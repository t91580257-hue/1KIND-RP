extends Node
## Локальная авторизация (автозагрузка AccountManager).
##
## ВАЖНО: это ЛОКАЛЬНАЯ авторизация на устройстве, а не онлайн-система.
## Аккаунты хранятся в user://accounts.json, пароли — только в виде
## PBKDF2-HMAC-SHA256 с уникальной случайной солью (в открытом виде не хранятся).
## Для перехода на серверную авторизацию (Nakama) см. network_service.gd и README.
##
## ПРОИЗВОДИТЕЛЬНОСТЬ (важно для Android): хеширование выполняется
## порциями внутри бюджета HASH_BUDGET_MS на кадр (pbkdf2_sha256_async),
## поэтому экран входа/регистрации НЕ зависает и показывает прогресс.
## Жёсткий лимит MAX_HASH_SECONDS гарантирует, что проверка не может
## длиться вечно даже на самом слабом устройстве.

signal hashing_progress(fraction: float)  # 0.0..1.0 — прогресс хеширования

const ACCOUNTS_PATH := "user://accounts.json"
const PBKDF2_ITERATIONS := 2000      # новые аккаунты: быстро даже на слабых Android
const LEGACY_ITERATIONS := 10000     # старые аккаунты (мигрируются при входе)
const SALT_BYTES := 16
const HASH_BYTES := 32
const HASH_BUDGET_MS := 8.0          # бюджет хеширования на один кадр, мс
const MAX_HASH_SECONDS := 45.0       # жёсткий предел общей длительности проверки
const MIN_NICK := 3
const MAX_NICK := 16
const MIN_PASS := 6
const MAX_PASS := 64
const GENERIC_LOGIN_ERROR := "Неверный никнейм или пароль."

var current_nick: String = ""
var logged_in: bool = false

var _accounts: Dictionary = {}
var _crypto := Crypto.new()


func _ready() -> void:
	_load_accounts()


## PBKDF2-HMAC-SHA256 (RFC 8018). Возвращает dk_len байт.
## Синхронная версия: блокирует поток до завершения. Из UI НЕ вызывать —
## используйте pbkdf2_sha256_async() / login_async() / register_async().
func pbkdf2_sha256(password: PackedByteArray, salt: PackedByteArray, iterations: int, dk_len: int = 32) -> PackedByteArray:
	var crypto := _crypto
	var result := PackedByteArray()
	var block_index := 1
	while result.size() < dk_len:
		var salt_block := salt.duplicate()
		salt_block.append((block_index >> 24) & 0xFF)
		salt_block.append((block_index >> 16) & 0xFF)
		salt_block.append((block_index >> 8) & 0xFF)
		salt_block.append(block_index & 0xFF)
		var u: PackedByteArray = crypto.hmac_digest(HashingContext.HASH_SHA256, password, salt_block)
		var t: PackedByteArray = u.duplicate()
		var n := t.size()
		var i := 1
		while i < iterations:
			u = crypto.hmac_digest(HashingContext.HASH_SHA256, password, u)
			var j := 0
			while j < n:
				t[j] = t[j] ^ u[j]
				j += 1
			i += 1
		result.append_array(t)
		block_index += 1
	return result.slice(0, dk_len)


## Асинхронная версия PBKDF2: итерации выполняются порциями в рамках бюджета
## HASH_BUDGET_MS на кадр, между порциями отдаётся кадр — интерфейс продолжает
## работать, прогресс транслируется сигналом hashing_progress (0..1).
## Возвращает хеш (dk_len байт) или ПУСТОЙ массив, если превышен лимит
## MAX_HASH_SECONDS — вызывающий код обязан трактовать это как ошибку.
func pbkdf2_sha256_async(password: PackedByteArray, salt: PackedByteArray, iterations: int, dk_len: int = 32) -> PackedByteArray:
	var crypto := _crypto
	var result := PackedByteArray()
	var block_index := 1
	var started_ms := Time.get_ticks_msec()
	var done := 0
	while result.size() < dk_len:
		var salt_block := salt.duplicate()
		salt_block.append((block_index >> 24) & 0xFF)
		salt_block.append((block_index >> 16) & 0xFF)
		salt_block.append((block_index >> 8) & 0xFF)
		salt_block.append(block_index & 0xFF)
		var u: PackedByteArray = crypto.hmac_digest(HashingContext.HASH_SHA256, password, salt_block)
		var t: PackedByteArray = u.duplicate()
		var n := t.size()
		var frame_start := Time.get_ticks_msec()
		var i := 1
		while i < iterations:
			u = crypto.hmac_digest(HashingContext.HASH_SHA256, password, u)
			var j := 0
			while j < n:
				t[j] = t[j] ^ u[j]
				j += 1
			i += 1
			done += 1
			if Time.get_ticks_msec() - frame_start >= HASH_BUDGET_MS:
				hashing_progress.emit(minf(float(done) / float(iterations), 1.0))
				await get_tree().process_frame
				frame_start = Time.get_ticks_msec()
		result.append_array(t)
		block_index += 1
		hashing_progress.emit(minf(float(done) / float(iterations), 1.0))
		if Time.get_ticks_msec() - started_ms > int(MAX_HASH_SECONDS * 1000.0):
			push_warning("PBKDF2 прерван: превышен лимит %.0f с" % MAX_HASH_SECONDS)
			return PackedByteArray()
	return result.slice(0, dk_len)


func validate_nick(nick: String) -> String:
	if nick.length() < MIN_NICK or nick.length() > MAX_NICK:
		return "Никнейм должен содержать от %d до %d символов." % [MIN_NICK, MAX_NICK]
	var rx := RegEx.new()
	rx.compile("^[\\p{L}0-9_]+$")
	if rx.search(nick) == null:
		return "Никнейм может содержать только буквы, цифры и знак «_»."
	return ""


func validate_password(password: String) -> String:
	if password.length() < MIN_PASS:
		return "Пароль должен содержать минимум %d символов." % MIN_PASS
	if password.length() > MAX_PASS:
		return "Пароль слишком длинный (максимум %d символов)." % MAX_PASS
	return ""


func nick_key(nick: String) -> String:
	return nick.strip_edges().to_lower()


func account_exists(nick: String) -> bool:
	return _accounts.has(nick_key(nick))


## Регистрация (синхронная версия для совместимости; из UI использовать register_async).
## Возвращает {"ok": bool, "error": String, "nick": String}.
func register(nick: String, password: String, password_repeat: String) -> Dictionary:
	nick = nick.strip_edges()
	if nick.is_empty() or password.is_empty() or password_repeat.is_empty():
		return {"ok": false, "error": "Заполните все поля."}
	var nick_error := validate_nick(nick)
	if nick_error != "":
		return {"ok": false, "error": nick_error}
	var pass_error := validate_password(password)
	if pass_error != "":
		return {"ok": false, "error": pass_error}
	if password != password_repeat:
		return {"ok": false, "error": "Пароли не совпадают."}
	if account_exists(nick):
		return {"ok": false, "error": "Такой никнейм уже занят на этом устройстве."}

	var salt: PackedByteArray = _crypto.generate_random_bytes(SALT_BYTES)
	var hash_bytes := pbkdf2_sha256(password.to_utf8_buffer(), salt, PBKDF2_ITERATIONS, HASH_BYTES)
	_accounts[nick_key(nick)] = {
		"nick": nick,
		"salt": salt.hex_encode(),
		"hash": hash_bytes.hex_encode(),
		"iterations": PBKDF2_ITERATIONS,
		"algo": "PBKDF2-HMAC-SHA256",
		"created": Time.get_unix_time_from_system(),
	}
	if not _save_accounts():
		_accounts.erase(nick_key(nick))
		return {"ok": false, "error": "Не удалось сохранить аккаунт на устройстве."}
	return {"ok": true, "error": "", "nick": nick}


## Асинхронная регистрация (не блокирует интерфейс, прогресс в hashing_progress).
## Возвращает {"ok": bool, "error": String, "nick": String}.
func register_async(nick: String, password: String, password_repeat: String) -> Dictionary:
	nick = nick.strip_edges()
	# Мгновенные проверки выполняются ДО хеширования — ошибки видны сразу.
	if nick.is_empty() or password.is_empty() or password_repeat.is_empty():
		return {"ok": false, "error": "Заполните все поля."}
	var nick_error := validate_nick(nick)
	if nick_error != "":
		return {"ok": false, "error": nick_error}
	var pass_error := validate_password(password)
	if pass_error != "":
		return {"ok": false, "error": pass_error}
	if password != password_repeat:
		return {"ok": false, "error": "Пароли не совпадают."}
	if account_exists(nick):
		return {"ok": false, "error": "Такой никнейм уже занят на этом устройстве."}

	var salt: PackedByteArray = _crypto.generate_random_bytes(SALT_BYTES)
	var hash_bytes := await pbkdf2_sha256_async(password.to_utf8_buffer(), salt, PBKDF2_ITERATIONS, HASH_BYTES)
	if hash_bytes.is_empty():
		return {"ok": false, "error": "Создание аккаунта заняло слишком много времени. Попробуйте ещё раз."}
	_accounts[nick_key(nick)] = {
		"nick": nick,
		"salt": salt.hex_encode(),
		"hash": hash_bytes.hex_encode(),
		"iterations": PBKDF2_ITERATIONS,
		"algo": "PBKDF2-HMAC-SHA256",
		"created": Time.get_unix_time_from_system(),
	}
	if not _save_accounts():
		_accounts.erase(nick_key(nick))
		return {"ok": false, "error": "Не удалось сохранить аккаунт на устройстве."}
	return {"ok": true, "error": "", "nick": nick}


## Асинхронный вход (не блокирует интерфейс, прогресс в hashing_progress).
## Старые аккаунты с 10000 итераций при первом же успешном входе переводятся
## на PBKDF2_ITERATIONS (быстрее на Android), пароль при этом уже проверен.
## Возвращает {"ok": bool, "error": String, "nick": String}.
func login_async(nick: String, password: String) -> Dictionary:
	nick = nick.strip_edges()
	if nick.is_empty() or password.is_empty():
		return {"ok": false, "error": "Введите никнейм и пароль."}
	var key := nick_key(nick)
	var acc: Dictionary = {}
	if _accounts.has(key):
		acc = _accounts[key]
	var known := not acc.is_empty()
	var salt: PackedByteArray
	var iterations := PBKDF2_ITERATIONS
	var expected := PackedByteArray()
	if known:
		salt = String(acc.get("salt", "")).hex_decode()
		iterations = int(acc.get("iterations", PBKDF2_ITERATIONS))
		if iterations < 1:
			iterations = PBKDF2_ITERATIONS
		expected = String(acc.get("hash", "")).hex_decode()
	else:
		# Фиктивное вычисление, чтобы время ответа не выдавало существование аккаунта.
		salt = _crypto.generate_random_bytes(SALT_BYTES)
	var actual := await pbkdf2_sha256_async(password.to_utf8_buffer(), salt, iterations, HASH_BYTES)
	if actual.is_empty():
		return {"ok": false, "error": "Проверка заняла слишком много времени. Попробуйте ещё раз."}
	if not known or not _constant_time_equal(actual, expected):
		return {"ok": false, "error": GENERIC_LOGIN_ERROR}
	current_nick = String(acc.get("nick", nick))
	logged_in = true
	# Разовая миграция старого аккаунта на быстрый параметр итераций.
	if iterations != PBKDF2_ITERATIONS:
		var new_salt: PackedByteArray = _crypto.generate_random_bytes(SALT_BYTES)
		var new_hash := await pbkdf2_sha256_async(password.to_utf8_buffer(), new_salt, PBKDF2_ITERATIONS, HASH_BYTES)
		if not new_hash.is_empty():
			_accounts[key] = {
				"nick": current_nick,
				"salt": new_salt.hex_encode(),
				"hash": new_hash.hex_encode(),
				"iterations": PBKDF2_ITERATIONS,
				"algo": "PBKDF2-HMAC-SHA256",
				"created": acc.get("created", Time.get_unix_time_from_system()),
			}
			_save_accounts()
	return {"ok": true, "error": "", "nick": current_nick}


## Вход (синхронная версия для совместимости; из UI использовать login_async).
## Возвращает {"ok": bool, "error": String, "nick": String}.
func login(nick: String, password: String) -> Dictionary:
	nick = nick.strip_edges()
	if nick.is_empty() or password.is_empty():
		return {"ok": false, "error": "Введите никнейм и пароль."}
	var key := nick_key(nick)
	var acc: Dictionary = {}
	if _accounts.has(key):
		acc = _accounts[key]
	var salt: PackedByteArray
	var iterations := PBKDF2_ITERATIONS
	var expected := PackedByteArray()
	if acc.is_empty():
		# Фиктивное вычисление, чтобы время ответа не выдавало существование аккаунта.
		salt = _crypto.generate_random_bytes(SALT_BYTES)
	else:
		salt = String(acc.get("salt", "")).hex_decode()
		iterations = int(acc.get("iterations", PBKDF2_ITERATIONS))
		expected = String(acc.get("hash", "")).hex_decode()
	var actual := pbkdf2_sha256(password.to_utf8_buffer(), salt, iterations, HASH_BYTES)
	if acc.is_empty() or not _constant_time_equal(actual, expected):
		return {"ok": false, "error": GENERIC_LOGIN_ERROR}
	current_nick = String(acc.get("nick", nick))
	logged_in = true
	return {"ok": true, "error": "", "nick": current_nick}


func logout() -> void:
	current_nick = ""
	logged_in = false


func _constant_time_equal(a: PackedByteArray, b: PackedByteArray) -> bool:
	if a.size() != b.size():
		return false
	var diff := 0
	for i in range(a.size()):
		diff |= a[i] ^ b[i]
	return diff == 0


func _load_accounts() -> void:
	_accounts = {}
	if not FileAccess.file_exists(ACCOUNTS_PATH):
		return
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("accounts") and typeof(parsed["accounts"]) == TYPE_DICTIONARY:
		_accounts = parsed["accounts"]


func _save_accounts() -> bool:
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Не удалось открыть %s для записи" % ACCOUNTS_PATH)
		return false
	f.store_string(JSON.stringify({"version": 1, "accounts": _accounts}))
	f.close()
	return true
