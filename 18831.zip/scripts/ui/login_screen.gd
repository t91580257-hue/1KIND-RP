extends Control
## Экран входа. Проверяет никнейм и пароль через локальный AccountManager.

signal login_success(nick: String)
signal register_requested
signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _nick: LineEdit
var _pass: LineEdit
var _status: Label
var _login_btn: Button
var _busy: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim(0.7))
	# Форма расположена в верхней части экрана, чтобы её не закрывала экранная клавиатура.
	var top := MarginContainer.new()
	top.set_anchors_preset(Control.PRESET_FULL_RECT)
	top.add_theme_constant_override("margin_top", 28)
	add_child(top)
	var holder := HBoxContainer.new()
	holder.alignment = BoxContainer.ALIGNMENT_CENTER
	holder.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(holder)
	var panel := UiKit.make_panel()
	holder.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)

	vb.add_child(UiKit.make_title("Вход", 40))
	_nick = UiKit.make_line_edit("Никнейм")
	_nick.max_length = 16
	vb.add_child(_nick)
	_pass = UiKit.make_line_edit("Пароль", true)
	_pass.max_length = 64
	_pass.text_submitted.connect(func(_t: String) -> void: _do_login())
	vb.add_child(_pass)
	_status = UiKit.make_label("", 20, UiKit.COLOR_MUTED)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(380, 54)
	vb.add_child(_status)

	_login_btn = UiKit.make_button("Войти", "gold", Vector2(380, 64))
	_login_btn.pressed.connect(_do_login)
	vb.add_child(_login_btn)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	var reg := UiKit.make_button("Регистрация", "blue", Vector2(185, 56), 22)
	reg.pressed.connect(func() -> void: register_requested.emit())
	row.add_child(reg)
	var back := UiKit.make_button("Назад", "dark", Vector2(185, 56), 22)
	back.pressed.connect(func() -> void: closed.emit())
	row.add_child(back)
	var note := UiKit.make_label("Локальный аккаунт: данные хранятся только на этом устройстве.", 16, UiKit.COLOR_MUTED)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(380, 0)
	vb.add_child(note)


## Подставить никнейм и сообщение (например, после регистрации).
func prefill(nick: String, message: String) -> void:
	_nick.text = nick
	_set_status(message, UiKit.COLOR_OK)
	if nick != "":
		_pass.grab_focus()


func _set_status(text: String, color: Color) -> void:
	_status.text = text
	_status.add_theme_color_override("font_color", color)


func _do_login() -> void:
	if _busy:
		return
	var nick := _nick.text.strip_edges()
	var pw := _pass.text
	if nick.is_empty() or pw.is_empty():
		_set_status("Введите никнейм и пароль.", UiKit.COLOR_ERROR)
		AudioManager.play_sfx("error")
		return
	_busy = true
	_login_btn.disabled = true
	_set_status("Проверка данных…", UiKit.COLOR_MUTED)
	# Асинхронная проверка: интерфейс не замирает, статус показывает прогресс.
	if not AccountManager.hashing_progress.is_connected(_on_hash_progress):
		AccountManager.hashing_progress.connect(_on_hash_progress)
	var res: Dictionary = await AccountManager.login_async(nick, pw)
	if AccountManager.hashing_progress.is_connected(_on_hash_progress):
		AccountManager.hashing_progress.disconnect(_on_hash_progress)
	_busy = false
	_login_btn.disabled = false
	if bool(res["ok"]):
		_pass.text = ""
		login_success.emit(String(res["nick"]))
	else:
		_pass.text = ""
		_set_status(String(res["error"]), UiKit.COLOR_ERROR)
		AudioManager.play_sfx("error")


func _on_hash_progress(fraction: float) -> void:
	_set_status("Проверка данных… %d%%" % int(round(clampf(fraction, 0.0, 1.0) * 100.0)), UiKit.COLOR_MUTED)
