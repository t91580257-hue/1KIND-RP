extends Node
## ВЫДЕЛЕННЫЙ СЕРВЕР 1KIND RP — этап 1 онлайн-режима (Godot 4.3 headless).
##
## Запуск (на ПК или VPS с Godot 4.3):
##   godot --headless --path server/godot_server
## Порт: 7777 (ENet/UDP). До 50 игроков.
##
## Сервер АВТОРИТАРЕН: аккаунты, профиль, деньги, опыт и ключевые операции
## экономики считаются только здесь. Клиент отправляет запросы без сумм.
##
## Данные: server_data/accounts.json и server_data/profiles/<hash>.json.

const Catalogs = preload("res://catalogs.gd")

const PORT := 7777
const MAX_PLAYERS := 50
const PROTO_VERSION := 3
const TAX_RATE := 0.13
const JOB_MIN_SECONDS := 25.0     # минимальная длительность смены (анти-фарм)
const JOB_COOLDOWN := 90.0
const CHAT_COOLDOWN := 1.2
const STATE_INTERVAL := 0.1

const DATA_DIR := "res://server_data"
const ACCOUNTS_PATH := "res://server_data/accounts.json"

var _crypto := Crypto.new()
var accounts: Dictionary = {}          # nick_key -> {nick, salt, hash, iterations, created}
var profiles: Dictionary = {}          # nick_key -> profile Dictionary
var dirty_profiles: Dictionary = {}    # nick_key -> true (сохранить при автосейве)
var player_nicks: Dictionary = {}      # peer_id -> nick_key
var job_sessions: Dictionary = {}      # nick_key -> {"job": id, "started": unix}
var job_cooldowns: Dictionary = {}     # nick_key -> {job_id: ready_unix}
var chat_last: Dictionary = {}         # peer_id -> unix
var last_state: Dictionary = {}        # peer_id -> {"nick", "x","y","z","yaw"}
var _save_timer: float = 0.0
var _state_timer: float = 0.0


func _ready() -> void:
	DirAccess.make_dir_recursive_absolute(DATA_DIR)
	DirAccess.make_dir_recursive_absolute(DATA_DIR + "/profiles")
	_load_accounts()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, MAX_PLAYERS)
	if err != OK:
		push_error("Не удалось открыть порт %d (код %d). Возможно, порт занят." % [PORT, err])
		get_tree().quit(1)
		return
	multiplayer.multiplayer_peer = peer
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	print("=== 1KIND RP server: порт %d, слотов %d ===" % [PORT, MAX_PLAYERS])


func _process(delta: float) -> void:
	_state_timer += delta
	if _state_timer >= STATE_INTERVAL:
		_state_timer = 0.0
		_broadcast_players()
	_save_timer += delta
	if _save_timer >= 20.0:
		_save_timer = 0.0
		_save_dirty()


func _on_peer_connected(id: int) -> void:
	print("+ игрок подключился: #%d" % id)
	rpc_id(id, "cl_hello", PROTO_VERSION, MAX_PLAYERS)


func _on_peer_disconnected(id: int) -> void:
	var nk := String(player_nicks.get(id, ""))
	player_nicks.erase(id)
	last_state.erase(id)
	chat_last.erase(id)
	if nk != "":
		_save_profile(nk)
		job_sessions.erase(nk)
	print("- игрок отключился: #%d %s" % [id, nk])


# ---------------------------------------------------------------- пароли

func pbkdf2_sha256(password: PackedByteArray, salt: PackedByteArray, iterations: int, dk_len: int = 32) -> PackedByteArray:
	var result := PackedByteArray()
	var block_index := 1
	while result.size() < dk_len:
		var salt_block := salt.duplicate()
		salt_block.append((block_index >> 24) & 0xFF)
		salt_block.append((block_index >> 16) & 0xFF)
		salt_block.append((block_index >> 8) & 0xFF)
		salt_block.append(block_index & 0xFF)
		var u: PackedByteArray = _crypto.hmac_digest(HashingContext.HASH_SHA256, password, salt_block)
		var t: PackedByteArray = u.duplicate()
		for i in range(1, iterations):
			u = _crypto.hmac_digest(HashingContext.HASH_SHA256, password, u)
			for j in range(t.size()):
				t[j] = t[j] ^ u[j]
		result.append_array(t)
		block_index += 1
	return result.slice(0, dk_len)


func _constant_time_equal(a: PackedByteArray, b: PackedByteArray) -> bool:
	if a.size() != b.size():
		return false
	var diff := 0
	for i in range(a.size()):
		diff |= a[i] ^ b[i]
	return diff == 0


# ---------------------------------------------------------------- хранилище

func _load_accounts() -> void:
	if not FileAccess.file_exists(ACCOUNTS_PATH):
		return
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("accounts"):
		accounts = parsed["accounts"]
	print("Аккаунтов загружено: %d" % accounts.size())


func _save_accounts() -> void:
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Не удалось сохранить accounts.json")
		return
	f.store_string(JSON.stringify({"version": 1, "accounts": accounts}))
	f.close()


func profile_path(nk: String) -> String:
	return "%s/profiles/%s.json" % [DATA_DIR, nk.sha256_text()]


func get_profile(nk: String) -> Dictionary:
	if profiles.has(nk):
		return profiles[nk]
	if FileAccess.file_exists(profile_path(nk)):
		var f := FileAccess.open(profile_path(nk), FileAccess.READ)
		if f != null:
			var parsed: Variant = JSON.parse_string(f.get_as_text())
			f.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				profiles[nk] = parsed
				return parsed
	# Новый профиль.
	var prof := {
		"version": 3,
		"cash": 15000,
		"bank": 50000,
		"level": 1,
		"xp": 0,
		"play_seconds": 0.0,
		"health": 100.0,
		"hunger": 100.0,
		"thirst": 100.0,
		"slots": [],
		"owned_cars": [],
		"owned_property": [],
		"ledger": [],
		"appearance": {"skin": "f2c99a", "hair": "2b1c10", "shirt": "1e5fd6", "pants": "16223f", "shoes": "ffbe28"},
		"passport": {"first": "", "last": "", "gender": "м", "birth": "01.01.2000", "city": "Ванбург", "issued": 0.0},
		"job_skills": {},
		"org_ranks": {},
		"businesses": [],
		"licenses": [],
		"apartment_items": {},
		"statistics": {"jobs_done": 0, "tasks_done": 0, "arrests": 0, "races_won": 0, "fish_caught": 0},
	}
	for i in range(30):
		prof["slots"].append({})
	profiles[nk] = prof
	dirty_profiles[nk] = true
	return prof


func _save_profile(nk: String) -> void:
	if not profiles.has(nk):
		return
	var f := FileAccess.open(profile_path(nk), FileAccess.WRITE)
	if f == null:
		return
	f.store_string(JSON.stringify(profiles[nk]))
	f.close()
	dirty_profiles.erase(nk)


func _save_dirty() -> void:
	for nk in dirty_profiles.keys():
		_save_profile(String(nk))


func _log(prof: Dictionary, kind: String, amount: int, text: String) -> void:
	var led: Array = prof.get("ledger", [])
	led.push_front({"t": Time.get_unix_time_from_system(), "kind": kind, "amount": amount, "text": text})
	while led.size() > 100:
		led.pop_back()
	prof["ledger"] = led


func money_fmt(amount: int) -> String:
	var s := str(absi(amount))
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = " " + out
	if amount < 0:
		out = "-" + out
	return out + " ₽"


# ---------------------------------------------------------------- RPC: вход

@rpc("any_peer", "reliable")
func srv_hello(_proto: int) -> void:
	pass  # cl_hello отправляется сразу при подключении


@rpc("any_peer", "reliable")
func srv_register(nick: String, password: String) -> void:
	var sender := multiplayer.get_remote_sender_id()
	nick = nick.strip_edges()
	if nick.length() < 3 or nick.length() > 16:
		rpc_id(sender, "cl_register_result", false, "Никнейм: 3–16 символов.")
		return
	var nk := nick.to_lower()
	if accounts.has(nk):
		rpc_id(sender, "cl_register_result", false, "Никнейм занят на сервере.")
		return
	var salt: PackedByteArray = _crypto.generate_random_bytes(16)
	var hash_b: PackedByteArray = pbkdf2_sha256(password.to_utf8_buffer(), salt, 10000, 32)
	accounts[nk] = {"nick": nick, "salt": salt.hex_encode(), "hash": hash_b.hex_encode(), "iterations": 10000, "algo": "PBKDF2-HMAC-SHA256", "created": Time.get_unix_time_from_system()}
	_save_accounts()
	get_profile(nk)
	_save_profile(nk)
	print("Регистрация: %s" % nick)
	rpc_id(sender, "cl_register_result", true, "")


@rpc("any_peer", "reliable")
func srv_auth(nick: String, password: String) -> void:
	var sender := multiplayer.get_remote_sender_id()
	var nk := nick.strip_edges().to_lower()
	var expected := PackedByteArray()
	var salt := PackedByteArray()
	var iterations := 10000
	if accounts.has(nk):
		salt = String(accounts[nk].get("salt", "")).hex_decode()
		iterations = int(accounts[nk].get("iterations", 10000))
		expected = String(accounts[nk].get("hash", "")).hex_decode()
	else:
		salt = _crypto.generate_random_bytes(16)
	var actual := pbkdf2_sha256(password.to_utf8_buffer(), salt, iterations, 32)
	if not accounts.has(nk) or not _constant_time_equal(actual, expected):
		rpc_id(sender, "cl_auth_result", false, "Неверный никнейм или пароль.")
		return
	player_nicks[sender] = nk
	get_profile(nk)
	print("Вход: %s (#%d)" % [nk, sender])
	rpc_id(sender, "cl_auth_result", true, "")
	rpc_id(sender, "cl_profile", profiles[nk])


# ---------------------------------------------------------------- RPC: состояние и чат

@rpc("any_peer", "unreliable")
func srv_state(x: float, y: float, z: float, yaw: float) -> void:
	var sender := multiplayer.get_remote_sender_id()
	if not player_nicks.has(sender):
		return
	var prev: Dictionary = last_state.get(sender, {})
	if not prev.is_empty():
		var d := Vector3(x, y, z).distance_to(Vector3(float(prev["x"]), float(prev["y"]), float(prev["z"])))
		if d > 120.0:
			return
	var nick: String = String(accounts.get(String(player_nicks[sender]), {}).get("nick", "Игрок"))
	last_state[sender] = {"nick": nick, "x": x, "y": y, "z": z, "yaw": yaw}


func _broadcast_players() -> void:
	if last_state.is_empty():
		return
	for pid in multiplayer.get_peers():
		if player_nicks.has(pid):
			rpc_id(pid, "cl_players", last_state)


@rpc("any_peer", "reliable")
func srv_chat(text: String) -> void:
	var sender := multiplayer.get_remote_sender_id()
	if not player_nicks.has(sender):
		return
	var now := Time.get_unix_time_from_system()
	if now - float(chat_last.get(sender, 0.0)) < CHAT_COOLDOWN:
		return
	chat_last[sender] = now
	var t := text.strip_edges()
	if t.is_empty() or t.length() > 200:
		return
	var nick: String = String(accounts.get(String(player_nicks[sender]), {}).get("nick", "Игрок"))
	for pid in multiplayer.get_peers():
		if player_nicks.has(pid):
			rpc_id(pid, "cl_chat", nick, t)


# ---------------------------------------------------------------- RPC: экономика (авторитарно)

@rpc("any_peer", "reliable")
func srv_action(req: int, op: String, args: Dictionary) -> void:
	var sender := multiplayer.get_remote_sender_id()
	if not player_nicks.has(sender):
		return
	var nk := String(player_nicks[sender])
	var prof := get_profile(nk)
	var ok := false
	var text := ""
	match op:
		"job_start":
			var r := _server_job_start(nk, String(args.get("job", "")))
			ok = r[0]
			text = r[1]
		"job_done":
			var r2 := _server_job_done(nk, String(args.get("job", "")), float(args.get("elapsed", 0.0)))
			ok = r2[0]
			text = r2[1]
		"buy":
			var r3 := _server_buy(prof, String(args.get("kind", "")), String(args.get("item", "")))
			ok = r3[0]
			text = r3[1]
		"buy_car":
			var r4 := _server_buy_car(prof, String(args.get("car", "")), String(args.get("color", "")))
			ok = r4[0]
			text = r4[1]
		"sell_item":
			var r5 := _server_sell_item(prof, String(args.get("item", "")), int(args.get("count", 1)))
			ok = r5[0]
			text = r5[1]
		"atm_deposit":
			var r6 := _server_atm(prof, true, int(args.get("amount", 0)))
			ok = r6[0]
			text = r6[1]
		"atm_withdraw":
			var r7 := _server_atm(prof, false, int(args.get("amount", 0)))
			ok = r7[0]
			text = r7[1]
		_:
			text = "Неизвестная операция."
	dirty_profiles[nk] = true
	rpc_id(sender, "cl_action_result", req, op, ok, text)
	rpc_id(sender, "cl_profile", prof)


# ---------------------------------------------------------------- серверные операции

func _server_job_start(nk: String, job_id: String) -> Array:
	if not Catalogs.JOBS.has(job_id):
		return [false, "Работа не найдена."]
	var prof := get_profile(nk)
	var level := int(prof.get("level", 1))
	if level < int(Catalogs.JOBS[job_id]["min_level"]):
		return [false, "Нужен уровень %d." % int(Catalogs.JOBS[job_id]["min_level"])]
	var cds: Dictionary = job_cooldowns.get(nk, {})
	var left := float(cds.get(job_id, 0.0)) - Time.get_unix_time_from_system()
	if left > 0.0:
		return [false, "Следующая смена через %d с." % int(ceil(left))]
	if job_sessions.has(nk):
		return [false, "Смена уже начата на сервере."]
	job_sessions[nk] = {"job": job_id, "started": Time.get_unix_time_from_system()}
	return [true, "Смена «%s» подтверждена сервером." % String(Catalogs.JOBS[job_id]["name"])]


func _server_job_done(nk: String, job_id: String, _elapsed: float) -> Array:
	var session: Dictionary = job_sessions.get(nk, {})
	if session.is_empty() or String(session.get("job", "")) != job_id:
		return [false, "Смена не была начата на сервере."]
	job_sessions.erase(nk)
	var real_elapsed := Time.get_unix_time_from_system() - float(session.get("started", 0.0))
	if real_elapsed < JOB_MIN_SECONDS:
		return [false, "Слишком быстро для честной смены (античит сервера)."]
	var job: Dictionary = Catalogs.JOBS[job_id]
	var prof := get_profile(nk)
	var skills: Dictionary = prof.get("job_skills", {})
	var sx := int(skills.get(job_id, 0))
	var lvl := Catalogs.job_skill_level(sx)
	var pay := int(round(float(job["base_pay"]) * (1.0 + 0.15 * float(lvl - 1))))
	if job.has("org"):
		var ranks: Dictionary = prof.get("org_ranks", {})
		var rank := clampi(int(ranks.get(job["org"], 1)), 1, 5)
		pay = int(round(float(pay) * float(Catalogs.RANK_PAY[rank - 1])))
	var tax := int(round(float(pay) * TAX_RATE))
	var net := pay - tax
	prof["bank"] = int(prof.get("bank", 0)) + net
	prof["xp"] = int(prof.get("xp", 0)) + int(job["xp"])
	skills[job_id] = sx + int(job["xp"])
	prof["job_skills"] = skills
	var stats: Dictionary = prof.get("statistics", {})
	stats["jobs_done"] = int(stats.get("jobs_done", 0)) + 1
	prof["statistics"] = stats
	_log(prof, "bank", net, "Зарплата: %s (налог %s)" % [String(job["name"]), money_fmt(tax)])
	var cds: Dictionary = job_cooldowns.get(nk, {})
	cds[job_id] = Time.get_unix_time_from_system() + JOB_COOLDOWN
	job_cooldowns[nk] = cds
	return [true, "Смена «%s» завершена: +%s на счёт (сервер)" % [String(job["name"]), money_fmt(net)]]


func _server_buy(prof: Dictionary, kind: String, item_id: String) -> Array:
	var catalog: Dictionary = {}
	if kind == "shop":
		for id in Catalogs.SHOP_ITEMS:
			catalog[id] = Catalogs.ITEMS[id]
	elif kind == "property":
		catalog = Catalogs.PROPERTY
	else:
		return [false, "Раздел недоступен онлайн."]
	if not catalog.has(item_id):
		return [false, "Товар не найден."]
	var price := int(catalog[item_id]["price"])
	if kind == "property" and Array(prof.get("owned_property", [])).has(item_id):
		return [false, "Уже куплено."]
	if int(prof.get("cash", 0)) + int(prof.get("bank", 0)) < price:
		return [false, "Недостаточно средств."]
	var from_cash := mini(int(prof.get("cash", 0)), price)
	prof["cash"] = int(prof.get("cash", 0)) - from_cash
	prof["bank"] = int(prof.get("bank", 0)) - (price - from_cash)
	match kind:
		"shop":
			var slots: Array = prof.get("slots", [])
			var placed := false
			for i in range(slots.size()):
				if typeof(slots[i]) != TYPE_DICTIONARY or slots[i].is_empty():
					slots[i] = {"id": item_id, "count": 1}
					placed = true
					break
			if not placed:
				return [false, "Инвентарь полон."]
			prof["slots"] = slots
		"property":
			var props: Array = prof.get("owned_property", [])
			props.append(item_id)
			prof["owned_property"] = props
	_log(prof, "cash", -price, "Покупка: %s" % String(catalog[item_id]["name"]))
	return [true, "Куплено: %s (сервер)" % String(catalog[item_id]["name"])]


func _server_buy_car(prof: Dictionary, car_id: String, color: String) -> Array:
	if not Catalogs.CARS.has(car_id):
		return [false, "Автомобиль не найден."]
	var cars: Array = prof.get("owned_cars", [])
	for c in cars:
		if String(c.get("id", "")) == car_id:
			return [false, "Этот автомобиль уже в гараже."]
	if cars.size() >= 12:
		return [false, "Гараж заполнен."]
	var def: Dictionary = Catalogs.CARS[car_id]
	var price := int(def["price"])
	if int(prof.get("cash", 0)) + int(prof.get("bank", 0)) < price:
		return [false, "Недостаточно средств."]
	var col := color if Array(def["colors"]).has(color) else String(def["colors"][0])
	var from_cash := mini(int(prof.get("cash", 0)), price)
	prof["cash"] = int(prof.get("cash", 0)) - from_cash
	prof["bank"] = int(prof.get("bank", 0)) - (price - from_cash)
	cars.append({"uid": "%s_%d" % [car_id, Time.get_unix_time_from_system()], "id": car_id, "color": col, "fuel": float(def["tank"]), "damage": 0.0, "tuning": {}})
	prof["owned_cars"] = cars
	_log(prof, "cash", -price, "Покупка авто: %s" % String(def["name"]))
	return [true, "Автомобиль куплен: %s (сервер)" % String(def["name"])]


func _server_sell_item(prof: Dictionary, item_id: String, count: int) -> Array:
	if not Catalogs.SELLABLE.has(item_id):
		return [false, "Этот предмет не принимают."]
	var base_price := int(Catalogs.item_def(item_id).get("price", 0))
	if base_price <= 0:
		return [false, "Нет рыночной цены."]
	var slots: Array = prof.get("slots", [])
	var have := 0
	for s in slots:
		if typeof(s) == TYPE_DICTIONARY and not s.is_empty() and String(s.get("id", "")) == item_id:
			have += int(s.get("count", 0))
	if have == 0:
		return [false, "Предмета нет в инвентаре."]
	var n := clampi(count, 1, have)
	var unit := maxi(1, int(round(float(base_price) * 0.62)))
	var total := unit * n
	var left := n
	for i in range(slots.size() - 1, -1, -1):
		if left <= 0:
			break
		var s: Variant = slots[i]
		if typeof(s) == TYPE_DICTIONARY and not s.is_empty() and String(s.get("id", "")) == item_id:
			var take := mini(left, int(s.get("count", 0)))
			s["count"] = int(s.get("count", 0)) - take
			left -= take
			if int(s["count"]) <= 0:
				slots[i] = {}
	prof["slots"] = slots
	prof["cash"] = int(prof.get("cash", 0)) + total
	_log(prof, "cash", total, "Продажа: %s × %d" % [Catalogs.item_name(item_id), n])
	return [true, "Продано %s × %d за %s (сервер)" % [Catalogs.item_name(item_id), n, money_fmt(total)]]


func _server_atm(prof: Dictionary, deposit: bool, amount: int) -> Array:
	if amount <= 0:
		return [false, "Неверная сумма."]
	if deposit:
		if int(prof.get("cash", 0)) < amount:
			return [false, "Недостаточно наличных."]
		prof["cash"] = int(prof.get("cash", 0)) - amount
		prof["bank"] = int(prof.get("bank", 0)) + amount
		_log(prof, "bank", amount, "Пополнение через банкомат")
		return [true, "Внесено: %s (сервер)" % money_fmt(amount)]
	if int(prof.get("bank", 0)) < amount:
		return [false, "Недостаточно средств на счёте."]
	prof["bank"] = int(prof.get("bank", 0)) - amount
	prof["cash"] = int(prof.get("cash", 0)) + amount
	_log(prof, "bank", -amount, "Снятие в банкомате")
	return [true, "Снято: %s (сервер)" % money_fmt(amount)]


# ---------------------------------------------------------------- клиентские RPC-заглушки (нужны для конфигурации)

@rpc("authority", "reliable")
func cl_hello(_proto: int, _max_players: int) -> void:
	pass


@rpc("authority", "reliable")
func cl_register_result(_ok: bool, _error: String) -> void:
	pass


@rpc("authority", "reliable")
func cl_auth_result(_ok: bool, _error: String) -> void:
	pass


@rpc("authority", "reliable")
func cl_profile(_data: Dictionary) -> void:
	pass


@rpc("authority", "unreliable")
func cl_players(_players: Dictionary) -> void:
	pass


@rpc("authority", "reliable")
func cl_chat(_from: String, _text: String) -> void:
	pass


@rpc("authority", "reliable")
func cl_action_result(_req: int, _op: String, _ok: bool, _text: String) -> void:
	pass
