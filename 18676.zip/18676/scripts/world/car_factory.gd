extends RefCounted
## Процедурные 3D-модели автомобилей. Каждый тип кузова (shape) строится по своему профилю:
## длина, ширина, высота, форма салона, спойлеры, кузов пикапа, открытый верх и т.д.
## Передняя часть автомобиля направлена в +X. Модель строится кодом из примитивов — это оригинальные
## модели без сторонних ресурсов.

const Kit = preload("res://scripts/world/world_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

# length, width, body_h, wheel_r, cab_len, cab_h, cab_x, roof(bool)
const PROFILES: Dictionary = {
	"hatch": {"l": 3.7, "w": 1.7, "h": 0.62, "wr": 0.30, "cl": 2.0, "ch": 0.55, "cx": -0.15, "roof": true},
	"sedan": {"l": 4.5, "w": 1.8, "h": 0.65, "wr": 0.33, "cl": 2.2, "ch": 0.52, "cx": -0.25, "roof": true},
	"van": {"l": 4.4, "w": 1.85, "h": 0.95, "wr": 0.32, "cl": 3.3, "ch": 0.78, "cx": -0.15, "roof": true},
	"crossover": {"l": 4.3, "w": 1.82, "h": 0.8, "wr": 0.36, "cl": 2.5, "ch": 0.6, "cx": -0.2, "roof": true},
	"pickup": {"l": 5.0, "w": 1.9, "h": 0.85, "wr": 0.38, "cl": 1.5, "ch": 0.62, "cx": 0.55, "roof": true},
	"wagon": {"l": 4.7, "w": 1.8, "h": 0.65, "wr": 0.33, "cl": 3.0, "ch": 0.55, "cx": -0.35, "roof": true},
	"suv": {"l": 4.6, "w": 1.95, "h": 0.95, "wr": 0.42, "cl": 2.9, "ch": 0.65, "cx": -0.3, "roof": true},
	"coupe": {"l": 4.4, "w": 1.85, "h": 0.55, "wr": 0.33, "cl": 1.7, "ch": 0.42, "cx": -0.35, "roof": true},
	"cabrio": {"l": 4.3, "w": 1.8, "h": 0.58, "wr": 0.33, "cl": 1.7, "ch": 0.4, "cx": -0.3, "roof": false},
	"limo": {"l": 5.3, "w": 1.95, "h": 0.72, "wr": 0.35, "cl": 2.9, "ch": 0.55, "cx": -0.4, "roof": true},
	"bigsuv": {"l": 5.0, "w": 2.05, "h": 1.05, "wr": 0.46, "cl": 3.1, "ch": 0.7, "cx": -0.35, "roof": true},
	"gt": {"l": 4.75, "w": 1.95, "h": 0.5, "wr": 0.35, "cl": 1.5, "ch": 0.4, "cx": -0.6, "roof": true},
	"roadster": {"l": 4.0, "w": 1.85, "h": 0.48, "wr": 0.33, "cl": 1.3, "ch": 0.36, "cx": -0.2, "roof": false},
	"super": {"l": 4.5, "w": 2.0, "h": 0.42, "wr": 0.34, "cl": 1.4, "ch": 0.36, "cx": -0.25, "roof": true},
}


## Возвращает Node3D с моделью. car_id — ключ из Catalogs.CARS, color_hex — цвет кузова.
static func build(car_id: String, color_hex: String) -> Node3D:
	var def: Dictionary = Catalogs.CARS.get(car_id, {})
	var shape := String(def.get("shape", "sedan"))
	return build_shape(shape, Color(color_hex))


static func build_shape(shape: String, color: Color) -> Node3D:
	var p: Dictionary = PROFILES.get(shape, PROFILES["sedan"])
	var L: float = p["l"]
	var W: float = p["w"]
	var H: float = p["h"]
	var wr: float = p["wr"]
	var cl: float = p["cl"]
	var ch: float = p["ch"]
	var cx: float = p["cx"]
	var has_roof: bool = p["roof"]
	var root := Node3D.new()
	var paint := Kit.color_mat(color, 0.25, 0.6)
	var dark := Kit.color_mat(Color(0.05, 0.05, 0.07), 0.8)
	var chrome := Kit.color_mat(Color(0.75, 0.78, 0.82), 0.2, 0.9)
	var glass := Kit.glass_mat()
	var floor_y := wr * 0.8
	var body_y := floor_y + H * 0.5

	# Кузов, нижняя юбка и бамперы.
	Kit.add_box(root, Vector3(0, body_y, 0), Vector3(L, H, W), paint, false, 0.0, true)
	Kit.add_box(root, Vector3(0, floor_y + 0.05, 0), Vector3(L * 0.96, 0.12, W + 0.02), dark, false, 0.0, true)
	Kit.add_box(root, Vector3(L * 0.5, floor_y + H * 0.28, 0), Vector3(0.18, H * 0.4, W * 0.96), dark, false, 0.0, true)
	Kit.add_box(root, Vector3(-L * 0.5, floor_y + H * 0.28, 0), Vector3(0.18, H * 0.4, W * 0.96), dark, false, 0.0, true)
	# Капот ниже кабины, чуть скошенный.
	var top_y := floor_y + H
	var hood := Kit.add_box(root, Vector3(L * 0.5 - 0.7, top_y + 0.01, 0), Vector3(1.5, 0.05, W * 0.9), paint, false, 0.0, true)
	hood.rotation_degrees.z = -4.0

	# Салон: стёкла, стойки, крыша.
	var cab_y := top_y + ch * 0.5
	var cab_front := cx + cl * 0.5
	var cab_back := cx - cl * 0.5
	Kit.add_box(root, Vector3(cx, cab_y, 0), Vector3(cl - 0.5, ch, W * 0.88), glass, false, 0.0, true)
	var ws := Kit.add_box(root, Vector3(cab_front - 0.12, cab_y, 0), Vector3(0.07, ch * 1.12, W * 0.86), glass, false, 0.0, true)
	ws.rotation_degrees.z = -32.0
	var rw := Kit.add_box(root, Vector3(cab_back + 0.12, cab_y, 0), Vector3(0.07, ch * 1.12, W * 0.86), glass, false, 0.0, true)
	rw.rotation_degrees.z = 30.0
	if has_roof:
		Kit.add_box(root, Vector3(cx, top_y + ch + 0.02, 0), Vector3(cl - 0.55, 0.05, W * 0.84), paint, false, 0.0, true)
		for sz in [-1.0, 1.0]:
			Kit.add_box(root, Vector3(cx, cab_y, sz * W * 0.44), Vector3(cl - 0.5, ch, 0.05), paint, false, 0.0, true)
	else:
		# Открытый верх: сиденья и рамка лобового стекла.
		for sx in [cx - 0.1, cx + 0.5]:
			Kit.add_box(root, Vector3(sx - 0.2, top_y + 0.2, -W * 0.22), Vector3(0.5, 0.35, 0.45), dark, false, 0.0, true)
			Kit.add_box(root, Vector3(sx - 0.2, top_y + 0.2, W * 0.22), Vector3(0.5, 0.35, 0.45), dark, false, 0.0, true)

	# Колёса.
	var tire := Kit.color_mat(Color(0.04, 0.04, 0.05), 0.95)
	var wheel_x := L * 0.5 - wr - 0.28
	for wx in [-wheel_x, wheel_x]:
		for wz in [-(W * 0.5 - 0.1), W * 0.5 - 0.1]:
			var w := Kit.add_cylinder(root, Vector3(wx, wr, wz), wr, 0.26, tire, false, 14, true)
			w.rotation_degrees.x = 90.0
			var hub := Kit.add_cylinder(root, Vector3(wx, wr, wz + (0.14 if wz > 0.0 else -0.14)), wr * 0.55, 0.04, chrome, false, 10, true)
			hub.rotation_degrees.x = 90.0

	# Фары, задние огни, решётка, номер.
	var head := Kit.emissive_mat(Color(1, 0.97, 0.85), 1.4)
	var tail := Kit.emissive_mat(Color(1, 0.12, 0.12), 1.0)
	for sz in [-1.0, 1.0]:
		Kit.add_box(root, Vector3(L * 0.5 + 0.02, floor_y + H * 0.62, sz * W * 0.32), Vector3(0.05, 0.14, W * 0.2), head, false, 0.0, true)
		Kit.add_box(root, Vector3(-L * 0.5 - 0.02, floor_y + H * 0.62, sz * W * 0.32), Vector3(0.05, 0.14, W * 0.2), tail, false, 0.0, true)
		Kit.add_box(root, Vector3(cab_front - 0.35, top_y + 0.06, sz * (W * 0.5 + 0.05)), Vector3(0.14, 0.1, 0.1), paint, false, 0.0, true)
	Kit.add_box(root, Vector3(L * 0.5 + 0.03, floor_y + H * 0.3, 0), Vector3(0.04, 0.16, W * 0.3), chrome, false, 0.0, true)
	Kit.add_box(root, Vector3(-L * 0.5 - 0.03, floor_y + H * 0.3, 0), Vector3(0.04, 0.14, 0.45), Kit.color_mat(Color(0.95, 0.95, 0.85), 0.5), false, 0.0, true)

	_shape_extras(root, shape, p, paint, dark, chrome, floor_y, top_y)

	# Простая коллизия-габарит, чтобы игрок не проходил сквозь машину.
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(L, H + ch, W)
	cs.shape = box
	cs.position = Vector3(0, floor_y + (H + ch) * 0.5, 0)
	body.add_child(cs)
	root.add_child(body)
	return root


static func _shape_extras(root: Node3D, shape: String, p: Dictionary, paint: Material, dark: Material, chrome: Material, floor_y: float, top_y: float) -> void:
	var L: float = p["l"]
	var W: float = p["w"]
	var cx: float = p["cx"]
	var cl: float = p["cl"]
	var ch: float = p["ch"]
	match shape:
		"pickup":
			# Кузов-платформа: пол и три борта.
			var bed_x := -L * 0.5 + 1.0
			Kit.add_box(root, Vector3(bed_x, top_y - 0.05, 0), Vector3(1.9, 0.06, W * 0.92), dark, false, 0.0, true)
			Kit.add_box(root, Vector3(bed_x, top_y + 0.2, -W * 0.46), Vector3(1.9, 0.4, 0.07), paint, false, 0.0, true)
			Kit.add_box(root, Vector3(bed_x, top_y + 0.2, W * 0.46), Vector3(1.9, 0.4, 0.07), paint, false, 0.0, true)
			Kit.add_box(root, Vector3(bed_x - 0.95, top_y + 0.2, 0), Vector3(0.07, 0.4, W * 0.92), paint, false, 0.0, true)
			Kit.add_box(root, Vector3(bed_x + 0.95, top_y + 0.2, 0), Vector3(0.07, 0.4, W * 0.92), paint, false, 0.0, true)
		"van":
			Kit.add_box(root, Vector3(-L * 0.5 + 0.9, top_y + ch + 0.08, 0), Vector3(2.2, 0.06, W * 0.7), dark, false, 0.0, true)
		"wagon", "suv", "bigsuv", "crossover":
			var rack_len := cl - 0.9
			for sz in [-1.0, 1.0]:
				Kit.add_box(root, Vector3(cx, top_y + ch + 0.09, sz * W * 0.32), Vector3(rack_len, 0.04, 0.05), chrome, false, 0.0, true)
			if shape == "suv" or shape == "bigsuv":
				Kit.add_box(root, Vector3(-L * 0.5 - 0.1, floor_y + 0.5, 0.0), Vector3(0.18, 0.55, 0.5), dark, false, 0.0, true)
		"limo":
			Kit.add_box(root, Vector3(L * 0.5 - 0.02, top_y - 0.05, 0), Vector3(0.05, 0.05, 0.05), chrome, false, 0.0, true)
			Kit.add_box(root, Vector3(0, top_y - 0.3, W * 0.5 + 0.01), Vector3(L * 0.8, 0.03, 0.02), chrome, false, 0.0, true)
		"gt":
			var sp := Kit.add_box(root, Vector3(-L * 0.5 + 0.2, top_y + 0.12, 0), Vector3(0.5, 0.04, W * 0.8), paint, false, 0.0, true)
			sp.rotation_degrees.z = 8.0
		"roadster":
			for sz in [-1.0, 1.0]:
				Kit.add_cylinder(root, Vector3(cx - 0.55, top_y + 0.32, sz * 0.35), 0.05, 0.6, chrome, false, 8, true)
		"super":
			for sz in [-1.0, 1.0]:
				Kit.add_box(root, Vector3(-L * 0.5 + 0.3, top_y + 0.32, sz * W * 0.38), Vector3(0.06, 0.34, 0.06), dark, false, 0.0, true)
			Kit.add_box(root, Vector3(-L * 0.5 + 0.2, top_y + 0.5, 0), Vector3(0.7, 0.05, W * 0.92), dark, false, 0.0, true)
			Kit.add_box(root, Vector3(L * 0.5 - 0.3, floor_y + 0.1, 0), Vector3(0.7, 0.04, W * 0.9), dark, false, 0.0, true)
			for sz in [-1.0, 1.0]:
				Kit.add_box(root, Vector3(-0.3, floor_y + 0.28, sz * (W * 0.5 + 0.01)), Vector3(0.9, 0.12, 0.03), dark, false, 0.0, true)
		"coupe":
			Kit.add_box(root, Vector3(-L * 0.5 + 0.2, top_y + 0.07, 0), Vector3(0.35, 0.03, W * 0.6), paint, false, 0.0, true)
		"hatch":
			Kit.add_box(root, Vector3(-L * 0.5 + 0.12, top_y + ch * 0.8, 0), Vector3(0.05, 0.06, W * 0.6), dark, false, 0.0, true)
