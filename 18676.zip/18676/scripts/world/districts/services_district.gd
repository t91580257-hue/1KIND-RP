extends "res://scripts/world/districts/district.gd"
## Сервисы Ванбурга (этап 3): полиция, больница, заправки, СТО и тюнинг,
## ломбард, рынок, магазин одежды, бизнес-точки, ферма, карьер, военная база,
## чёрный рынок, флаги банд и точка гонок.

const Kit = preload("res://scripts/world/world_kit.gd")
const Points = preload("res://scripts/world/job_points.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")


func build() -> void:
		name = "Services"
		_build_police_station()
		_build_hospital()
		_build_fuel_stations()
		_build_service_station()
		_build_pawnshop()
		_build_market()
		_build_clothing_shop()
		_build_business_stalls()
		_build_farm()
		_build_quarry()
		_build_forest_camp()
		_build_army_base()
		_build_black_market()
		_build_gang_flags()
		_build_race_point()


func _yaw_toward(origin: Vector3, target: Vector3) -> float:
		var d := target - origin
		return rad_to_deg(atan2(d.x, d.z))


# ---------------------------------------------------------------- полиция и больница

func _build_police_station() -> void:
		var p := Points.POLICE_STATION
		var root := Kit.add_building(self, p, Vector3(18, 8, 12), Color(0.82, 0.87, 0.96), 0.0, false)
		Kit.add_label(root, "ПОЛИЦИЯ ВАНБУРГА", Vector3(0, 6.4, 6.15), 0.022, Color("6fb8ff"))
		# Синий козырёк и щит на фасаде.
		Kit.add_box(root, Vector3(0, 2.9, 6.4), Vector3(4.2, 0.25, 1.5), Kit.color_mat(Color("1e5fd6"), 0.4, 0.4), false)
		Kit.add_box(root, Vector3(0, 5.0, 6.1), Vector3(1.4, 1.4, 0.1), Kit.color_mat(Color("1e5fd6"), 0.4, 0.5), false)
		Kit.add_cylinder(root, Vector3(0, 5.0, 6.08), 0.55, 0.08, Kit.color_mat(Color("ffbe28"), 0.3, 0.7), false, 12)
		# Служебная машина у входа.
		Kit.add_car(self, p + Vector3(-9.5, 0, 10.5), 0.0, Color("1e5fd6"))
		Kit.add_interactable(self, Points.POLICE_NPC, "police_station", "Участок", "Дежурная часть", 2.8)
		Kit.add_interactable(self, p + Vector3(4.5, 0, 14.0), "police_bail", "Стойка залога", "Залог и вопросы", 2.4)


func _build_hospital() -> void:
		var p := Points.HOSPITAL
		var root := Kit.add_building(self, p, Vector3(16, 9, 12), Color(0.97, 0.97, 0.99), 0.0, false)
		Kit.add_label(root, "БОЛЬНИЦА", Vector3(0, 7.2, 6.15), 0.026, Color("ff5a5f"))
		# Красный крест.
		Kit.add_box(root, Vector3(0, 5.6, 6.12), Vector3(1.6, 0.5, 0.08), Kit.color_mat(Color("ff5a5f")), false)
		Kit.add_box(root, Vector3(0, 5.6, 6.12), Vector3(0.5, 1.6, 0.08), Kit.color_mat(Color("ff5a5f")), false)
		# Носилки-каталка у входа.
		Kit.add_box(self, p + Vector3(5.0, 0.5, 8.0), Vector3(0.9, 0.12, 2.0), Kit.color_mat(Color(0.9, 0.9, 0.95)), false)
		for off in [[-0.35, -0.8], [0.35, -0.8], [-0.35, 0.8], [0.35, 0.8]]:
				var o: Array = off
				Kit.add_cylinder(self, p + Vector3(5.0 + float(o[0]), 0.25, 8.0 + float(o[1])), 0.06, 0.5, Kit.color_mat(Color(0.3, 0.32, 0.36), 0.5, 0.6), false, 6)
		Kit.add_interactable(self, p + Vector3(0, 0, 7.6), "hospital", "Больница Ванбурга", "Приёмное отделение", 2.8)


# ---------------------------------------------------------------- заправки

func _build_fuel_stations() -> void:
		for p in Points.FUEL_STATIONS:
				_build_fuel_station(p)


func _build_fuel_station(p: Vector3) -> void:
		var root := Node3D.new()
		root.position = p
		add_child(root)
		# Площадка и навес.
		Kit.add_flat(root, 0.0, 0.0, 18.0, 14.0, 0.06, Kit.tri_mat("asphalt", 5.0, Color(0.92, 0.92, 0.96)))
		for px in [-4.5, 4.5]:
				Kit.add_cylinder(root, Vector3(px, 0.2, -2.0), 0.25, 0.4, Kit.color_mat(Color(0.8, 0.15, 0.12)), true, 10)
				Kit.add_box(root, Vector3(px, 1.1, -2.0), Vector3(0.8, 1.4, 0.6), Kit.color_mat(Color(0.92, 0.93, 0.96), 0.5), true)
				Kit.add_box(root, Vector3(px, 1.75, -2.0), Vector3(0.55, 0.3, 0.4), Kit.color_mat(Color(0.1, 0.3, 0.75)), false)
				Kit.add_label(root, "АЗС", Vector3(px, 2.4, -2.0), 0.008, Color("ffbe28"), 0.0, 48)
		for px in [-4.5, 0.0, 4.5]:
				Kit.add_cylinder(root, Vector3(px, 2.9, -2.0), 0.12, 5.6, Kit.color_mat(Color(0.55, 0.57, 0.62), 0.5, 0.6), false, 8)
		Kit.add_box(root, Vector3(0, 5.8, -2.0), Vector3(14.0, 0.35, 7.0), Kit.color_mat(Color(0.1, 0.3, 0.75), 0.6), false)
		Kit.add_box(root, Vector3(0, 5.62, -2.0), Vector3(13.4, 0.1, 6.4), Kit.emissive_mat(Color(1.0, 0.85, 0.5), 0.7), false)
		# Магазинок при АЗС.
		var shop := Kit.add_shop(root, Vector3(0, 0, 8.5), Vector3(9, 4, 6), "concrete", "АЗС 24/7", 0.0)
		shop.name = "FuelShop"
		Kit.add_interactable(root, Vector3(0, 0, 1.6), "fuel", "Заправка «Корона-Ойл»", "Заправить автомобиль", 6.0)
		Kit.add_interactable(root, Vector3(4.5, 0, 5.2), "shop", "Магазин на заправке", "Купить товары", 2.4)


# ---------------------------------------------------------------- СТО и тюнинг

func _build_service_station() -> void:
		var p := Vector3(21.0, 0, -61.0)
		var root := Kit.add_shop(self, p, Vector3(20, 7, 10), "concrete", "СТО И ТЮНИНГ «ФОРСАЖ»", 180.0)
		Kit.add_label(root, "РЕМОНТ · ТЮНИНГ · ПРОДАЖА АВТО", Vector3(0, 5.6, -5.3), 0.014, Color("6fb8ff"), 180.0)
		# Подъёмник и покрышки во дворе.
		Kit.add_box(self, p + Vector3(-11.0, 0.8, 6.0), Vector3(4.0, 0.25, 2.4), Kit.color_mat(Color(0.4, 0.42, 0.48), 0.5, 0.6), true)
		for i in range(3):
				Kit.add_cylinder(self, p + Vector3(12.0, 0.4 + 0.5 * float(i), 6.5), 0.7, 0.45, Kit.color_mat(Color(0.05, 0.05, 0.07), 0.95), true, 12)
		# Автомобили клиентов на ремонте (для работы механика).
		for cp in Points.MECHANIC_CARS:
				var broken := Kit.add_car(self, cp, 90.0, Color(0.45, 0.47, 0.5))
				Kit.add_interactable(self, cp + Vector3(0, 0, 2.6), "job:mechanic", "Ремонт авто", "Работа механика", 2.6)
		Kit.add_interactable(self, Points.TUNING_SHOP, "tuning", "СТО «Форсаж»", "Ремонт и тюнинг", 3.0)


# ---------------------------------------------------------------- ломбард и рынок

func _build_pawnshop() -> void:
		var p := Points.PAWNSHOP
		var root := Kit.add_shop(self, p, Vector3(14, 6, 8), "stone", "ЛОМБАРД «ЗОЛОТОЙ ЛОМ»", 0.0)
		Kit.add_label(root, "КУПИМ ВСЁ", Vector3(0, 5.4, 4.15), 0.016, Color("ffbe28"))
		Kit.add_interactable(self, p + Vector3(0, 0, 5.4), "pawnshop", "Ломбард «Золотой лом»", "Продать вещи", 2.8)


func _build_market() -> void:
		var p := Points.MARKET_STALL
		var root := Node3D.new()
		root.position = p
		add_child(root)
		# Навес-тент и прилавки.
		for px in [-3.0, 3.0]:
				Kit.add_cylinder(root, Vector3(px, 1.5, 0), 0.09, 3.0, Kit.color_mat(Color(0.55, 0.57, 0.62), 0.5, 0.6), true, 8)
		Kit.add_box(root, Vector3(0, 3.1, 0), Vector3(8.0, 0.2, 5.0), Kit.color_mat(Color(0.85, 0.2, 0.25), 0.8), false)
		Kit.add_box(root, Vector3(0, 3.0, 0), Vector3(8.4, 0.06, 5.4), Kit.color_mat(Color("ffbe28"), 0.7), false)
		for pz in [-1.6, 1.6]:
				Kit.add_box(root, Vector3(0, 0.85, pz), Vector3(6.0, 0.9, 1.0), Kit.tri_mat("wood", 1.5, Color(0.9, 0.78, 0.6)), true)
				var cols: Array = [Color(0.9, 0.3, 0.2), Color(0.3, 0.7, 0.4), Color(0.95, 0.8, 0.2), Color(0.2, 0.5, 0.9)]
				for k in range(6):
						Kit.add_sphere(root, Vector3(-2.2 + 0.9 * float(k), 1.5, pz), 0.18, Kit.color_mat(cols[k % cols.size()], 0.7), true, 0.8)
		Kit.add_label(root, "РЫНОК ВАНБУРГА", Vector3(0, 2.4, 2.7), 0.014, Color("ffbe28"))
		Kit.add_interactable(self, p + Vector3(0, 0, 4.0), "market", "Рынок Ванбурга", "Торговая площадка", 3.0)


# ---------------------------------------------------------------- магазин одежды

func _build_clothing_shop() -> void:
		var p := Points.CLOTHING_SHOP
		var root := Kit.add_shop(self, p, Vector3(18, 6, 12), "brick_red", "МОДА ВАНБУРГ", 0.0)
		Kit.add_label(root, "ОДЕЖДА · СТИЛЬ · КОРОНА", Vector3(0, 5.4, 6.65), 0.015, Color("ffbe28"))
		# Манекены у витрины.
		var mannequin_shirts: Array = ["c0392b", "ffbe28", "27ae60"]
		var mi := 0
		for px in [-4.0, 0.0, 4.0]:
				var mannequin := Node3D.new()
				mannequin.set_script(load("res://scripts/player/character_model.gd"))
				mannequin.position = p + Vector3(px, 0.0, 8.2)
				mannequin.rotation_degrees.y = 180.0
				add_child(mannequin)
				if mannequin.has_method("set_appearance"):
						mannequin.call("set_appearance", {"shirt": String(mannequin_shirts[mi]), "pants": "2c3e50"})
				mi += 1
		Kit.add_interactable(self, p + Vector3(0, 0, 7.6), "enter:cloth_shop", "Магазин «Мода Ванбург»", "Зайти в салон одежды", 2.8)


# ---------------------------------------------------------------- бизнес-точки

func _build_business_stalls() -> void:
		var coffee: Vector3 = Points.BUSINESS_SPOTS["coffee"]
		var croot := Node3D.new()
		croot.position = coffee
		add_child(croot)
		Kit.add_box(croot, Vector3(0, 0.9, 0), Vector3(2.6, 1.8, 1.4), Kit.tri_mat("wood", 2.0, Color(0.55, 0.4, 0.28)), true)
		Kit.add_box(croot, Vector3(0, 2.0, 0), Vector3(3.0, 0.4, 1.8), Kit.color_mat(Color("ffbe28"), 0.5), false)
		Kit.add_cylinder(croot, Vector3(0.6, 2.6, 0), 0.2, 0.5, Kit.color_mat(Color(0.2, 0.2, 0.22)), false, 10)
		Kit.add_label(croot, "КОФЕЙНЯ", Vector3(0, 2.8, 0), 0.011, Color("ffbe28"))
		Kit.add_interactable(self, coffee + Vector3(0, 0, 2.0), "business:coffee", "Кофейня «Корона-Кофе»", "Бизнес-точка", 2.6)

		var mini: Vector3 = Points.BUSINESS_SPOTS["minimart"]
		var mroot := Node3D.new()
		mroot.position = mini
		add_child(mroot)
		Kit.add_box(mroot, Vector3(0, 1.0, 0), Vector3(3.0, 2.0, 1.6), Kit.color_mat(Color(0.1, 0.3, 0.75), 0.7), true)
		Kit.add_box(mroot, Vector3(0, 1.4, 0.85), Vector3(2.4, 0.8, 0.1), Kit.glass_mat(), false)
		Kit.add_label(mroot, "МИНИ-МАРКЕТ", Vector3(0, 2.5, 0), 0.011, Color("ffbe28"))
		Kit.add_interactable(self, mini + Vector3(0, 0, 2.2), "business:minimart", "Мини-маркет «У Фонтана»", "Бизнес-точка", 2.6)

		var wash: Vector3 = Points.BUSINESS_SPOTS["carwash"]
		var wroot := Node3D.new()
		wroot.position = wash
		add_child(wroot)
		Kit.add_flat(wroot, 0, 0, 10.0, 14.0, 0.06, Kit.tri_mat("asphalt", 5.0, Color(0.88, 0.9, 0.96)))
		for px in [-2.0, 2.0]:
				Kit.add_cylinder(wroot, Vector3(px, 1.6, 0), 0.12, 3.2, Kit.color_mat(Color(0.55, 0.57, 0.62), 0.5, 0.6), false, 8)
		Kit.add_box(wroot, Vector3(0, 3.3, 0), Vector3(7.0, 0.3, 8.0), Kit.color_mat(Color(0.1, 0.3, 0.75), 0.6), false)
		Kit.add_box(wroot, Vector3(0, 1.4, 0), Vector3(4.5, 2.8, 0.4), Kit.color_mat(Color(0.15, 0.6, 0.85), 0.7), true)
		Kit.add_label(wroot, "АВТОМОЙКА «БЛЕСК»", Vector3(0, 4.1, 0), 0.013, Color("ffbe28"))
		Kit.add_interactable(self, wash + Vector3(0, 0, 5.4), "business:carwash", "Автомойка «Блеск»", "Бизнес-точка", 2.8)


# ---------------------------------------------------------------- ферма, карьер, лес

func _build_farm() -> void:
		var barn := Kit.add_building(self, Points.FARM_BARN, Vector3(12, 7, 10), Color(0.72, 0.45, 0.25), 0.0, false)
		Kit.add_label(barn, "ФЕРМА «РАССВЕТ»", Vector3(0, 5.6, 5.15), 0.02, Color("ffbe28"))
		Kit.add_prism(self, Points.FARM_BARN + Vector3(0, 8.4, 0), Vector3(13.0, 2.2, 10.6), Kit.color_mat(Color(0.35, 0.15, 0.1), 0.7))
		Kit.add_interactable(self, Points.FARM_BARN + Vector3(0, 0, 7.0), "job:farmer", "Ферма «Рассвет»", "Работа на ферме", 3.0)
		# Грядки.
		var soil := Kit.tri_mat("sand", 2.0, Color(0.45, 0.32, 0.2))
		var green := Kit.color_mat(Color(0.2, 0.55, 0.25), 0.9)
		for plot in Points.FARM_PLOTS:
				Kit.add_box(self, plot + Vector3(0, 0.12, 0), Vector3(5.0, 0.24, 3.4), soil, false)
				for gx in [-1.6, 0.0, 1.6]:
						Kit.add_box(self, plot + Vector3(gx, 0.34, 0), Vector3(0.6, 0.3, 2.6), green, false, 0.0, true)


func _build_quarry() -> void:
		var o := Vector3(-148.0, 0.0, -106.0)
		Kit.add_flat(self, o.x, o.z, 26.0, 26.0, 0.05, Kit.tri_mat("stone", 3.0, Color(0.62, 0.6, 0.58)))
		# Валуны карьера.
		var rng := RandomNumberGenerator.new()
		rng.seed = 7777
		for i in range(8):
				var rx := o.x + rng.randf_range(-11.0, 11.0)
				var rz := o.z + rng.randf_range(-11.0, 11.0)
				Kit.add_sphere(self, Vector3(rx, 0.6, rz), rng.randf_range(1.0, 1.9), Kit.tri_mat("stone", 2.0, Color(0.55, 0.55, 0.58)), true, 0.75)
		# Рабочая руда-декор у камней заданий.
		for rock in Points.QUARRY_ROCKS:
				Kit.add_sphere(self, rock + Vector3(0, 0.55, 0), 1.35, Kit.tri_mat("stone", 2.0, Color(0.52, 0.52, 0.56)), true, 0.8)
		# Будка весовщика.
		Kit.add_box(self, o + Vector3(0, 1.4, 12.0), Vector3(3.0, 2.8, 2.6), Kit.color_mat(Color(0.16, 0.28, 0.42), 0.8), true)
		Kit.add_interactable(self, Points.RAW_DEPOT, "raw_depot", "Приёмка сырья", "Сдать камень, руду и брёвна", 3.0)
		Kit.add_interactable(self, o + Vector3(6.0, 0, 12.0), "job:miner", "Карьер «Каменный пояс»", "Работа шахтёра", 3.0)


func _build_forest_camp() -> void:
		var o := Vector3(-250.0, 0.0, 38.0)
		# Помеченные деревья лесоруба (визуально крупнее).
		for tree in Points.FOREST_TREES:
				Kit.add_tree(self, tree, 1.5, 0)
				Kit.add_cylinder(self, tree + Vector3(0, 0.06, 0), 1.4, 0.08, Kit.emissive_mat(Color(1.0, 0.75, 0.15), 0.5), false, 16)
		# Лагерь лесорубов: костёр и столб.
		var logs := Kit.tri_mat("wood", 1.5, Color(0.45, 0.3, 0.18))
		for a in [0.0, 2.1, 4.2]:
				var aa := a
				Kit.add_cylinder(self, o + Vector3(cos(aa) * 0.8, 0.25, sin(aa) * 0.8), 0.2, 0.5, logs, true, 8)
				var fl := Kit.add_cone(self, o + Vector3(0, 0.7, 0), 0.45, 1.1, Kit.emissive_mat(Color(1.0, 0.5, 0.1), 2.0), 6)
				fl.name = "CampFire"
		Kit.add_interactable(self, o + Vector3(3.0, 0, 0), "job:lumberjack", "Лесопилка", "Работа лесоруба", 3.0)
		Kit.add_interactable(self, Points.RAW_DEPOT + Vector3(-3.0, 0, 0), "raw_depot", "Приёмка сырья", "Сдать камень, руду и брёвна", 3.0)


# ---------------------------------------------------------------- военная база

func _build_army_base() -> void:
		var o := Points.ARMY_BASE
		var wall := Kit.tri_mat("concrete", 3.0, Color(0.62, 0.64, 0.6))
		Kit.add_box(self, o + Vector3(0, 1.5, -14), Vector3(40, 3, 1.2), wall, true)
		Kit.add_box(self, o + Vector3(0, 1.5, 14), Vector3(14, 3, 1.2), wall, true)
		Kit.add_box(self, o + Vector3(-20, 1.5, 0), Vector3(1.2, 3, 27), wall, true)
		Kit.add_box(self, o + Vector3(20, 1.5, 0), Vector3(1.2, 3, 27), wall, true)
		# Казарма и вышка.
		var barracks := Kit.add_building(self, o + Vector3(-8, 0, 4), Vector3(16, 5, 10), Color(0.55, 0.6, 0.52), 0.0, false)
		Kit.add_label(barracks, "В/Ч 1К-2026", Vector3(0, 3.6, 5.15), 0.018, Color("c0c4cc"))
		Kit.add_box(self, o + Vector3(12, 2.5, 6), Vector3(0.7, 5.0, 0.7), wall, true)
		Kit.add_box(self, o + Vector3(12, 5.4, 6), Vector3(3.0, 0.8, 3.0), Kit.color_mat(Color(0.4, 0.44, 0.4)), true)
		Kit.add_cylinder(self, o + Vector3(12, 7.2, 6), 0.03, 3.4, Kit.color_mat(Color(0.85, 0.2, 0.2)), false, 6)
		Kit.add_cone(self, o + Vector3(12, 9.2, 6), 0.2, 0.5, Kit.color_mat(Color(0.85, 0.2, 0.2)), 6)
		# Палатки и техника.
		for i in range(2):
				Kit.add_prism(self, o + Vector3(4.0 + 7.0 * float(i), 1.1, -6.0), Vector3(5.0, 2.2, 4.0), Kit.color_mat(Color(0.35, 0.42, 0.3), 0.9))
		Kit.add_box(self, o + Vector3(-12, 0.9, -8), Vector3(5.5, 1.8, 2.6), Kit.color_mat(Color(0.32, 0.38, 0.3), 0.7), true)
		Kit.add_interactable(self, Points.ARMY_NPC, "job:army", "Военная база", "Служба в армии", 3.2)


# ---------------------------------------------------------------- чёрный рынок

func _build_black_market() -> void:
		var p := Points.BLACK_MARKET
		var root := Node3D.new()
		root.position = p
		add_child(root)
		# Фургон «с товарами».
		Kit.add_box(root, Vector3(0, 1.3, 0), Vector3(4.6, 2.0, 2.0), Kit.color_mat(Color(0.14, 0.16, 0.2), 0.6, 0.3), true)
		Kit.add_box(root, Vector3(0, 2.4, 0), Vector3(4.2, 0.1, 1.9), Kit.color_mat(Color(0.14, 0.16, 0.2), 0.6), false)
		for wx in [-1.5, 1.5]:
				for wz in [-0.95, 0.95]:
						var w := Kit.add_cylinder(root, Vector3(wx, 0.34, wz), 0.34, 0.24, Kit.color_mat(Color(0.05, 0.05, 0.07)), false, 10, true)
						w.rotation_degrees.x = 90.0
		# Ящики.
		Kit.add_box(root, Vector3(2.8, 0.4, 1.2), Vector3(0.8, 0.8, 0.8), Kit.tri_mat("wood", 1.5), true)
		Kit.add_box(root, Vector3(2.8, 1.2, 1.2), Vector3(0.6, 0.6, 0.6), Kit.tri_mat("wood", 1.5), false)
		var lamp := Kit.add_lamp(root, Vector3(0, 0, 2.4), 180.0)
		lamp.name = "MarketLamp"
		Kit.add_label(root, "С Т О Й !  НЕ КУРИТЬ", Vector3(0, 3.2, 0), 0.01, Color(1, 0.4, 0.3))
		Kit.add_interactable(self, p + Vector3(0, 0, 2.6), "blackmarket", "Чёрный рынок", "Тёмные делишки", 2.6)


# ---------------------------------------------------------------- банды

func _build_gang_flags() -> void:
		for gang_id in Points.GANG_FLAGS:
				var p: Vector3 = Points.GANG_FLAGS[gang_id]
				var def: Dictionary = Catalogs.GANGS[gang_id]
				var root := Node3D.new()
				root.position = p
				root.name = "GangFlag_" + gang_id
				add_child(root)
				Kit.add_cylinder(root, Vector3(0, 2.0, 0), 0.07, 4.0, Kit.color_mat(Color(0.55, 0.57, 0.62), 0.5, 0.6), true, 8)
				var flag := Kit.add_box(root, Vector3(0.8, 3.5, 0), Vector3(1.6, 1.0, 0.06), Kit.color_mat(Color(String(def["color"])), 0.8), false)
				flag.name = "FlagCloth"
				Kit.add_interactable(self, p + Vector3(0, 0, 2.2), "gang:" + gang_id, "Территория: %s" % String(def["name"]), "Захват и дань", 3.0)
				# Палатка-штаб банды.
				Kit.add_prism(self, p + Vector3(-4.0, 0.9, -2.0), Vector3(4.0, 1.8, 3.0), Kit.color_mat(Color(String(def["color"])).darkened(0.35), 0.9))


# ---------------------------------------------------------------- гонки

func _build_race_point() -> void:
		var p := Points.RACE_FOOT_START
		var root := Node3D.new()
		root.position = p
		add_child(root)
		# Стойка организатора с флагами.
		Kit.add_box(root, Vector3(0, 0.9, 0), Vector3(3.0, 1.8, 1.2), Kit.tri_mat("wood", 2.0), true)
		Kit.add_box(root, Vector3(0, 1.95, 0), Vector3(3.4, 0.3, 1.6), Kit.color_mat(Color("ffbe28"), 0.5), false)
		for px in [-2.6, 2.6]:
				Kit.add_cylinder(root, Vector3(px, 1.6, 0.4), 0.05, 3.2, Kit.color_mat(Color(0.55, 0.57, 0.62)), false, 6)
				Kit.add_box(root, Vector3(px, 2.9, 0.4), Vector3(0.8, 0.5, 0.05), Kit.color_mat(Color(0.1, 0.3, 0.75)), false)
		Kit.add_label(root, "ГОНКИ ВАНБУРГА", Vector3(0, 2.6, 0), 0.013, Color("ffbe28"))
		Kit.add_interactable(self, p + Vector3(0, 0, 2.4), "race", "Организатор гонок", "Забеги и призы", 3.0)
		# Стартовая арка.
		Kit.add_cylinder(root, Vector3(-2.5, 2.0, 2.0), 0.12, 4.0, Kit.color_mat(Color(0.85, 0.2, 0.2)), false, 8)
		Kit.add_cylinder(root, Vector3(2.5, 2.0, 2.0), 0.12, 4.0, Kit.color_mat(Color(0.85, 0.2, 0.2)), false, 8)
		Kit.add_box(root, Vector3(0, 4.1, 2.0), Vector3(5.4, 0.4, 0.3), Kit.color_mat(Color(0.85, 0.2, 0.2)), false)
