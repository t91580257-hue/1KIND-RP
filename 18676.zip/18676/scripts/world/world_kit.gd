extends RefCounted
## Набор статических помощников для построения 3D-мира Ванбурга из примитивов:
## материалы (с текстурами из ресурс-пака), коробки/цилиндры с коллизиями,
## деревья, фонари, лавочки, автомобили, знаки, остановки и т.д.
## Внешних 3D-моделей в первой версии нет — все объекты строятся кодом.

const Interactable = preload("res://scripts/world/interactable.gd")
const TEX_PATH := "res://assets/textures/"
const PROP_VIEW_DISTANCE := 120.0

static var _mat_cache: Dictionary = {}
static var _tex_cache: Dictionary = {}


# ------------------------------------------------------------------ материалы

static func tex(tex_name: String) -> Texture2D:
	if _tex_cache.has(tex_name):
		return _tex_cache[tex_name]
	var base := load("%s%s.png" % [TEX_PATH, tex_name]) as Texture2D
	var result: Texture2D = base
	# Пересобираем текстуру с мипмапами, чтобы вдалеке не было мерцания.
	if base != null:
		var img := base.get_image()
		if img != null:
			if img.is_compressed():
				img.decompress()
			img.generate_mipmaps()
			result = ImageTexture.create_from_image(img)
	_tex_cache[tex_name] = result
	return result


## Материал с текстурой из ресурс-пака. Триплонарное наложение в мировых
## координатах: текстура не растягивается на коробках любого размера.
static func tri_mat(tex_name: String, meters_per_tile: float = 4.0, tint: Color = Color.WHITE, rough: float = 0.9) -> StandardMaterial3D:
	var key := "tri:%s:%s:%s" % [tex_name, meters_per_tile, tint.to_html()]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex(tex_name)
	m.albedo_color = tint
	m.roughness = rough
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	var s := 1.0 / meters_per_tile
	m.uv1_scale = Vector3(s, s, s)
	_mat_cache[key] = m
	return m


static func color_mat(color: Color, rough: float = 0.85, metallic: float = 0.0) -> StandardMaterial3D:
	var key := "col:%s:%s:%s" % [color.to_html(), rough, metallic]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	m.metallic = metallic
	_mat_cache[key] = m
	return m


static func emissive_mat(color: Color, energy: float = 1.6) -> StandardMaterial3D:
	var key := "emi:%s:%s" % [color.to_html(), energy]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	m.emission_energy_multiplier = energy
	_mat_cache[key] = m
	return m


static func glass_mat() -> StandardMaterial3D:
	if _mat_cache.has("glass"):
		return _mat_cache["glass"]
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.35, 0.62, 0.9, 0.45)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.roughness = 0.1
	m.metallic = 0.3
	_mat_cache["glass"] = m
	return m


static func water_mat() -> StandardMaterial3D:
	if _mat_cache.has("water"):
		return _mat_cache["water"]
	var m := tri_mat("water", 3.0, Color(0.85, 0.95, 1.0), 0.15).duplicate() as StandardMaterial3D
	m.metallic = 0.25
	_mat_cache["water"] = m
	return m


static func lane_mat(length: float) -> StandardMaterial3D:
	var key := "lane:%s" % length
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex("lane_dashes")
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	m.alpha_scissor_threshold = 0.5
	m.uv1_scale = Vector3(1.0, length / 24.0, 1.0)
	m.roughness = 0.9
	_mat_cache[key] = m
	return m


## Фасад многоэтажки: процедурная текстура «этаж с окном» 4x4 м.
static func facade_mat(tint: Color = Color.WHITE) -> StandardMaterial3D:
	var key := "facade:%s" % tint.to_html()
	if _mat_cache.has(key):
		return _mat_cache[key]
	if not _tex_cache.has("facade"):
		var s := 128
		var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
		img.fill(Color(0.80, 0.82, 0.86))
		img.fill_rect(Rect2i(30, 30, 68, 72), Color(0.95, 0.95, 0.97))
		img.fill_rect(Rect2i(35, 35, 58, 62), Color(0.20, 0.34, 0.52))
		img.fill_rect(Rect2i(35, 35, 58, 14), Color(0.36, 0.55, 0.76))
		img.fill_rect(Rect2i(62, 35, 4, 62), Color(0.95, 0.95, 0.97))
		img.fill_rect(Rect2i(26, 102, 76, 6), Color(0.58, 0.60, 0.66))
		img.fill_rect(Rect2i(0, 0, s, 4), Color(0.60, 0.62, 0.68))
		img.generate_mipmaps()
		_tex_cache["facade"] = ImageTexture.create_from_image(img)
	var m := StandardMaterial3D.new()
	m.albedo_texture = _tex_cache["facade"]
	m.albedo_color = tint
	m.roughness = 0.8
	m.uv1_triplanar = true
	m.uv1_world_triplanar = true
	m.uv1_scale = Vector3(0.25, 0.25, 0.25)
	_mat_cache[key] = m
	return m


# ------------------------------------------------------------------ примитивы

static func _finish_mesh(mi: MeshInstance3D, mat: Material, far: bool) -> void:
	mi.material_override = mat
	if far:
		mi.visibility_range_end = PROP_VIEW_DISTANCE
		mi.visibility_range_end_margin = 10.0
		mi.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_DISABLED


static func _add_body(mi: MeshInstance3D, shape: Shape3D, offset: Vector3 = Vector3.ZERO) -> void:
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position = offset
	body.add_child(cs)
	mi.add_child(body)


static func add_box(parent: Node, pos: Vector3, size: Vector3, mat: Material, collide: bool = true, rot_y: float = 0.0, far: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	_finish_mesh(mi, mat, far)
	mi.position = pos
	mi.rotation_degrees.y = rot_y
	parent.add_child(mi)
	if collide:
		var shape := BoxShape3D.new()
		shape.size = size
		_add_body(mi, shape)
	return mi


static func add_cylinder(parent: Node, pos: Vector3, radius: float, height: float, mat: Material, collide: bool = true, segments: int = 16, far: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = segments
	cm.rings = 1
	mi.mesh = cm
	_finish_mesh(mi, mat, far)
	mi.position = pos
	parent.add_child(mi)
	if collide:
		var shape := CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		_add_body(mi, shape)
	return mi


static func add_cone(parent: Node, pos: Vector3, radius: float, height: float, mat: Material, segments: int = 8, far: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = radius
	cm.height = height
	cm.radial_segments = segments
	cm.rings = 1
	mi.mesh = cm
	_finish_mesh(mi, mat, far)
	mi.position = pos
	parent.add_child(mi)
	return mi


static func add_sphere(parent: Node, pos: Vector3, radius: float, mat: Material, far: bool = false, squash: float = 1.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = radius
	sm.height = radius * 2.0
	sm.radial_segments = 12
	sm.rings = 6
	mi.mesh = sm
	_finish_mesh(mi, mat, far)
	mi.position = pos
	mi.scale = Vector3(1.0, squash, 1.0)
	parent.add_child(mi)
	return mi


static func add_prism(parent: Node, pos: Vector3, size: Vector3, mat: Material, rot_y: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var pm := PrismMesh.new()
	pm.size = size
	mi.mesh = pm
	_finish_mesh(mi, mat, false)
	mi.position = pos
	mi.rotation_degrees.y = rot_y
	parent.add_child(mi)
	return mi


static func add_label(parent: Node, text: String, pos: Vector3, pixel_size: float = 0.01, color: Color = Color.WHITE, rot_y: float = 0.0, font_size: int = 64) -> Label3D:
	var l := Label3D.new()
	l.text = text
	l.font_size = font_size
	l.pixel_size = pixel_size
	l.modulate = color
	l.outline_size = 10
	l.outline_modulate = Color(0.02, 0.05, 0.12)
	l.double_sided = true
	l.position = pos
	l.rotation_degrees.y = rot_y
	l.visibility_range_end = 70.0
	parent.add_child(l)
	return l


static func add_interactable(parent: Node, pos: Vector3, action_id: String, title: String, prompt: String, radius: float = 2.6) -> Node3D:
	var it := Interactable.new()
	it.action_id = action_id
	it.title = title
	it.prompt = prompt
	it.radius = radius
	it.position = pos
	parent.add_child(it)
	return it


# ------------------------------------------------------------------ поверхности

static func add_ground(root: Node3D) -> void:
	add_box(root, Vector3(0, -0.5, 0), Vector3(2000, 1, 2000), tri_mat("grass", 6.0, Color(0.85, 0.95, 0.8)), true)


## Плоский визуальный слой без коллизий (дорога, тротуар). Верх на высоте top.
static func add_flat(parent: Node, cx: float, cz: float, sx: float, sz: float, top: float, mat: Material) -> MeshInstance3D:
	return add_box(parent, Vector3(cx, top * 0.5, cz), Vector3(sx, top, sz), mat, false)


## Пунктирная осевая линия. along_x = true — линия идёт вдоль оси X.
static func add_lane_line(parent: Node, cx: float, cz: float, length: float, along_x: bool) -> void:
	var size := Vector3(3.0, 0.01, length)
	var mi := add_box(parent, Vector3(cx, 0.052, cz), size, lane_mat(length), false)
	if along_x:
		mi.rotation_degrees.y = 90.0
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF


# ------------------------------------------------------------------ здания

## Многоэтажка/здание. Возвращает корневой Node3D (начало координат — центр
## основания; лицевая сторона направлена в +Z, при rot_y = 0).
static func add_building(parent: Node, pos: Vector3, size: Vector3, tint: Color, rot_y: float = 0.0, roof_extras: bool = true) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	add_box(root, Vector3(0, size.y * 0.5, 0), size, facade_mat(tint), true)
	add_box(root, Vector3(0, size.y + 0.25, 0), Vector3(size.x + 0.6, 0.5, size.z + 0.6), tri_mat("concrete", 3.0, Color(0.8, 0.8, 0.85)), true)
	if roof_extras:
		add_box(root, Vector3(size.x * 0.2, size.y + 1.1, -size.z * 0.15), Vector3(2.4, 1.2, 2.0), color_mat(Color(0.45, 0.47, 0.52)), true)
		add_box(root, Vector3(-size.x * 0.25, size.y + 0.9, size.z * 0.1), Vector3(1.6, 0.8, 1.6), color_mat(Color(0.5, 0.52, 0.56)), true)
	# Входная группа: дверь и золотой козырёк.
	var front := size.z * 0.5
	add_box(root, Vector3(0, 1.3, front + 0.05), Vector3(2.4, 2.6, 0.12), color_mat(Color(0.08, 0.16, 0.32), 0.4, 0.2), false)
	add_box(root, Vector3(0, 2.85, front + 0.6), Vector3(3.4, 0.2, 1.3), color_mat(Color("ffbe28"), 0.4, 0.5), false)
	return root


## Магазин: низкое здание с витриной, вывеской и золотым козырьком.
static func add_shop(parent: Node, pos: Vector3, size: Vector3, wall_tex: String, sign_text: String, rot_y: float = 0.0) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var front := size.z * 0.5
	add_box(root, Vector3(0, size.y * 0.5, 0), size, tri_mat(wall_tex, 3.0), true)
	add_box(root, Vector3(0, size.y + 0.2, 0), Vector3(size.x + 0.5, 0.4, size.z + 0.5), color_mat(Color(0.18, 0.22, 0.32)), true)
	add_box(root, Vector3(0, 1.7, front + 0.04), Vector3(size.x - 3.0, 2.6, 0.1), glass_mat(), false)
	add_box(root, Vector3(0, 1.7, front + 0.02), Vector3(size.x - 2.7, 2.9, 0.06), color_mat(Color(0.08, 0.16, 0.32)), false)
	add_box(root, Vector3(0, size.y - 0.9, front + 0.5), Vector3(size.x - 1.0, 1.3, 0.25), color_mat(Color(0.06, 0.14, 0.34)), false)
	add_box(root, Vector3(0, 3.5, front + 1.0), Vector3(size.x - 2.0, 0.15, 2.0), color_mat(Color("ffbe28"), 0.4, 0.5), false)
	add_label(root, sign_text, Vector3(0, size.y - 0.9, front + 0.66), 0.012, Color("ffbe28"))
	return root


# ------------------------------------------------------------------ растительность

static func add_tree(parent: Node, pos: Vector3, scale_f: float = 1.0, variant: int = 0) -> void:
	var trunk := add_cylinder(parent, pos + Vector3(0, 1.2 * scale_f, 0), 0.22 * scale_f, 2.4 * scale_f, tri_mat("wood", 1.5), true, 8, true)
	trunk.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var greens: Array = [Color(0.16, 0.45, 0.22), Color(0.22, 0.52, 0.2), Color(0.12, 0.38, 0.28)]
	var green: Color = greens[variant % greens.size()]
	var crown_mat := color_mat(green, 0.95)
	if variant % 2 == 0:
		add_sphere(parent, pos + Vector3(0, 3.7 * scale_f, 0), 1.7 * scale_f, crown_mat, true, 1.1)
	else:
		add_cone(parent, pos + Vector3(0, 3.5 * scale_f, 0), 1.6 * scale_f, 3.0 * scale_f, crown_mat, 8, true)
		add_cone(parent, pos + Vector3(0, 4.7 * scale_f, 0), 1.2 * scale_f, 2.4 * scale_f, crown_mat, 8, true)


static func add_bush(parent: Node, pos: Vector3, scale_f: float = 1.0) -> void:
	add_sphere(parent, pos + Vector3(0, 0.4 * scale_f, 0), 0.7 * scale_f, color_mat(Color(0.18, 0.5, 0.24), 0.95), true, 0.75)


## Уличный фонарь (эмиссивная лампа, без реального источника света).
static func add_lamp(parent: Node, pos: Vector3, rot_y: float = 0.0) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var metal := color_mat(Color(0.15, 0.17, 0.22), 0.5, 0.6)
	add_cylinder(root, Vector3(0, 2.75, 0), 0.08, 5.5, metal, true, 8, true)
	add_box(root, Vector3(0.6, 5.5, 0), Vector3(1.3, 0.1, 0.12), metal, false, 0.0, true)
	add_box(root, Vector3(1.15, 5.4, 0), Vector3(0.5, 0.14, 0.3), emissive_mat(Color(1.0, 0.85, 0.5), 2.2), false, 0.0, true)
	add_cylinder(root, Vector3(0, 0.15, 0), 0.2, 0.3, metal, false, 8, true)


static func add_bench(parent: Node, pos: Vector3, rot_y: float = 0.0) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var wood := tri_mat("wood", 1.5, Color(0.9, 0.75, 0.55))
	var metal := color_mat(Color(0.12, 0.2, 0.4), 0.5, 0.5)
	add_box(root, Vector3(0, 0.5, 0), Vector3(1.8, 0.08, 0.5), wood, true, 0.0, true)
	add_box(root, Vector3(0, 0.85, -0.22), Vector3(1.8, 0.4, 0.06), wood, false, 0.0, true)
	add_box(root, Vector3(-0.8, 0.25, 0), Vector3(0.08, 0.5, 0.45), metal, false, 0.0, true)
	add_box(root, Vector3(0.8, 0.25, 0), Vector3(0.08, 0.5, 0.45), metal, false, 0.0, true)


## Корона (символ 1KIND RP): золотое кольцо и пять зубцов с шариками.
static func add_crown(parent: Node, pos: Vector3, scale_f: float = 1.0) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.scale = Vector3(scale_f, scale_f, scale_f)
	parent.add_child(root)
	var gold := color_mat(Color("ffbe28"), 0.3, 0.7)
	add_cylinder(root, Vector3(0, 0.15, 0), 0.55, 0.3, gold, false, 16)
	for i in range(5):
		var a := TAU * float(i) / 5.0
		var p := Vector3(cos(a) * 0.42, 0.55, sin(a) * 0.42)
		add_cone(root, p, 0.17, 0.55, gold, 6)
		add_sphere(root, p + Vector3(0, 0.34, 0), 0.07, emissive_mat(Color(1, 0.95, 0.8), 0.6))
	return root


# ------------------------------------------------------------------ транспорт, знаки, остановки

## Припаркованный автомобиль. Перед автомобиля направлен в +X при rot_y = 0.
static func add_car(parent: Node, pos: Vector3, rot_y: float, color: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var paint := color_mat(color, 0.35, 0.5)
	var body := add_box(root, Vector3(0, 0.62, 0), Vector3(4.2, 0.7, 1.8), paint, false, 0.0, true)
	add_box(root, Vector3(-0.2, 1.22, 0), Vector3(2.3, 0.55, 1.6), glass_mat(), false, 0.0, true)
	add_box(root, Vector3(-0.2, 1.52, 0), Vector3(2.2, 0.08, 1.55), paint, false, 0.0, true)
	var wheel_mat := color_mat(Color(0.05, 0.05, 0.07), 0.9)
	for wx in [-1.3, 1.3]:
		for wz in [-0.9, 0.9]:
			var w := add_cylinder(root, Vector3(wx, 0.33, wz), 0.34, 0.24, wheel_mat, false, 10, true)
			w.rotation_degrees.x = 90.0
	add_box(root, Vector3(2.11, 0.7, 0.55), Vector3(0.06, 0.18, 0.3), emissive_mat(Color(1, 0.97, 0.85), 1.2), false, 0.0, true)
	add_box(root, Vector3(2.11, 0.7, -0.55), Vector3(0.06, 0.18, 0.3), emissive_mat(Color(1, 0.97, 0.85), 1.2), false, 0.0, true)
	add_box(root, Vector3(-2.11, 0.7, 0.55), Vector3(0.06, 0.16, 0.3), emissive_mat(Color(1, 0.15, 0.15), 1.0), false, 0.0, true)
	add_box(root, Vector3(-2.11, 0.7, -0.55), Vector3(0.06, 0.16, 0.3), emissive_mat(Color(1, 0.15, 0.15), 1.0), false, 0.0, true)
	var shape := BoxShape3D.new()
	shape.size = Vector3(4.2, 1.5, 1.8)
	_add_body(body, shape, Vector3(0, 0.3, 0))


## Дорожный знак. kind: stop | parking | speed | street
static func add_sign(parent: Node, pos: Vector3, kind: String, rot_y: float = 0.0, text: String = "") -> void:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var metal := color_mat(Color(0.55, 0.57, 0.62), 0.5, 0.6)
	add_cylinder(root, Vector3(0, 1.4, 0), 0.04, 2.8, metal, true, 6, true)
	match kind:
		"stop":
			var oct := add_cylinder(root, Vector3(0, 2.5, 0.05), 0.38, 0.04, color_mat(Color(0.8, 0.08, 0.1)), false, 8, true)
			oct.rotation_degrees = Vector3(90, 22.5, 0)
			add_label(root, "СТОП", Vector3(0, 2.5, 0.09), 0.0035, Color.WHITE, 0.0, 64)
		"parking":
			add_box(root, Vector3(0, 2.5, 0.05), Vector3(0.7, 0.7, 0.04), color_mat(Color(0.1, 0.3, 0.75)), false, 0.0, true)
			add_label(root, "P", Vector3(0, 2.5, 0.09), 0.009, Color.WHITE, 0.0, 64)
		"speed":
			var ring := add_cylinder(root, Vector3(0, 2.5, 0.05), 0.4, 0.04, color_mat(Color(0.8, 0.08, 0.1)), false, 16, true)
			ring.rotation_degrees.x = 90.0
			var face := add_cylinder(root, Vector3(0, 2.5, 0.075), 0.3, 0.04, color_mat(Color(0.96, 0.96, 0.96)), false, 16, true)
			face.rotation_degrees.x = 90.0
			add_label(root, "40", Vector3(0, 2.5, 0.11), 0.007, Color(0.05, 0.05, 0.08), 0.0, 64)
		"street":
			add_box(root, Vector3(0, 2.75, 0.06), Vector3(2.0, 0.45, 0.06), color_mat(Color(0.05, 0.4, 0.28)), false, 0.0, true)
			add_label(root, text, Vector3(0, 2.75, 0.1), 0.0045, Color.WHITE, 0.0, 64)


## Автобусная остановка. Открытая сторона направлена в +Z при rot_y = 0.
static func add_bus_stop(parent: Node, pos: Vector3, stop_name: String, rot_y: float = 0.0) -> Node3D:
	var root := Node3D.new()
	root.position = pos
	root.rotation_degrees.y = rot_y
	parent.add_child(root)
	var metal := color_mat(Color(0.12, 0.2, 0.4), 0.5, 0.5)
	add_cylinder(root, Vector3(-1.6, 1.3, -0.7), 0.06, 2.6, metal, true, 8, true)
	add_cylinder(root, Vector3(1.6, 1.3, -0.7), 0.06, 2.6, metal, true, 8, true)
	add_box(root, Vector3(0, 2.65, -0.2), Vector3(3.6, 0.12, 1.8), color_mat(Color(0.1, 0.35, 0.8), 0.5, 0.3), false, 0.0, true)
	add_box(root, Vector3(0, 1.3, -0.72), Vector3(3.2, 2.2, 0.05), glass_mat(), false, 0.0, true)
	add_bench(root, Vector3(0, 0, -0.35))
	add_cylinder(root, Vector3(2.4, 1.5, 0.3), 0.04, 3.0, metal, true, 6, true)
	add_box(root, Vector3(2.4, 3.1, 0.3), Vector3(1.5, 0.55, 0.06), color_mat(Color(0.1, 0.35, 0.8)), false, 0.0, true)
	add_label(root, stop_name, Vector3(2.4, 3.1, 0.35), 0.0042, Color("ffbe28"), 0.0, 64)
	return root
