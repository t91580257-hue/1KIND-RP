extends CharacterBody3D
## Управляемый автомобиль (аркадная физика для мобильных устройств).
## Вход/выход игрока, расход топлива, урон при ударах, тюнинг (визуал + характеристики).
## Перед автомобиля направлен в +X (как в car_factory.gd).

const CarFactory = preload("res://scripts/world/car_factory.gd")
const Kit = preload("res://scripts/world/world_kit.gd")

signal exited(car: Node3D)

var car_uid: String = ""
var car_id: String = "vanbi"
var color_hex: String = "d94b3f"

## Ввод вождения (заполняет мир из TouchControls/клавиатуры).
var steer_input: float = 0.0     # -1 лево .. +1 право
var throttle: float = 0.0        # 0..1 газ
var brake: float = 0.0           # 0..1 тормоз/назад

var fuel: float = 40.0
var damage: float = 0.0
var top_speed: float = 40.0      # м/с
var accel_power: float = 8.0     # м/с^2
var steer_rate: float = 1.6
var grip: float = 10.0

var driven: bool = false         # true — игрок за рулём
var _wheels: Array = []
var _front_wheels: Array = []
var _body_node: Node3D
var _smoke: MeshInstance3D
var _t: float = 0.0
var _prev_speed: float = 0.0


func _ready() -> void:
	collision_layer = 1
	collision_mask = 1
	var entry := GameState.car_by_uid(car_uid)
	var def: Dictionary = Catalogs.CARS.get(car_id, {})
	fuel = float(entry.get("fuel", def.get("tank", 40))) if not entry.is_empty() else float(def.get("tank", 40))
	damage = float(entry.get("damage", 0.0)) if not entry.is_empty() else 0.0
	# Характеристики из каталога + тюнинг.
	var tune: Dictionary = entry.get("tuning", {}) if not entry.is_empty() else {}
	top_speed = float(def.get("top_speed", 160)) / 3.6
	accel_power = 27.78 / maxf(2.5, float(def.get("accel", 12.0)))
	steer_rate = 1.1 + 0.09 * float(def.get("handling", 6))
	if tune.has("spoiler"):
		steer_rate += 0.16
	if tune.has("exhaust"):
		accel_power *= 1.08
	if damage > 60.0:
		top_speed *= 0.72
		accel_power *= 0.85

	var shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	var len_b: float = 4.3
	var wid: float = 1.9
	var hei: float = 1.5
	if def.has("shape"):
		var prof: Dictionary = CarFactory.PROFILES.get(String(def["shape"]), {})
		len_b = float(prof.get("l", 4.3))
		wid = float(prof.get("w", 1.9))
		hei = float(prof.get("h", 0.65)) + float(prof.get("ch", 0.55)) + 0.35
	box.size = Vector3(len_b, hei, wid)
	shape.shape = box
	shape.position = Vector3(0, hei * 0.5, 0)
	add_child(shape)

	_body_node = Node3D.new()
	add_child(_body_node)
	var visual := CarFactory.build(car_id, color_hex)
	visual.name = "Visual"
	_body_node.add_child(visual)
	_apply_tuning_visual(visual, tune)

	# Колёса-визуалы (физика аркадная, колёса только крутятся).
	var wr: float = 0.33
	var wheel_mat := Kit.color_mat(Color(0.04, 0.04, 0.05), 0.95)
	var rim_col := Color(0.75, 0.78, 0.82)
	if tune.has("rims"):
		rim_col = Color("ffbe28")
	var rim_mat := Kit.color_mat(rim_col, 0.25, 0.9)
	var wheel_x: float = len_b * 0.5 - wr - 0.28
	for wx in [-wheel_x, wheel_x]:
		for wz in [-(wid * 0.5 - 0.08), wid * 0.5 - 0.08]:
			var steer := Node3D.new()
			steer.position = Vector3(wx, wr, wz)
			_body_node.add_child(steer)
			var pivot := Node3D.new()
			steer.add_child(pivot)
			var tire := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = wr
			cm.bottom_radius = wr
			cm.height = 0.24
			cm.radial_segments = 12
			tire.mesh = cm
			tire.material_override = wheel_mat
			tire.rotation_degrees.x = 90.0
			pivot.add_child(tire)
			var hub := MeshInstance3D.new()
			var hm := CylinderMesh.new()
			hm.top_radius = wr * 0.5
			hm.bottom_radius = wr * 0.5
			hm.height = 0.26
			hm.radial_segments = 8
			hub.mesh = hm
			hub.material_override = rim_mat
			hub.rotation_degrees.x = 90.0
			pivot.add_child(hub)
			_wheels.append(pivot)
			if wx > 0.0:
				_front_wheels.append(steer)

	# Дым при сильном уроне.
	if damage > 55.0:
		_smoke = MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.25
		sm.height = 0.5
		_smoke.mesh = sm
		var smat := StandardMaterial3D.new()
		smat.albedo_color = Color(0.2, 0.2, 0.22, 0.5)
		smat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_smoke.material_override = smat
		_smoke.position = Vector3(-len_b * 0.4, 1.0, 0)
		_body_node.add_child(_smoke)


func _apply_tuning_visual(visual: Node3D, tune: Dictionary) -> void:
	if tune.has("spoiler"):
		var prof: Dictionary = CarFactory.PROFILES.get(String(Catalogs.CARS.get(car_id, {}).get("shape", "sedan")), {})
		var l: float = prof.get("l", 4.3)
		var wdt: float = prof.get("w", 1.9)
		Kit.add_box(visual, Vector3(-l * 0.5 + 0.15, 1.0, 0), Vector3(0.4, 0.05, wdt * 0.85), Kit.color_mat(Color("0a1630"), 0.4, 0.4), false, 0.0, true)
		for sz in [-1.0, 1.0]:
			Kit.add_box(visual, Vector3(-l * 0.5 + 0.15, 0.88, sz * wdt * 0.35), Vector3(0.06, 0.24, 0.06), Kit.color_mat(Color("0a1630"), 0.4, 0.4), false, 0.0, true)
	if tune.has("neon"):
		var neon := MeshInstance3D.new()
		var nm := CylinderMesh.new()
		nm.top_radius = 2.6
		nm.bottom_radius = 2.6
		nm.height = 0.02
		neon.mesh = nm
		var nmat := StandardMaterial3D.new()
		nmat.albedo_color = Color(0.12, 0.56, 1.0, 0.4)
		nmat.emission_enabled = true
		nmat.emission = Color(0.12, 0.56, 1.0)
		nmat.emission_energy_multiplier = 1.6
		nmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		neon.material_override = nmat
		neon.position = Vector3(0, 0.12, 0)
		neon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		visual.add_child(neon)


func _physics_process(delta: float) -> void:
	_t += delta
	var fwd := global_transform.basis.x
	var hvel := Vector3(velocity.x, 0, velocity.z)
	var forward_speed := hvel.dot(fwd)

	# Торможение/задний ход.
	var engine_force := 0.0
	if driven:
		engine_force = throttle * accel_power
		if brake > 0.0:
			if forward_speed > 0.5:
				engine_force = -brake * accel_power * 1.6
			else:
				engine_force = -brake * accel_power * 0.5
	if fuel <= 0.0:
		engine_force = 0.0
	# Сопротивление воздуха и качения.
	engine_force -= forward_speed * 0.35
	if absf(forward_speed) > 0.3:
		engine_force -= signf(forward_speed) * 1.2

	var new_forward := forward_speed + engine_force * delta
	new_forward = clampf(new_forward, -top_speed * 0.35, top_speed)
	# Боковое сцепление (гасим скольжение).
	var lateral := hvel - fwd * forward_speed
	var lateral_damped := lateral * maxf(0.0, 1.0 - grip * delta)
	velocity = fwd * new_forward + lateral_damped
	if not is_on_floor():
		velocity.y -= 20.0 * delta
	move_and_slide()

	# Поворот: руль работает только на ходу.
	if driven and absf(new_forward) > 0.5:
		var turn_factor := clampf(new_forward / 8.0, -1.0, 1.0)
		rotate_y(-steer_input * steer_rate * delta * turn_factor)

	# Расход топлива (л/с): расход каталога на 100 км при текущей скорости + холостой ход.
	if driven and fuel > 0.0:
		var kmh := absf(new_forward) * 3.6
		var lps := float(Catalogs.CARS.get(car_id, {}).get("fuel", 8.0)) * kmh / 100.0 / 3600.0
		fuel = maxf(0.0, fuel - (lps + 0.0015) * delta)
		if fuel <= 0.0:
			GameState.notify("Бак пуст! Заправьтесь на АЗС или вызовите эвакуатор через телефон.")

	# Урон при жёстком ударе: резкая потеря скорости.
	var speed_now := Vector3(velocity.x, 0, velocity.z).length()
	var impact := absf(_prev_speed - speed_now)
	if impact > 8.0 and driven:
		var add := clampf((impact - 8.0) * 0.55, 0.0, 14.0)
		GameState.add_car_damage(car_uid, add)
		damage = minf(100.0, damage + add)
		AudioManager.play_sfx("error")
	_prev_speed = speed_now

	# Визуал: колёса и поворот передних (рулевой узел — родитель колеса).
	var spin := new_forward * delta / 0.33
	for w2 in _wheels:
		w2.rotate_object_local(Vector3(0, 0, 1), spin)
	for fw in _front_wheels:
		fw.rotation.y = lerpf(fw.rotation.y, -steer_input * 0.45, 10.0 * delta)
	# Крен в повороте.
	_body_node.rotation.z = lerpf(_body_node.rotation.z, steer_input * clampf(new_forward * 0.006, -0.06, 0.06), 6.0 * delta)
	if _smoke != null:
		_smoke.scale = Vector3.ONE * (0.8 + sin(_t * 6.0) * 0.25)
		_smoke.position.y = 1.0 + fmod(_t * 0.7, 0.8)


func speed_kmh() -> float:
	return Vector3(velocity.x, 0, velocity.z).length() * 3.6


## Перенести состояние в профиль (при выходе/сохранении).
func sync_to_profile() -> void:
	var c := GameState.car_by_uid(car_uid)
	if c.is_empty():
		return
	c["fuel"] = fuel
	c["damage"] = damage
	GameState.save_profile()
