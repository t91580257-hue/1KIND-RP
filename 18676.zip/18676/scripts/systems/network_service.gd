extends Node
## NetworkService (автозагрузка): онлайн-режим 1KIND RP — этап 1 (реальная сеть).
##
## Транспорт: ENet (UDP, надёжные каналы) через ENetMultiplayerPeer. Сервер —
## отдельный headless-проект Godot 4.3 в `server/godot_server/` (см. README).
##
## ЧТО РЕАЛЬНО РАБОТАЕТ В ЭТАПЕ 1:
##   • подключение к серверу по адресу IP:порт (по умолчанию порт 7777);
##   • регистрация/вход НА СЕРВЕРЕ (пароль проверяет сервер, PBKDF2+соль);
##   • серверное сохранение профиля (server_data/profiles/*.json на стороне сервера);
##   • синхронизация игроков: до 50 клиентов, позиция/поворот 10 Гц, «призраки» в мире;
##   • чат через сервер (антиспам и длина текста проверяются на сервере);
##   • серверная экономика для ключевых операций: работы (job_start/job_done),
##     покупки в магазине, банкомат, продажа, недвижимость и автомобили —
##     деньги/опыт считает СЕРВЕР, клиент лишь отправляет запросы и получает профиль.
##
## ЧТО НЕ ВХОДИТ В ЭТАП 1 (честно): семьи/друзья/приглашения, аукцион, передача
## предметов, защита от читов уровня античита, шифрование WSS (пароль ходит по
## локальной сети в открытом виде — для публичных серверов нужен TLS-прокси).
## Список игроков онлайн: get_player_list().

signal connection_state_changed(online: bool)
signal chat_received(from: String, text: String)
signal auth_result(ok: bool, error: String)
signal profile_synced
signal players_changed

const PROTO_VERSION := 3
const DEFAULT_PORT := 7777
const STATE_SEND_INTERVAL := 0.1     # 10 Гц
const CHAT_COOLDOWN := 1.2

var online: bool = false             # подключён и авторизован
var connecting: bool = false
var my_server_id: int = -1
var server_addr: String = ""

var remote_players: Dictionary = {}  # id -> {"nick", "x","y","z","yaw"} (последнее полученное)
var chat_history: Array = []         # [{"from", "text"}]

var _peer: ENetMultiplayerPeer = null
var _state_timer: float = 0.0
var _chat_last: float = 0.0
var _pending_actions: Dictionary = {}  # req_id -> op (для сопоставления ответов)
var _req_seq: int = 0


func is_online() -> bool:
		return online


func mode_title() -> String:
		if online:
				return "Онлайн · %s" % server_addr
		if connecting:
				return "Подключение…"
		return "Офлайн (локальная игра)"


# ---------------------------------------------------------------- подключение

## Адрес "127.0.0.1:7777" или "192.168.1.5" (порт по умолчанию).
func connect_to_server(addr: String) -> Dictionary:
		if online or connecting:
				return {"ok": false, "error": "Уже подключены — сначала отключитесь."}
		var host := addr.strip_edges()
		var port := DEFAULT_PORT
		if host.contains(":"):
				var parts := host.split(":")
				host = parts[0]
				port = parts[1].to_int() if parts[1].is_valid_int() else DEFAULT_PORT
		if host == "" or port <= 0 or port > 65535:
				return {"ok": false, "error": "Неверный адрес сервера."}
		_peer = ENetMultiplayerPeer.new()
		var err := _peer.create_client(host, port)
		if err != OK:
				_peer = null
				return {"ok": false, "error": "Не удалось создать соединение (код %d)." % err}
		multiplayer.multiplayer_peer = _peer
		my_server_id = -1
		connecting = true
		server_addr = "%s:%d" % [host, port]
		if not multiplayer.connected_to_server.is_connected(_on_connected):
				multiplayer.connected_to_server.connect(_on_connected)
				multiplayer.connection_failed.connect(_on_connect_failed)
				multiplayer.server_disconnected.connect(_on_server_disconnected)
		return {"ok": true, "error": ""}


func disconnect_from_server() -> void:
		if _peer != null:
				_peer.close()
		_peer = null
		multiplayer.multiplayer_peer = null
		online = false
		connecting = false
		remote_players = {}
		_pending_actions = {}
		connection_state_changed.emit(false)
		players_changed.emit()


func _on_connected() -> void:
		connecting = false
		my_server_id = multiplayer.get_unique_id()
		rpc_id(1, "srv_hello", PROTO_VERSION)


func _on_connect_failed() -> void:
		connecting = false
		_cleanup_peer()
		auth_result.emit(false, "Сервер недоступен: проверьте адрес и что сервер запущен.")


func _on_server_disconnected() -> void:
		var was := online
		_cleanup_peer()
		if was:
				GameState.notify("Соединение с сервером потеряно — переход в офлайн-режим.")
		GameState.online_mode = false
		connection_state_changed.emit(false)
		players_changed.emit()


func _cleanup_peer() -> void:
		if _peer != null:
				_peer.close()
		_peer = null
		multiplayer.multiplayer_peer = null
		online = false
		connecting = false
		remote_players = {}


# ---------------------------------------------------------------- авторизация

## Регистрация на сервере. Пароль передаётся один раз по ENet (см. README про TLS).
func server_register(nick: String, password: String) -> Dictionary:
		if not online:
				return {"ok": false, "error": "Нет подключения к серверу."}
		var e := AccountManager.validate_nick(nick)
		if e != "":
				return {"ok": false, "error": e}
		e = AccountManager.validate_password(password)
		if e != "":
				return {"ok": false, "error": e}
		rpc_id(1, "srv_register", nick.strip_edges(), password)
		return {"ok": true, "error": ""}


## Вход на сервере. При успехе сервер пришлёт профиль (srv_profile).
func server_auth(nick: String, password: String) -> Dictionary:
		if not online:
				return {"ok": false, "error": "Нет подключения к серверу."}
		rpc_id(1, "srv_auth", nick.strip_edges(), password)
		return {"ok": true, "error": ""}


# ---------------------------------------------------------------- игровой поток

func _process(delta: float) -> void:
		if not online:
				return
		_state_timer += delta
		if _state_timer >= STATE_SEND_INTERVAL:
				_state_timer = 0.0
				var world := get_tree().current_scene
				var player = world.get("_player") if world != null else null
				if player != null and is_instance_valid(player):
						var gp: Vector3 = player.global_position
						var yaw: float = float(player.get("_model").rotation.y) if player.get("_model") != null else 0.0
						rpc_id(1, "srv_state", gp.x, gp.y, gp.z, yaw)


## Список игроков онлайн (для UI).
func get_player_list() -> Array:
		var out: Array = []
		for id in remote_players:
				out.append({"id": id, "nick": String(remote_players[id].get("nick", "?"))})
		return out


func send_chat(text: String) -> Dictionary:
		if not online:
				return {"ok": false, "error": "Чат работает только онлайн."}
		var t := text.strip_edges()
		if t.is_empty():
				return {"ok": false, "error": "Пустое сообщение."}
		if t.length() > 200:
				t = t.substr(0, 200)
		var now := Time.get_unix_time_from_system()
		if now - _chat_last < CHAT_COOLDOWN:
				return {"ok": false, "error": "Слишком часто — подождите секунду."}
		_chat_last = now
		rpc_id(1, "srv_chat", t)
		return {"ok": true, "error": ""}


## Запрос серверной операции экономики: op + аргументы (без денег!).
func request(op: String, args: Dictionary = {}) -> void:
		if not online:
				return
		_req_seq += 1
		rpc_id(1, "srv_action", _req_seq, op, args)


# ---------------------------------------------------------------- RPC (клиент → сервер)

@rpc("any_peer", "reliable")
func srv_hello(proto: int) -> void:
		pass


@rpc("any_peer", "reliable")
func srv_register(nick: String, password: String) -> void:
		pass


@rpc("any_peer", "reliable")
func srv_auth(nick: String, password: String) -> void:
		pass


@rpc("any_peer", "unreliable")
func srv_state(x: float, y: float, z: float, yaw: float) -> void:
		pass


@rpc("any_peer", "reliable")
func srv_chat(text: String) -> void:
		pass


@rpc("any_peer", "reliable")
func srv_action(req: int, op: String, args: Dictionary) -> void:
		pass


# ---------------------------------------------------------------- RPC (сервер → клиент)

@rpc("authority", "reliable")
func cl_hello(proto: int, max_players: int) -> void:
		online = true
		connection_state_changed.emit(true)
		_add_chat("Система", "Сервер Ванбурга: протокол %d, слотов %d." % [proto, max_players])


@rpc("authority", "reliable")
func cl_register_result(ok: bool, error: String) -> void:
		auth_result.emit(ok, error)


@rpc("authority", "reliable")
func cl_auth_result(ok: bool, error: String) -> void:
		auth_result.emit(ok, error)
		if ok:
				GameState.online_mode = true


@rpc("authority", "reliable")
func cl_profile(data: Dictionary) -> void:
		# Серверный профиль — источник истины. Применяем Snapshot.
		if data.is_empty():
				return
		GameState.apply_server_profile(data)
		profile_synced.emit()


@rpc("authority", "unreliable")
func cl_players(players: Dictionary) -> void:
		remote_players = players
		players_changed.emit()


@rpc("authority", "reliable")
func cl_chat(from: String, text: String) -> void:
		_add_chat(from, text)
		chat_received.emit(from, text)


@rpc("authority", "reliable")
func cl_action_result(req: int, op: String, ok: bool, text: String) -> void:
		if not text.is_empty():
				GameState.notify(text)
				if ok:
						AudioManager.play_sfx("coin")
				else:
						AudioManager.play_sfx("error")


func _add_chat(from: String, text: String) -> void:
		chat_history.append({"from": from, "text": text})
		while chat_history.size() > 100:
				chat_history.pop_front()
