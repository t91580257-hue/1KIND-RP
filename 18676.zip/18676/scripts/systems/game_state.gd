extends Node
## Состояние игрока и профиль (автозагрузка GameState).
## Единая экономика в рублях (₽): наличные, банковский счёт, журнал операций, налоги, штрафы.
## Показатели выживания (здоровье, голод, жажда), инвентарь со слотами и весом, автомобили в гараже.
## Профиль каждого аккаунта сохраняется в user://profiles/<sha256 никнейма>.json.
## ВАЖНО: это ЛОКАЛЬНОЕ сохранение. В онлайне все эти операции должны выполняться на сервере (см. server/).

signal balance_changed(new_balance: int)
signal xp_changed(level: int, xp: int, xp_needed: int)
signal inventory_changed
signal stats_changed
signal notification(text: String)

const Catalogs = preload("res://scripts/systems/catalogs.gd")

const CURRENCY := "₽"
const START_CASH := 15000
const START_BANK := 50000
const TAX_RATE := 0.13            # налог на зарплату (НДФЛ)
const LEDGER_MAX := 100
const PROFILE_DIR := "user://profiles"
const AUTOSAVE_INTERVAL := 30.0

const SLOT_COUNT := 30
const MAX_WEIGHT := 40.0
const GARAGE_MAX := 12
const PROFILE_VERSION := 3

## Медицинские/сервисные константы.
const HEAL_PRICE := 1500
const HEAL_PARTIAL := 40.0
const AMBULANCE_PRICE := 800
const AMBULANCE_DELAY := 15.0
const INSURANCE_PRICE := 9000
const INSURANCE_PERIOD := 1800.0     # 30 минут покрытия

## Скины/цвета для создания персонажа.
const SKIN_TONES: Array = ["f6d7b8", "f2c99a", "d9a066", "a9713d", "7c4a21"]
const HAIR_COLORS: Array = ["2b1c10", "4a2c17", "c9a227", "b0b4bc", "8e2f2f"]
const SHIRT_COLORS: Array = ["1e5fd6", "0a1630", "c0392b", "27ae60", "ffbe28", "f2f2f2", "8e44ad"]
const PANTS_COLORS: Array = ["16223f", "2c3e50", "5a4634", "7f8c8d", "1d1f24"]

const HUNGER_DECAY := 0.035       # в секунду (≈ 48 мин до нуля)
const THIRST_DECAY := 0.055       # в секунду (≈ 30 мин до нуля)
const STARVE_DAMAGE := 0.6        # здоровья в секунду при нулевом голоде/жажде
const REGEN_RATE := 0.15          # здоровья в секунду при сытости

var nickname: String = ""
var cash: int = 0
var bank: int = 0
var level: int = 1
var xp: int = 0
var play_seconds: float = 0.0
var health: float = 100.0
var hunger: float = 100.0
var thirst: float = 100.0
var slots: Array = []               # SLOT_COUNT элементов: {} (пусто) или {"id": String, "count": int}
var equipped: Dictionary = {}       # слот экипировки -> id предмета (заполняется магазинами одежды)
var owned_cars: Array = []          # [{"uid","id","color","fuel","damage","tuning":{}}]
var owned_property: Array = []      # id недвижимости
var ledger: Array = []              # [{"t": unix, "kind", "amount", "text"}]
var cooldowns: Dictionary = {}      # ключ -> unix-время готовности
var last_world_pos: Array = []      # [x, y, z] последняя позиция в городе
var session_active: bool = false

# --- Этап 3 (v0.3.0) ---
var appearance: Dictionary = {"skin": "f2c99a", "hair": "2b1c10", "shirt": "1e5fd6", "pants": "16223f", "shoes": "ffbe28"}
var passport: Dictionary = {"first": "", "last": "", "gender": "м", "birth": "01.01.2000", "city": "Ванбург", "issued": 0.0}
var job_skills: Dictionary = {}     # job_id -> int опыт навыка
var org_ranks: Dictionary = {}      # org("police"|"army") -> int ранг 1..5
var wanted: int = 0
var wanted_decay_at: float = 0.0
var jail_until: float = 0.0
var jail_reason: String = ""
var businesses: Array = []          # id бизнесов
var licenses: Array = []            # id лицензий
var apartment_items: Dictionary = {} # prop_id -> [id мебели] (мебель живёт в квартире, не в рюкзаке)
var insurance_until: float = 0.0
var active_car_uid: String = ""     # автомобиль, в котором сидит игрок
var tutorial_done: bool = false
var tutorial_step: int = 0
var race_best: Dictionary = {}      # "foot"/"car" -> лучшее время (сек)
var territories: Dictionary = {}    # gang_id -> {"owner": "gang"|"player", "captured_at", "tribute_at"}
var market_factors: Dictionary = {} # item_id -> фактор цены продажи (0.4..0.85)
var emergency_until: Dictionary = {} # ключ вызова -> unix готовности
var statistics: Dictionary = {"jobs_done": 0, "tasks_done": 0, "arrests": 0, "races_won": 0, "fish_caught": 0}

## Онлайн-режим (этап 1): при true GameState — зеркало серверного профиля.
## Деньги/опыт меняются только через подтверждение сервера (см. network_service.gd).
var online_mode: bool = false


## Применить серверный снимок профиля (источник истины в онлайн-режиме).
func apply_server_profile(data: Dictionary) -> void:
		if data.is_empty():
				return
		cash = maxi(0, int(data.get("cash", cash)))
		bank = maxi(0, int(data.get("bank", bank)))
		level = maxi(1, int(data.get("level", level)))
		xp = maxi(0, int(data.get("xp", xp)))
		play_seconds = float(data.get("play_seconds", play_seconds))
		health = clampf(float(data.get("health", 100.0)), 1.0, 100.0)
		hunger = clampf(float(data.get("hunger", 100.0)), 0.0, 100.0)
		thirst = clampf(float(data.get("thirst", 100.0)), 0.0, 100.0)
		_load_slots(data.get("slots", []))
		owned_cars = _load_cars(data.get("owned_cars", []))
		owned_property = _to_string_array(data.get("owned_property", []))
		var led: Variant = data.get("ledger", [])
		ledger = led if typeof(led) == TYPE_ARRAY else []
		appearance = _merge_str_dict(data.get("appearance", {}), appearance)
		passport = _merge_str_dict(data.get("passport", {}), passport)
		job_skills = _int_dict(data.get("job_skills", {}))
		org_ranks = _int_dict(data.get("org_ranks", {}))
		wanted = clampi(int(data.get("wanted", 0)), 0, 5)
		businesses = _to_string_array(data.get("businesses", []))
		licenses = _to_string_array(data.get("licenses", []))
		tutorial_done = bool(data.get("tutorial_done", tutorial_done))
		var apt: Variant = data.get("apartment_items", {})
		apartment_items = {}
		if typeof(apt) == TYPE_DICTIONARY:
				for k in apt.keys():
						apartment_items[String(k)] = _to_string_array(apt[k])
		for c in owned_cars:
				if not c.has("uid") or String(c.get("uid", "")) == "":
						c["uid"] = _new_car_uid(String(c["id"]))
				if not c.has("damage"):
						c["damage"] = 0.0
				if not c.has("tuning"):
						c["tuning"] = {}
		balance_changed.emit(cash)
		xp_changed.emit(level, xp, xp_needed(level))
		inventory_changed.emit()
		stats_changed.emit()

var _autosave_timer: float = 0.0
var _stats_emit_timer: float = 0.0


## Для совместимости: «баланс» в интерфейсе — наличные.
var balance: int:
		get:
				return cash


func _process(delta: float) -> void:
		if not session_active:
				return
		play_seconds += delta
		_autosave_timer += delta
		if _autosave_timer >= AUTOSAVE_INTERVAL:
				_autosave_timer = 0.0
				save_profile()
		_tick_survival(delta)


func _tick_survival(delta: float) -> void:
		hunger = maxf(0.0, hunger - HUNGER_DECAY * delta)
		thirst = maxf(0.0, thirst - THIRST_DECAY * delta)
		if hunger <= 0.0 or thirst <= 0.0:
				health = maxf(1.0, health - STARVE_DAMAGE * delta)
		elif hunger > 30.0 and thirst > 30.0:
				health = minf(100.0, health + REGEN_RATE * delta)
		_stats_emit_timer += delta
		if _stats_emit_timer >= 0.5:
				_stats_emit_timer = 0.0
				stats_changed.emit()


func xp_needed(for_level: int) -> int:
		return 100 + (for_level - 1) * 50


func fmt_money(amount: int) -> String:
		var s := str(absi(amount))
		var out := ""
		var count := 0
		for i in range(s.length() - 1, -1, -1):
				out = s[i] + out
				count += 1
				if count % 3 == 0 and i > 0:
						out = " " + out
		if amount < 0:
				out = "-" + out
		return "%s %s" % [out, CURRENCY]


func fmt_time(seconds: float) -> String:
		var total := int(seconds)
		return "%d ч %02d мин" % [total / 3600, (total % 3600) / 60]


# ---------- Сессия ----------

func start_session(nick: String, from_server: bool = false) -> void:
		nickname = nick
		_reset_profile()
		if not from_server:
				load_profile()
		session_active = true
		_autosave_timer = 0.0
		balance_changed.emit(cash)
		xp_changed.emit(level, xp, xp_needed(level))
		inventory_changed.emit()
		stats_changed.emit()


func end_session() -> void:
		if session_active and not online_mode:
				save_profile()
		session_active = false
		nickname = ""
		online_mode = false
		_reset_profile()
		if NetworkService.is_online() or NetworkService.connecting:
				NetworkService.disconnect_from_server()
		AccountManager.logout()


func _reset_profile() -> void:
		cash = START_CASH
		bank = START_BANK
		level = 1
		xp = 0
		play_seconds = 0.0
		health = 100.0
		hunger = 100.0
		thirst = 100.0
		slots = []
		for i in range(SLOT_COUNT):
				slots.append({})
		equipped = {}
		owned_cars = []
		owned_property = []
		ledger = []
		cooldowns = {}
		last_world_pos = []
		appearance = {"skin": "f2c99a", "hair": "2b1c10", "shirt": "1e5fd6", "pants": "16223f", "shoes": "ffbe28"}
		passport = {"first": "", "last": "", "gender": "м", "birth": "01.01.2000", "city": "Ванбург", "issued": 0.0}
		job_skills = {}
		org_ranks = {}
		wanted = 0
		wanted_decay_at = 0.0
		jail_until = 0.0
		jail_reason = ""
		businesses = []
		licenses = []
		apartment_items = {}
		insurance_until = 0.0
		active_car_uid = ""
		tutorial_done = false
		tutorial_step = 0
		race_best = {}
		territories = {}
		market_factors = {}
		emergency_until = {}
		statistics = {"jobs_done": 0, "tasks_done": 0, "arrests": 0, "races_won": 0, "fish_caught": 0}
		_roll_market()


func _profile_path_for(nick: String) -> String:
		return "%s/%s.json" % [PROFILE_DIR, nick.strip_edges().to_lower().sha256_text()]


func _profile_path() -> String:
		return _profile_path_for(nickname)


func save_profile() -> void:
		if nickname == "":
				return
		if online_mode:
				# В онлайн-режиме профиль хранит и сохраняет сервер.
				return
		DirAccess.make_dir_recursive_absolute(PROFILE_DIR)
		var data := {
				"version": PROFILE_VERSION,
				"nickname": nickname,
				"cash": cash,
				"bank": bank,
				"level": level,
				"xp": xp,
				"play_seconds": play_seconds,
				"health": health,
				"hunger": hunger,
				"thirst": thirst,
				"slots": slots,
				"equipped": equipped,
				"owned_cars": owned_cars,
				"owned_property": owned_property,
				"ledger": ledger,
				"cooldowns": cooldowns,
				"last_world_pos": last_world_pos,
				"appearance": appearance,
				"passport": passport,
				"job_skills": job_skills,
				"org_ranks": org_ranks,
				"wanted": wanted,
				"jail_until": jail_until,
				"jail_reason": jail_reason,
				"businesses": businesses,
				"licenses": licenses,
				"apartment_items": apartment_items,
				"insurance_until": insurance_until,
				"tutorial_done": tutorial_done,
				"tutorial_step": tutorial_step,
				"race_best": race_best,
				"territories": territories,
				"statistics": statistics,
		}
		var f := FileAccess.open(_profile_path(), FileAccess.WRITE)
		if f == null:
				push_warning("Не удалось сохранить профиль игрока.")
				return
		f.store_string(JSON.stringify(data))
		f.close()


func load_profile() -> void:
		var data := _read_profile_file(_profile_path())
		if data.is_empty():
				return
		var ver := int(data.get("version", 1))
		level = maxi(1, int(data.get("level", 1)))
		xp = maxi(0, int(data.get("xp", 0)))
		play_seconds = float(data.get("play_seconds", 0.0))
		if ver < 2:
				_migrate_v1(data)
		else:
				cash = maxi(0, int(data.get("cash", START_CASH)))
				bank = maxi(0, int(data.get("bank", START_BANK)))
				health = clampf(float(data.get("health", 100.0)), 1.0, 100.0)
				hunger = clampf(float(data.get("hunger", 100.0)), 0.0, 100.0)
				thirst = clampf(float(data.get("thirst", 100.0)), 0.0, 100.0)
				_load_slots(data.get("slots", []))
				var eq: Variant = data.get("equipped", {})
				equipped = {}
				if typeof(eq) == TYPE_DICTIONARY:
						for k in eq.keys():
								equipped[String(k)] = String(eq[k])
				owned_cars = _load_cars(data.get("owned_cars", []))
				owned_property = _to_string_array(data.get("owned_property", []))
				var led: Variant = data.get("ledger", [])
				ledger = led if typeof(led) == TYPE_ARRAY else []
				var wp: Variant = data.get("last_world_pos", [])
				last_world_pos = wp if typeof(wp) == TYPE_ARRAY and wp.size() == 3 else []
		var cds: Variant = data.get("cooldowns", {})
		cooldowns = {}
		if typeof(cds) == TYPE_DICTIONARY:
				for k in cds.keys():
						cooldowns[String(k)] = float(cds[k])
		if ver >= 3:
				appearance = _merge_str_dict(data.get("appearance", {}), appearance)
				passport = _merge_str_dict(data.get("passport", {}), passport)
				job_skills = _int_dict(data.get("job_skills", {}))
				org_ranks = _int_dict(data.get("org_ranks", {}))
				wanted = clampi(int(data.get("wanted", 0)), 0, 5)
				jail_until = float(data.get("jail_until", 0.0))
				if jail_until > 0.0 and jail_until <= Time.get_unix_time_from_system():
						jail_until = 0.0
						jail_reason = ""
				else:
						jail_reason = String(data.get("jail_reason", ""))
				businesses = _to_string_array(data.get("businesses", []))
				licenses = _to_string_array(data.get("licenses", []))
				var apt: Variant = data.get("apartment_items", {})
				apartment_items = {}
				if typeof(apt) == TYPE_DICTIONARY:
						for k in apt.keys():
								apartment_items[String(k)] = _to_string_array(apt[k])
				insurance_until = float(data.get("insurance_until", 0.0))
				tutorial_done = bool(data.get("tutorial_done", false))
				tutorial_step = maxi(0, int(data.get("tutorial_step", 0)))
				var rb: Variant = data.get("race_best", {})
				race_best = {}
				if typeof(rb) == TYPE_DICTIONARY:
						for k in rb.keys():
								race_best[String(k)] = float(rb[k])
				var tt: Variant = data.get("territories", {})
				territories = {}
				if typeof(tt) == TYPE_DICTIONARY:
						for k in tt.keys():
								var t: Variant = tt[k]
								if typeof(t) == TYPE_DICTIONARY:
										territories[String(k)] = t
				statistics = _merge_str_dict(data.get("statistics", {}), statistics)
		else:
				_roll_market()
		for c in owned_cars:
				if not c.has("uid") or String(c.get("uid", "")) == "":
						c["uid"] = _new_car_uid(String(c["id"]))
				if not c.has("damage"):
						c["damage"] = 0.0
				if not c.has("tuning"):
						c["tuning"] = {}


## Старый профиль (v0.1, валюта VB): 1 VB = 10 ₽, всё идёт на банковский счёт.
func _migrate_v1(data: Dictionary) -> void:
		cash = START_CASH
		bank = START_BANK + int(data.get("balance", 0)) * 10
		var inv: Variant = data.get("inventory", {})
		if typeof(inv) == TYPE_DICTIONARY:
				for k in inv.keys():
						add_item(String(k), int(inv[k]))
		owned_cars = []
		var old_cars := _to_string_array(data.get("owned_cars", []))
		var map := {"hatch": "vanbi", "sedan": "korona_s", "coupe": "strela"}
		for cid in old_cars:
				var new_id: String = map.get(cid, "")
				if new_id != "" and Catalogs.CARS.has(new_id):
						owned_cars.append({"id": new_id, "color": String(Catalogs.CARS[new_id]["colors"][0]), "fuel": float(Catalogs.CARS[new_id]["tank"])})
		owned_property = _to_string_array(data.get("owned_property", []))


func _read_profile_file(path: String) -> Dictionary:
		if not FileAccess.file_exists(path):
				return {}
		var f := FileAccess.open(path, FileAccess.READ)
		if f == null:
				return {}
		var parsed: Variant = JSON.parse_string(f.get_as_text())
		f.close()
		if typeof(parsed) != TYPE_DICTIONARY:
				return {}
		return parsed


func _load_slots(src: Variant) -> void:
		slots = []
		for i in range(SLOT_COUNT):
				slots.append({})
		if typeof(src) != TYPE_ARRAY:
				return
		for i in range(mini(src.size(), SLOT_COUNT)):
				var e: Variant = src[i]
				if typeof(e) == TYPE_DICTIONARY and e.has("id") and Catalogs.ITEMS.has(String(e["id"])):
						slots[i] = {"id": String(e["id"]), "count": maxi(1, int(e.get("count", 1)))}


func _load_cars(src: Variant) -> Array:
		var out: Array = []
		if typeof(src) != TYPE_ARRAY:
				return out
		for v in src:
				if typeof(v) == TYPE_DICTIONARY and Catalogs.CARS.has(String(v.get("id", ""))):
						var cid := String(v["id"])
						out.append({"id": cid, "color": String(v.get("color", Catalogs.CARS[cid]["colors"][0])), "fuel": float(v.get("fuel", Catalogs.CARS[cid]["tank"]))})
		return out


func _to_string_array(src: Variant) -> Array:
		var out: Array = []
		if typeof(src) == TYPE_ARRAY:
				for v in src:
						out.append(String(v))
		return out


func _merge_str_dict(src: Variant, fallback: Dictionary) -> Dictionary:
		var out := fallback.duplicate()
		if typeof(src) == TYPE_DICTIONARY:
				for k in src.keys():
						out[String(k)] = src[k]
		return out


func _int_dict(src: Variant) -> Dictionary:
		var out: Dictionary = {}
		if typeof(src) == TYPE_DICTIONARY:
				for k in src.keys():
						out[String(k)] = maxi(0, int(src[k]))
		return out


func _new_car_uid(car_id: String) -> String:
		return "%s_%d" % [car_id, Time.get_unix_time_from_system()] + "_%d" % (randi() % 900 + 100)


## Рыночные факторы продажи: у каждого предмета своя «котировка», обновляется при входе.
func _roll_market() -> void:
		market_factors = {}
		for id in Catalogs.SELLABLE:
				market_factors[id] = randf_range(0.42, 0.85)


func market_sell_price(item_id: String) -> int:
		var base := int(Catalogs.item_def(item_id).get("price", 0))
		if base <= 0:
				return 0
		var f := float(market_factors.get(item_id, Catalogs.SELL_FACTOR))
		return maxi(1, int(round(float(base) * f)))


# ---------- Деньги: наличные и банк ----------

func _log(kind: String, amount: int, text: String) -> void:
		ledger.push_front({"t": Time.get_unix_time_from_system(), "kind": kind, "amount": amount, "text": text})
		while ledger.size() > LEDGER_MAX:
				ledger.pop_back()


func _money_changed() -> void:
		balance_changed.emit(cash)


func add_money(amount: int, reason: String = "Поступление") -> void:
		cash += amount
		_log("cash", amount, reason)
		_money_changed()


## Списать наличные. Для обратной совместимости.
func try_spend(amount: int, reason: String = "Покупка") -> bool:
		if amount < 0 or cash < amount:
				return false
		cash -= amount
		_log("cash", -amount, reason)
		_money_changed()
		return true


func total_money() -> int:
		return cash + bank


## Оплата услуги/товара: сначала наличные, остаток — с банковской карты.
func charge(amount: int, reason: String) -> bool:
		if amount < 0 or total_money() < amount:
				return false
		var from_cash := mini(cash, amount)
		var from_bank := amount - from_cash
		cash -= from_cash
		bank -= from_bank
		if from_cash > 0:
				_log("cash", -from_cash, reason)
		if from_bank > 0:
				_log("bank", -from_bank, reason + " (карта)")
		_money_changed()
		return true


## Зачисление на банковский счёт (пособия, переводы, премии).
func credit_bank(amount: int, reason: String) -> void:
		bank += amount
		_log("bank", amount, reason)
		_money_changed()


func atm_deposit(amount: int) -> Dictionary:
		if online_mode:
				NetworkService.request("atm_deposit", {"amount": amount})
				return {"ok": true, "text": "Запрос отправлен на сервер…"}
		if amount <= 0 or cash < amount:
				return {"ok": false, "text": "Недостаточно наличных."}
		cash -= amount
		bank += amount
		_log("bank", amount, "Пополнение счёта через банкомат")
		_money_changed()
		return {"ok": true, "text": "Внесено на счёт: %s" % fmt_money(amount)}


func atm_withdraw(amount: int) -> Dictionary:
		if online_mode:
				NetworkService.request("atm_withdraw", {"amount": amount})
				return {"ok": true, "text": "Запрос отправлен на сервер…"}
		if amount <= 0 or bank < amount:
				return {"ok": false, "text": "Недостаточно средств на счёте."}
		bank -= amount
		cash += amount
		_log("bank", -amount, "Снятие наличных в банкомате")
		_money_changed()
		return {"ok": true, "text": "Снято со счёта: %s" % fmt_money(amount)}


## Перевод другому ЛОКАЛЬНОМУ аккаунту этого устройства. Это не онлайн-перевод:
## для настоящих игроков перевод обязан выполнять сервер.
func transfer_local(target_nick: String, amount: int) -> Dictionary:
		var target := target_nick.strip_edges()
		if target == "" or target.to_lower() == nickname.to_lower():
				return {"ok": false, "text": "Укажите ник другого игрока."}
		if amount <= 0 or bank < amount:
				return {"ok": false, "text": "Недостаточно средств на счёте."}
		var path := _profile_path_for(target)
		var data := _read_profile_file(path)
		if data.is_empty() or int(data.get("version", 1)) < 2:
				return {"ok": false, "text": "Игрок «%s» не найден на этом устройстве." % target}
		data["bank"] = int(data.get("bank", 0)) + amount
		var led: Array = data.get("ledger", []) if typeof(data.get("ledger", [])) == TYPE_ARRAY else []
		led.push_front({"t": Time.get_unix_time_from_system(), "kind": "bank", "amount": amount, "text": "Перевод от %s" % nickname})
		data["ledger"] = led
		var f := FileAccess.open(path, FileAccess.WRITE)
		if f == null:
				return {"ok": false, "text": "Не удалось выполнить перевод."}
		f.store_string(JSON.stringify(data))
		f.close()
		bank -= amount
		_log("bank", -amount, "Перевод игроку %s" % target)
		_money_changed()
		save_profile()
		return {"ok": true, "text": "Переведено %s игроку %s" % [fmt_money(amount), target]}


## Штраф списывается со счёта, затем с наличных. Может увести баланс в минус только на счёте.
func fine(amount: int, reason: String) -> void:
		var from_bank := mini(bank, amount)
		bank -= from_bank
		var rest := amount - from_bank
		var from_cash := mini(cash, rest)
		cash -= from_cash
		var debt := rest - from_cash
		if debt > 0:
				bank -= debt
		_log("bank", -amount, "Штраф: %s" % reason)
		_money_changed()
		notification.emit("Штраф %s: %s" % [fmt_money(amount), reason])


func pay_salary(gross: int, reason: String) -> int:
		var tax := int(round(float(gross) * TAX_RATE))
		var net := gross - tax
		bank += net
		_log("bank", net, "Зарплата: %s (налог %s)" % [reason, fmt_money(tax)])
		_money_changed()
		return net


func add_xp(amount: int) -> void:
		xp += amount
		while xp >= xp_needed(level):
				xp -= xp_needed(level)
				level += 1
				notification.emit("Новый уровень: %d!" % level)
				AudioManager.play_sfx("levelup")
		xp_changed.emit(level, xp, xp_needed(level))


func notify(text: String) -> void:
		notification.emit(text)


# ---------- Инвентарь ----------

func item_weight(item_id: String) -> float:
		return float(Catalogs.item_def(item_id).get("weight", 0.1))


func total_weight() -> float:
		var w := 0.0
		for s in slots:
				if not s.is_empty():
						w += item_weight(String(s["id"])) * float(int(s["count"]))
		return w


func item_total(item_id: String) -> int:
		var n := 0
		for s in slots:
				if not s.is_empty() and String(s["id"]) == item_id:
						n += int(s["count"])
		return n


func has_item(item_id: String, count: int = 1) -> bool:
		return item_total(item_id) >= count


## Добавляет предметы с учётом лимита веса, размера стека и свободных слотов.
## Возвращает, сколько штук реально добавлено.
func add_item(item_id: String, count: int = 1) -> int:
		if count <= 0 or not Catalogs.ITEMS.has(item_id):
				return 0
		var def := Catalogs.item_def(item_id)
		var stack := int(def.get("stack", 1))
		var unit_w := item_weight(item_id)
		var left := count
		var room_by_weight := count
		if unit_w > 0.0:
				room_by_weight = int(floor((MAX_WEIGHT - total_weight()) / unit_w + 0.0001))
		left = mini(left, maxi(0, room_by_weight))
		var added := 0
		for i in range(SLOT_COUNT):
				if left <= 0:
						break
				var s: Dictionary = slots[i]
				if not s.is_empty() and String(s["id"]) == item_id and int(s["count"]) < stack:
						var put := mini(left, stack - int(s["count"]))
						s["count"] = int(s["count"]) + put
						left -= put
						added += put
		for i in range(SLOT_COUNT):
				if left <= 0:
						break
				if slots[i].is_empty():
						var put2 := mini(left, stack)
						slots[i] = {"id": item_id, "count": put2}
						left -= put2
						added += put2
		if added > 0:
				inventory_changed.emit()
		return added


func can_add_item(item_id: String, count: int = 1) -> bool:
		# Пробное добавление без изменений состояния.
		var backup := slots.duplicate(true)
		var got := add_item(item_id, count)
		slots = backup
		inventory_changed.emit()
		return got >= count


func remove_item(item_id: String, count: int = 1) -> bool:
		if item_total(item_id) < count:
				return false
		var left := count
		for i in range(SLOT_COUNT - 1, -1, -1):
				if left <= 0:
						break
				var s: Dictionary = slots[i]
				if not s.is_empty() and String(s["id"]) == item_id:
						var take := mini(left, int(s["count"]))
						s["count"] = int(s["count"]) - take
						left -= take
						if int(s["count"]) <= 0:
								slots[i] = {}
		inventory_changed.emit()
		return true


func move_slot(from_i: int, to_i: int) -> void:
		if from_i == to_i or from_i < 0 or to_i < 0 or from_i >= SLOT_COUNT or to_i >= SLOT_COUNT:
				return
		var a: Dictionary = slots[from_i]
		var b: Dictionary = slots[to_i]
		if a.is_empty():
				return
		if not b.is_empty() and String(a["id"]) == String(b["id"]):
				var stack := int(Catalogs.item_def(String(a["id"])).get("stack", 1))
				var put := mini(int(a["count"]), stack - int(b["count"]))
				if put > 0:
						b["count"] = int(b["count"]) + put
						a["count"] = int(a["count"]) - put
						if int(a["count"]) <= 0:
								slots[from_i] = {}
		else:
				slots[from_i] = b
				slots[to_i] = a
		inventory_changed.emit()


## Разделить стек: отделяет amount штук в первый свободный слот.
func split_slot(i: int, amount: int) -> Dictionary:
		if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
				return {"ok": false, "text": "Слот пуст."}
		var s: Dictionary = slots[i]
		if amount <= 0 or amount >= int(s["count"]):
				return {"ok": false, "text": "Нельзя разделить такое количество."}
		for j in range(SLOT_COUNT):
				if slots[j].is_empty():
						s["count"] = int(s["count"]) - amount
						slots[j] = {"id": String(s["id"]), "count": amount}
						inventory_changed.emit()
						return {"ok": true, "text": "Стек разделён."}
		return {"ok": false, "text": "Нет свободных слотов."}


## Выбросить предметы из слота (предмет исчезает из инвентаря).
func drop_slot(i: int, amount: int) -> Dictionary:
		if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
				return {"ok": false, "text": "Слот пуст."}
		var s: Dictionary = slots[i]
		var id := String(s["id"])
		var n := clampi(amount, 1, int(s["count"]))
		s["count"] = int(s["count"]) - n
		if int(s["count"]) <= 0:
				slots[i] = {}
		inventory_changed.emit()
		return {"ok": true, "text": "Выброшено: %s × %d" % [Catalogs.item_name(id), n]}


## Использовать предмет из слота: еда/вода меняют голод и жажду, аптечка лечит, кейс открывается.
func use_slot(i: int) -> Dictionary:
		if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
				return {"ok": false, "text": "Слот пуст."}
		var id := String(slots[i]["id"])
		var def := Catalogs.item_def(id)
		var kind := String(def.get("kind", "misc"))
		var text := ""
		match kind:
				"food", "drink":
						if hunger >= 100.0 and float(def.get("hunger", 0.0)) > 0.0 and float(def.get("thirst", 0.0)) <= 0.0:
								return {"ok": false, "text": "Вы не голодны."}
						if thirst >= 100.0 and float(def.get("thirst", 0.0)) > 0.0 and float(def.get("hunger", 0.0)) <= 0.0:
								return {"ok": false, "text": "Вы не хотите пить."}
						hunger = clampf(hunger + float(def.get("hunger", 0.0)), 0.0, 100.0)
						thirst = clampf(thirst + float(def.get("thirst", 0.0)), 0.0, 100.0)
						text = "Использовано: %s" % String(def["name"])
				"misc":
						if def.has("heal"):
								if health >= 100.0:
										return {"ok": false, "text": "Здоровье полное."}
								health = clampf(health + float(def["heal"]), 1.0, 100.0)
								text = "Использовано: %s" % String(def["name"])
						else:
								return {"ok": false, "text": "Этот предмет нельзя использовать."}
				"case":
						text = _open_case(id)
				_:
						return {"ok": false, "text": "Этот предмет нельзя использовать."}
		remove_item_at(i, 1)
		stats_changed.emit()
		return {"ok": true, "text": text}


func remove_item_at(i: int, count: int) -> void:
		if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
				return
		var s: Dictionary = slots[i]
		s["count"] = int(s["count"]) - count
		if int(s["count"]) <= 0:
				slots[i] = {}
		inventory_changed.emit()


func _open_case(case_id: String) -> String:
		var roll := randf()
		if case_id == "case_starter":
				# Кейс новичка: гарантированно приятная награда за обучение.
				if roll < 0.6:
						var sums: Array = [2500, 3500, 5000]
						var sum: int = sums[randi() % sums.size()]
						add_money(sum, "Кейс новичка")
						return "Кейс новичка: +%s" % fmt_money(sum)
				if roll < 0.9:
						if add_item("medkit", 2) > 0 and add_item("burger", 2) > 0:
								return "Кейс новичка: аптечки и бургеры"
						add_money(3000, "Кейс новичка")
						return "Кейс новичка: +%s" % fmt_money(3000)
				add_item("gold_badge", 1)
				add_xp(20)
				return "Кейс новичка: золотой значок и +20 опыта"
		if roll < 0.55:
				var sums2: Array = [500, 1000, 1500, 2500]
				var sum2: int = sums2[randi() % sums2.size()]
				add_money(sum2, "Награда из кейса")
				return "Кейс: +%s" % fmt_money(sum2)
		if roll < 0.9:
				var pool: Array = ["sandwich", "burger", "water", "cola", "medkit"]
				var pick: String = pool[randi() % pool.size()]
				if add_item(pick, 2) > 0:
						return "Кейс: %s × 2" % Catalogs.item_name(pick)
				add_money(1000, "Награда из кейса")
				return "Инвентарь полон, кейс заменён на %s" % fmt_money(1000)
		add_xp(150)
		return "Кейс: +150 опыта"


# ---------- Покупки ----------

## kind: "shop" | "property". Автомобили покупаются через buy_car(). Возвращает {"ok": bool, "text": String}.
func buy(kind: String, item_id: String) -> Dictionary:
		if online_mode:
				NetworkService.request("buy", {"kind": kind, "item": item_id})
				return {"ok": true, "text": "Запрос отправлен на сервер…"}
		var catalog := Catalogs.get_catalog(kind)
		if not catalog.has(item_id):
				return {"ok": false, "text": "Товар не найден."}
		var entry: Dictionary = catalog[item_id]
		var price := int(entry["price"])
		if kind == "property" and owned_property.has(item_id):
				return {"ok": false, "text": "Эта недвижимость уже принадлежит вам."}
		if total_money() < price:
				return {"ok": false, "text": "Недостаточно средств."}
		match kind:
				"shop":
						if not can_add_item(item_id, 1):
								return {"ok": false, "text": "Нет места или превышен лимит веса."}
						charge(price, "Покупка: %s" % String(entry["name"]))
						add_item(item_id, 1)
				"property":
						charge(price, "Покупка: %s" % String(entry["name"]))
						owned_property.append(item_id)
						inventory_changed.emit()
				_:
						return {"ok": false, "text": "Неизвестная категория."}
		add_xp(10)
		AudioManager.play_sfx("coin")
		save_profile()
		return {"ok": true, "text": "Покупка: %s" % String(entry["name"])}


func owns_car(car_id: String) -> bool:
		for c in owned_cars:
				if String(c["id"]) == car_id:
						return true
		return false


# ---------- Работа ----------

func buy_car(car_id: String, color_hex: String) -> Dictionary:
		if online_mode:
				NetworkService.request("buy_car", {"car": car_id, "color": color_hex})
				return {"ok": true, "text": "Запрос отправлен на сервер…"}
		if not Catalogs.CARS.has(car_id):
				return {"ok": false, "text": "Автомобиль не найден."}
		var entry: Dictionary = Catalogs.CARS[car_id]
		for c in owned_cars:
				if String(c["id"]) == car_id:
						return {"ok": false, "text": "Этот автомобиль уже в вашем гараже."}
		if owned_cars.size() >= GARAGE_MAX:
				return {"ok": false, "text": "Гараж заполнен."}
		var price := int(entry["price"])
		if total_money() < price:
				return {"ok": false, "text": "Недостаточно средств."}
		var col := color_hex if entry["colors"].has(color_hex) else String(entry["colors"][0])
		charge(price, "Покупка авто: %s" % String(entry["name"]))
		owned_cars.append({"uid": _new_car_uid(car_id), "id": car_id, "color": col, "fuel": float(entry["tank"]), "damage": 0.0, "tuning": {}})
		inventory_changed.emit()
		add_xp(50)
		AudioManager.play_sfx("coin")
		save_profile()
		return {"ok": true, "text": "Автомобиль куплен и отправлен в гараж: %s" % String(entry["name"])}


# ---------- Перезарядки ----------

func cooldown_left(key: String) -> float:
		var ready_at := float(cooldowns.get(key, 0.0))
		return maxf(0.0, ready_at - Time.get_unix_time_from_system())


func start_cooldown(key: String, seconds: float) -> void:
		cooldowns[key] = Time.get_unix_time_from_system() + seconds


# ---------- Профессии: навыки и выплаты ----------

func job_skill_xp(job_id: String) -> int:
		return int(job_skills.get(job_id, 0))


func job_skill(job_id: String) -> Dictionary:
		var sx := job_skill_xp(job_id)
		return Catalogs.job_skill_progress(sx)


func add_job_skill_xp(job_id: String, amount: int) -> int:
		var before := job_skill(job_id)["level"]
		var nx := job_skill_xp(job_id) + maxi(0, amount)
		job_skills[job_id] = nx
		var after := job_skill(job_id)["level"]
		if after > before:
				notify("Навык «%s»: уровень %d — %s!" % [Catalogs.job_name(job_id), after, String(Catalogs.JOB_LEVELS[after - 1])])
				AudioManager.play_sfx("levelup")
		return nx


func org_rank(org: String) -> int:
		return clampi(int(org_ranks.get(org, 1)), 1, 5)


## Доступ к полицейским действиям (задержания): хотя бы одна отработанная смена в полиции.
func has_job_org_access() -> bool:
		return job_skill_xp("police") > 0


## Полная выплата за смену: база × навык × ранг организации, с налогом и записью в журнал.
func job_payout(job_id: String, tasks_bonus: int = 0) -> int:
		var job: Dictionary = Catalogs.JOBS[job_id]
		var skill_mult := 1.0 + 0.15 * float(job_skill(job_id)["level"] - 1)
		var pay := int(round(float(job["base_pay"]) * skill_mult)) + maxi(0, tasks_bonus)
		if job.has("org"):
				pay = int(round(float(pay) * float(Catalogs.RANK_PAY[org_rank(String(job["org"])) - 1])))
		return pay_salary(pay, String(job["name"]))


# ---------- Розыск, арест и тюрьма ----------

func is_wanted() -> bool:
		return wanted > 0 and jail_until <= Time.get_unix_time_from_system()


func add_wanted(stars: int, reason: String) -> void:
		var before := wanted
		wanted = clampi(wanted + stars, 0, 5)
		wanted_decay_at = Time.get_unix_time_from_system() + WANTED_DECAY_SEC
		if wanted > before:
				notify("Розыск: %d ★ — %s" % [wanted, reason])
				AudioManager.play_sfx("error")
		else:
				notify(reason)


func clear_wanted() -> void:
		if wanted > 0:
				wanted = 0
				notify("Розыск снят.")


func jail_seconds_left() -> float:
		return maxf(0.0, jail_until - Time.get_unix_time_from_system())


func is_jailed() -> bool:
		return jail_until > Time.get_unix_time_from_system()


func jail_time_for_current() -> float:
		return float(wanted) * JAIL_SEC_PER_STAR


func jail_serve(seconds: float, reason: String) -> void:
		jail_until = Time.get_unix_time_from_system() + seconds
		jail_reason = reason
		wanted = 0
		save_profile()


func jail_release() -> void:
		jail_until = 0.0
		jail_reason = ""


## Выход под залог (штраф) у входа в участок.
func jail_bail() -> Dictionary:
		if not is_jailed():
				return {"ok": false, "text": "Вы не в тюрьме."}
		var left := jail_seconds_left()
		var cost := int(ceil(left / JAIL_SEC_PER_STAR)) * BAIL_PER_STAR
		if not charge(cost, "Залог из тюрьмы"):
				return {"ok": false, "text": "Нужно %s на залог." % fmt_money(cost)}
		jail_release()
		notify("Вы внесли залог и вышли на свободу.")
		return {"ok": true, "text": "Выпущен под залог: %s" % fmt_money(cost)}


# ---------- Автомобили: состояние, тюнинг, страховка, штрафстоянка ----------

func car_by_uid(uid: String) -> Dictionary:
		for c in owned_cars:
				if String(c.get("uid", "")) == uid:
						return c
		return {}


func car_def_for(entry: Dictionary) -> Dictionary:
		return Catalogs.CARS.get(String(entry["id"]), {})


func car_tuning(uid: String) -> Dictionary:
		var c := car_by_uid(uid)
		return c.get("tuning", {}) if not c.is_empty() else {}


func car_has_tuning(uid: String, tune_id: String) -> bool:
		return car_tuning(uid).has(tune_id)


func buy_tuning(uid: String, tune_id: String) -> Dictionary:
		if not Catalogs.TUNING.has(tune_id):
				return {"ok": false, "text": "Услуга не найдена."}
		var c := car_by_uid(uid)
		if c.is_empty():
				return {"ok": false, "text": "Автомобиль не найден."}
		if car_has_tuning(uid, tune_id):
				return {"ok": false, "text": "Это уже установлено."}
		var t: Dictionary = Catalogs.TUNING[tune_id]
		if not charge(int(t["price"]), "Тюнинг: %s" % String(t["name"])):
				return {"ok": false, "text": "Недостаточно средств."}
		var tune: Dictionary = c.get("tuning", {})
		tune[tune_id] = true
		c["tuning"] = tune
		add_xp(20)
		save_profile()
		return {"ok": true, "text": "Установлено: %s" % String(t["name"])}


func add_car_damage(uid: String, percent: float) -> void:
		var c := car_by_uid(uid)
		if c.is_empty():
				return
		c["damage"] = clampf(float(c.get("damage", 0.0)) + percent, 0.0, 100.0)


func repair_car(uid: String, free: bool = false) -> Dictionary:
		var c := car_by_uid(uid)
		if c.is_empty():
				return {"ok": false, "text": "Автомобиль не найден."}
		var dmg := float(c.get("damage", 0.0))
		if dmg < 1.0:
				return {"ok": false, "text": "Кузов в порядке, ремонт не нужен."}
		var cost := int(ceil(dmg)) * int(Catalogs.SERVICES["repair_per_percent"]["price"])
		if not free and not charge(cost, "Ремонт автомобиля"):
				return {"ok": false, "text": "Ремонт стоит %s." % fmt_money(cost)}
		c["damage"] = 0.0
		save_profile()
		return {"ok": true, "text": "Кузов восстановлен!%s" % ("" if free else " Счёт: %s" % fmt_money(cost))}


func insurance_active() -> bool:
		return insurance_until > Time.get_unix_time_from_system()


func buy_insurance() -> Dictionary:
		if insurance_active():
				return {"ok": false, "text": "Страховка уже действует до конца срока."}
		if not charge(INSURANCE_PRICE, "КАСКО на 30 минут"):
				return {"ok": false, "text": "Полис стоит %s." % fmt_money(INSURANCE_PRICE)}
		insurance_until = Time.get_unix_time_from_system() + INSURANCE_PERIOD
		save_profile()
		return {"ok": true, "text": "КАСКО оформлено: ремонт и эвакуатор — бесплатно 30 минут."}


## Автомобиль ушёл на штрафстоянку (например, оставлен в розыск или брошен у дороги).
func impound_car(uid: String, reason: String = "") -> Dictionary:
		var c := car_by_uid(uid)
		if c.is_empty():
				return {"ok": false, "text": "Автомобиль не найден."}
		if bool(c.get("impound", false)):
				return {"ok": false, "text": "Автомобиль уже на штрафстоянке."}
		c["impound"] = true
		if active_car_uid == uid:
				active_car_uid = ""
		notify("Автомобиль забран на штрафстоянку.%s" % ((" Причина: " + reason) if reason != "" else ""))
		save_profile()
		return {"ok": true, "text": "Автомобиль на штрафстоянке."}


func car_release_impound(uid: String) -> Dictionary:
		var c := car_by_uid(uid)
		if c.is_empty():
				return {"ok": false, "text": "Автомобиль не найден."}
		if not bool(c.get("impound", false)):
				return {"ok": false, "text": "Автомобиль не на штрафстоянке."}
		var fee := int(Catalogs.SERVICES["impound_fee"]["price"])
		if insurance_active():
				c["impound"] = false
				save_profile()
				return {"ok": true, "text": "КАСКО покрыло штрафстоянку. Автомобиль в гараже."}
		if not charge(fee, "Штрафстоянка"):
				return {"ok": false, "text": "Освобождение стоит %s (или оформите КАСКО)." % fmt_money(fee)}
		c["impound"] = false
		save_profile()
		return {"ok": true, "text": "Автомобиль возвращён в гараж."}


## Продажа автомобиля в автосалоне (60% цены минус износ).
func sell_car(uid: String) -> Dictionary:
		var c := car_by_uid(uid)
		if c.is_empty():
				return {"ok": false, "text": "Автомобиль не найден."}
		if active_car_uid == uid:
				return {"ok": false, "text": "Сначала покиньте автомобиль."}
		var price := Catalogs.car_sell_price(c)
		owned_cars.erase(c)
		credit_bank(price, "Продажа авто: %s" % Catalogs.car_name(String(c["id"])))
		add_xp(30)
		save_profile()
		return {"ok": true, "text": "Автомобиль продан за %s (на счёт)." % fmt_money(price)}


# ---------- Бизнесы и лицензии ----------

func has_license(lic: String) -> bool:
		return licenses.has(lic)


func buy_license(lic: String) -> Dictionary:
		if not Catalogs.LICENSES.has(lic):
				return {"ok": false, "text": "Лицензия не найдена."}
		if has_license(lic):
				return {"ok": false, "text": "Лицензия уже у вас."}
		var l: Dictionary = Catalogs.LICENSES[lic]
		if not charge(int(l["price"]), "Лицензия: %s" % String(l["name"])):
				return {"ok": false, "text": "Недостаточно средств."}
		licenses.append(lic)
		add_xp(25)
		save_profile()
		return {"ok": true, "text": "Получена: %s" % String(l["name"])}


func buy_business(biz_id: String) -> Dictionary:
		if not Catalogs.BUSINESSES.has(biz_id):
				return {"ok": false, "text": "Бизнес не найден."}
		if not has_license("business"):
				return {"ok": false, "text": "Сначала получите лицензию предпринимателя в мэрии."}
		if businesses.has(biz_id):
				return {"ok": false, "text": "Этот бизнес уже ваш."}
		var b: Dictionary = Catalogs.BUSINESSES[biz_id]
		if total_money() < int(b["price"]):
				return {"ok": false, "text": "Недостаточно средств."}
		charge(int(b["price"]), "Покупка бизнеса: %s" % String(b["name"]))
		businesses.append(biz_id)
		territories[biz_id] = {"owner": "player", "captured_at": Time.get_unix_time_from_system(), "tribute_at": Time.get_unix_time_from_system()}
		add_xp(120)
		save_profile()
		return {"ok": true, "text": "Бизнес куплен: %s" % String(b["name"])}


func business_income(biz_id: String) -> Dictionary:
		if not businesses.has(biz_id):
				return {"amount": 0, "cap": 0}
		var b: Dictionary = Catalogs.BUSINESSES[biz_id]
		var t: Dictionary = territories.get(biz_id, {})
		var started := float(t.get("tribute_at", Time.get_unix_time_from_system()))
		var mins := (Time.get_unix_time_from_system() - started) / 60.0
		var capped := minf(mins, float(b["cap_min"]))
		return {"amount": int(round(float(b["income"]) * capped)), "cap": int(round(float(b["income"]) * float(b["cap_min"])))}


func collect_business(biz_id: String) -> Dictionary:
		if not businesses.has(biz_id):
				return {"ok": false, "text": "Это не ваш бизнес."}
		var inc := business_income(biz_id)
		var amount := int(inc["amount"])
		if amount <= 0:
				return {"ok": false, "text": "Выручка ещё не накопилась."}
		var b: Dictionary = Catalogs.BUSINESSES[biz_id]
		var tax := int(round(float(amount) * float(b["tax"])))
		var net := amount - tax
		credit_bank(net, "Выручка: %s (налог %s)" % [String(b["name"]), fmt_money(tax)])
		territories[biz_id] = {"owner": "player", "captured_at": Time.get_unix_time_from_system(), "tribute_at": Time.get_unix_time_from_system()}
		add_job_skill_xp("courier", 10)   # предпринимательство качает деловую хватку
		save_profile()
		return {"ok": true, "text": "Выручка %s на счёт (налог %s)" % [fmt_money(net), fmt_money(tax)]}


# ---------- Продажа предметов (ломбард / приёмка) ----------

## Продать предметы по рыночной цене (доля от базовой цены).
func sell_item(item_id: String, count: int) -> Dictionary:
		if online_mode:
				NetworkService.request("sell_item", {"item": item_id, "count": count})
				return {"ok": true, "text": "Запрос отправлен на сервер…"}
		if not Catalogs.SELLABLE.has(item_id):
				return {"ok": false, "text": "Этот предмет не принимают."}
		var have := item_total(item_id)
		var n := clampi(count, 1, have)
		if have <= 0:
				return {"ok": false, "text": "У вас нет этого предмета."}
		var unit := market_sell_price(item_id)
		if unit <= 0:
				return {"ok": false, "text": "Этот предмет не примут — нет рыночной цены."}
		var total := unit * n
		remove_item(item_id, n)
		add_money(total, "Продажа: %s × %d" % [Catalogs.item_name(item_id), n])
		add_xp(2 * n)
		save_profile()
		return {"ok": true, "text": "Продано %s × %d за %s" % [Catalogs.item_name(item_id), n, fmt_money(total)]}


# ---------- Мебель в квартире (живёт в квартире, не в рюкзаке) ----------

func apartment_furniture(prop_id: String) -> Array:
		return apartment_items.get(prop_id, [])


func buy_furniture(prop_id: String, item_id: String) -> Dictionary:
		var def: Dictionary = Catalogs.item_def(item_id)
		if String(def.get("kind", "")) != "furniture":
				return {"ok": false, "text": "Это не мебель."}
		if not owned_property.has(prop_id):
				return {"ok": false, "text": "Сначала купите квартиру."}
		var list: Array = apartment_furniture(prop_id)
		for spot in list:
				if String(Catalogs.item_def(String(spot)).get("spot", "")) == String(def.get("spot", "")):
						return {"ok": false, "text": "Это место уже занято такой мебелью."}
		var price := int(def.get("price", 0))
		if not charge(price, "Мебель: %s" % String(def["name"])):
				return {"ok": false, "text": "Недостаточно средств."}
		if not apartment_items.has(prop_id):
				apartment_items[prop_id] = []
		apartment_items[prop_id].append(item_id)
		add_xp(15)
		save_profile()
		return {"ok": true, "text": "Доставлено в квартиру: %s" % String(def["name"])}


# ---------- Здоровье и экстренные службы ----------

func heal_player(amount: float) -> void:
		health = clampf(health + amount, 1.0, 100.0)
		stats_changed.emit()


## Стационар в больнице: полное лечение за деньги, иначе — бесплатная помощь до 40%.
func hospital_treat() -> Dictionary:
		if health >= 99.0:
				return {"ok": false, "text": "Вы полностью здоровы."}
		if charge(HEAL_PRICE, "Лечение в больнице"):
				health = 100.0
				stats_changed.emit()
				save_profile()
				return {"ok": true, "text": "Вылечено полностью. Счёт: %s" % fmt_money(HEAL_PRICE)}
		health = maxf(health, HEAL_PARTIAL)
		stats_changed.emit()
		save_profile()
		return {"ok": true, "text": "Денег на полный курс нет — оказана базовая помощь (40)."}


func emergency_ready(key: String) -> bool:
		return float(emergency_until.get(key, 0.0)) <= Time.get_unix_time_from_system()


func emergency_cooldown(key: String, seconds: float) -> void:
		emergency_until[key] = Time.get_unix_time_from_system() + seconds


func buy_insurance_check() -> bool:
		return insurance_active()


# ---------- Обучение новичка ----------

func tutorial_active() -> bool:
		return not tutorial_done


func tutorial_advance(step: int) -> void:
		if tutorial_done or step <= tutorial_step:
				return
		tutorial_step = step
		save_profile()


## Награда за обучение: 15 000 ₽ наличными + 15 опыта + кейс новичка. Выдаётся один раз.
func grant_tutorial_reward() -> Dictionary:
		if tutorial_done:
				return {"ok": false, "text": "Награда уже получена."}
		tutorial_done = true
		tutorial_step = 0
		add_money(15000, "Награда за обучение")
		add_xp(15)
		var added := add_item("case_starter", 1)
		if added == 0:
				credit_bank(2500, "Кейс новичка заменён деньгами (инвентарь полон)")
		notify("Награда за обучение: 15 000 ₽, 15 опыта и кейс новичка!")
		AudioManager.play_sfx("levelup")
		save_profile()
		return {"ok": true, "text": "Обучение завершено!"}


# ---------- Территории банд ----------

func territory_state(gang_id: String) -> Dictionary:
		if not Catalogs.GANGS.has(gang_id):
				return {}
		var t: Dictionary = territories.get(gang_id, {})
		var now := Time.get_unix_time_from_system()
		var owner := String(t.get("owner", "gang"))
		var captured := float(t.get("captured_at", 0.0))
		# Банда отбивает зону сама, если игрок не продлевал влияние.
		if owner == "player" and captured > 0.0 and now - captured > Catalogs.GANG_RETALIATION:
				owner = "gang"
				territories[gang_id] = {"owner": "gang", "captured_at": now, "tribute_at": now}
		return {"owner": owner, "data": territories.get(gang_id, {}), "def": Catalogs.GANGS[gang_id]}


func capture_territory(gang_id: String) -> Dictionary:
		if not Catalogs.GANGS.has(gang_id):
				return {"ok": false, "text": "Зона не найдена."}
		var now := Time.get_unix_time_from_system()
		var already := String(territories.get(gang_id, {}).get("owner", "gang"))
		if already == "player":
				return {"ok": false, "text": "Зона уже под вашим контролем."}
		territories[gang_id] = {"owner": "player", "captured_at": now, "tribute_at": now}
		add_wanted(2, "Захват территории банды")
		add_xp(200)
		save_profile()
		return {"ok": true, "text": "Территория захвачена! Ждите ответки банды или собирайте дань."}


func collect_tribute(gang_id: String) -> Dictionary:
		if not Catalogs.GANGS.has(gang_id):
				return {"ok": false, "text": "Зона не найдена."}
		var t: Dictionary = territories.get(gang_id, {})
		if String(t.get("owner", "gang")) != "player":
				return {"ok": false, "text": "Зона принадлежит банде."}
		var last := float(t.get("tribute_at", 0.0))
		var left := Catalogs.GANG_TRIBUTE_PERIOD - (Time.get_unix_time_from_system() - last)
		if left > 0.0:
				return {"ok": false, "text": "Дань будет готова через %d мин." % int(ceil(left / 60.0))}
		var amount := int(Catalogs.GANGS[gang_id]["tribute"])
		credit_bank(amount, "Дань с территории: %s" % String(Catalogs.GANGS[gang_id]["name"]))
		territories[gang_id] = {"owner": "player", "captured_at": float(t.get("captured_at", Time.get_unix_time_from_system())), "tribute_at": Time.get_unix_time_from_system()}
		save_profile()
		return {"ok": true, "text": "Дань собрана: %s" % fmt_money(amount)}


# ---------- Внешность ----------

func apply_appearance_to_model(model: Node3D) -> void:
		if model == null or not model.has_method("set_appearance"):
				return
		model.call("set_appearance", appearance)


func _notification(what: int) -> void:
		if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
				if session_active:
						save_profile()
