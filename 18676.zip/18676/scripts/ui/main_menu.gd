extends Node3D
## Главное меню: 3D-фон с облётом города Ванбург, логотип с короной и кнопки
## «Войти», «Регистрация», «Настройки», «Выход». Экраны входа/регистрации/настроек
## открываются поверх меню.

const CityBuilder = preload("res://scripts/world/city_builder.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const LoginScene = preload("res://scenes/ui/login_screen.tscn")
const RegisterScene = preload("res://scenes/ui/register_screen.tscn")
const SettingsScene = preload("res://scenes/ui/settings_screen.tscn")
const OnlinePanel = preload("res://scripts/ui/online_panel.gd")
const WORLD_SCENE := "res://scenes/world/vanburg.tscn"

var _camera: Camera3D
var _ui: CanvasLayer
var _menu_root: Control
var _overlay: Control = null
var _angle: float = 0.6


func _ready() -> void:
		get_tree().paused = false
		get_tree().set_quit_on_go_back(false)
		var sun := CityBuilder.add_atmosphere(self)
		GameSettings.apply_light(sun)
		GameSettings.apply_viewport(get_viewport())
		CityBuilder.build(self)

		_camera = Camera3D.new()
		_camera.far = 450.0
		_camera.fov = 62.0
		add_child(_camera)
		_camera.current = true
		_update_camera()

		_ui = CanvasLayer.new()
		add_child(_ui)
		_build_menu()


func _process(delta: float) -> void:
		_angle += delta * 0.07
		_update_camera()


func _update_camera() -> void:
		var r := 92.0
		_camera.position = Vector3(cos(_angle) * r, 46.0, sin(_angle) * r)
		_camera.look_at(Vector3(0, 4, 0), Vector3.UP)


func _build_menu() -> void:
		_menu_root = Control.new()
		_menu_root.set_anchors_preset(Control.PRESET_FULL_RECT)
		_menu_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_ui.add_child(_menu_root)

		var left := MarginContainer.new()
		left.set_anchors_preset(Control.PRESET_LEFT_WIDE)
		left.add_theme_constant_override("margin_left", 40)
		left.add_theme_constant_override("margin_top", 24)
		left.add_theme_constant_override("margin_bottom", 24)
		left.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_menu_root.add_child(left)
		var panel := UiKit.make_panel()
		panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		left.add_child(panel)
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 10)
		panel.add_child(vb)

		var logo := UiKit.make_icon("crown", 120)
		logo.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		vb.add_child(logo)
		vb.add_child(UiKit.make_title("1KIND RP", 62))
		var sub := UiKit.make_label("Город Ванбург", 26, UiKit.COLOR_TEXT)
		sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(sub)
		var gap := Control.new()
		gap.custom_minimum_size = Vector2(0, 8)
		vb.add_child(gap)

		var login := UiKit.make_button("Войти", "gold", Vector2(380, 70))
		login.pressed.connect(_open_login)
		vb.add_child(login)
		var register := UiKit.make_button("Регистрация", "blue", Vector2(380, 70))
		register.pressed.connect(_open_register)
		vb.add_child(register)
		var online := UiKit.make_button("Сетевая игра (бета)", "purple", Vector2(380, 70))
		online.pressed.connect(_open_online)
		vb.add_child(online)
		var settings := UiKit.make_button("Настройки", "blue", Vector2(380, 70))
		settings.pressed.connect(_open_settings)
		vb.add_child(settings)
		var quit := UiKit.make_button("Выход", "dark", Vector2(380, 70))
		quit.pressed.connect(_quit_game)
		vb.add_child(quit)

		var version := str(ProjectSettings.get_setting("application/config/version", "0.1.0"))
		var ver_label := UiKit.make_label("Версия %s  ·  %s" % [version, NetworkService.mode_title()], 20, UiKit.COLOR_TEXT)
		ver_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
		ver_label.add_theme_constant_override("outline_size", 6)
		ver_label.anchor_left = 1.0
		ver_label.anchor_right = 1.0
		ver_label.anchor_top = 1.0
		ver_label.anchor_bottom = 1.0
		ver_label.offset_left = -24.0
		ver_label.offset_right = -24.0
		ver_label.offset_top = -16.0
		ver_label.offset_bottom = -16.0
		ver_label.grow_horizontal = Control.GROW_DIRECTION_BEGIN
		ver_label.grow_vertical = Control.GROW_DIRECTION_BEGIN
		_menu_root.add_child(ver_label)


# ---------- Оверлеи ----------

func _show_overlay(node: Control) -> void:
		_close_overlay()
		_overlay = node
		_ui.add_child(node)
		AudioManager.play_sfx("open")


func _close_overlay() -> void:
		if _overlay != null:
				_overlay.queue_free()
				_overlay = null


func _open_login(prefill_nick: String = "", message: String = "") -> void:
		var screen = LoginScene.instantiate()
		screen.login_success.connect(_on_login_success)
		screen.register_requested.connect(_open_register)
		screen.closed.connect(_close_overlay)
		_show_overlay(screen)
		if prefill_nick != "":
				screen.prefill(prefill_nick, message)


func _open_register() -> void:
		var screen = RegisterScene.instantiate()
		screen.registered.connect(_on_registered)
		screen.login_requested.connect(_open_login)
		screen.closed.connect(_close_overlay)
		_show_overlay(screen)


func _open_settings() -> void:
		var screen = SettingsScene.instantiate()
		screen.closed.connect(_close_overlay)
		_show_overlay(screen)


func _open_online() -> void:
		var panel := OnlinePanel.new()
		panel.closed.connect(_close_overlay)
		_show_overlay(panel)


func _on_registered(nick: String) -> void:
		_open_login(nick, "Аккаунт создан! Введите пароль для входа.")


func _on_login_success(nick: String) -> void:
		GameState.start_session(nick)
		get_tree().change_scene_to_file(WORLD_SCENE)


func _quit_game() -> void:
		GameSettings.save_settings()
		get_tree().quit()


func _notification(what: int) -> void:
		if what == NOTIFICATION_WM_GO_BACK_REQUEST:
				if _overlay != null:
						_close_overlay()
				else:
						_quit_game()
