extends Control
## Экран регистрации: никнейм, пароль, повтор пароля. Создаёт локальный аккаунт
## (пароль хранится как PBKDF2-HMAC-SHA256 с солью).

signal registered(nick: String)
signal login_requested
signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _nick: LineEdit
var _pass: LineEdit
var _repeat: LineEdit
var _status: Label
var _create_btn: Button
var _busy: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim(0.7))
	var top := MarginContainer.new()
	top.set_anchors_preset(Control.PRESET_FULL_RECT)
	top.add_theme_constant_override("margin_top", 16)
	add_child(top)
	var holder := HBoxContainer.new()
	holder.alignment = BoxContainer.ALIGNMENT_CENTER
	holder.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(holder)
	var panel := UiKit.make_panel()
	holder.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	panel.add_child(vb)

	vb.add_child(UiKit.make_title("Регистрация", 38))
	_nick = UiKit.make_line_edit("Никнейм (3–16 символов)")
	_nick.max_length = 16
	vb.add_child(_nick)
	_pass = UiKit.make_line_edit("Пароль (минимум 6 символов)", true)
	_pass.max_length = 64
	vb.add_child(_pass)
	_repeat = UiKit.make_line_edit("Повторите пароль", true)
	_repeat.max_length = 64
	_repeat.text_submitted.connect(func(_t: String) -> void: _do_register())
	vb.add_child(_repeat)
	_status = UiKit.make_label("", 20, UiKit.COLOR_MUTED)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(380, 52)
	vb.add_child(_status)

	_create_btn = UiKit.make_button("Создать аккаунт", "gold", Vector2(380, 62))
	_create_btn.pressed.connect(_do_register)
	vb.add_child(_create_btn)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	vb.add_child(row)
	var login := UiKit.make_button("Уже есть аккаунт", "blue", Vector2(185, 54), 20)
	login.pressed.connect(func() -> void: login_requested.emit())
	row.add_child(login)
	var back := UiKit.make_button("Назад", "dark", Vector2(185, 54), 22)
	back.pressed.connect(func() -> void: closed.emit())
	row.add_child(back)


func _set_error(text: String) -> void:
	_status.text = text
	_status.add_theme_color_override("font_color", UiKit.COLOR_ERROR)
	AudioManager.play_sfx("error")


func _do_register() -> void:
	if _busy:
		return
	var nick := _nick.text.strip_edges()
	var pw := _pass.text
	var pw2 := _repeat.text
	# Проверки выполняются до тяжёлого хеширования, чтобы ответ был мгновенным.
	if nick.is_empty() or pw.is_empty() or pw2.is_empty():
		_set_error("Заполните все поля.")
		return
	var nick_error := AccountManager.validate_nick(nick)
	if nick_error != "":
		_set_error(nick_error)
		return
	var pass_error := AccountManager.validate_password(pw)
	if pass_error != "":
		_set_error(pass_error)
		return
	if pw != pw2:
		_set_error("Пароли не совпадают.")
		return
	if AccountManager.account_exists(nick):
		_set_error("Такой никнейм уже занят на этом устройстве.")
		return
	_busy = true
	_create_btn.disabled = true
	_status.text = "Создание аккаунта…"
	_status.add_theme_color_override("font_color", UiKit.COLOR_MUTED)
	await get_tree().process_frame
	await get_tree().process_frame
	var res := AccountManager.register(nick, pw, pw2)
	_busy = false
	_create_btn.disabled = false
	if bool(res["ok"]):
		_pass.text = ""
		_repeat.text = ""
		registered.emit(String(res["nick"]))
	else:
		_set_error(String(res["error"]))
