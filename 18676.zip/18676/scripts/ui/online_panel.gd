extends Control
## Онлайн-панель главного меню: адрес сервера, подключение, регистрация и вход
## НА СЕРВЕРЕ (этап 1 онлайн-режима). Пароли проверяет сервер, профиль хранит сервер.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const WORLD_SCENE := "res://scenes/world/vanburg.tscn"
const DEFAULT_ADDR := "127.0.0.1:7777"

var _addr: LineEdit
var _nick: LineEdit
var _pass: LineEdit
var _status: Label
var _connect_btn: Button
var _register_btn: Button
var _login_btn: Button


func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(UiKit.make_dim(0.7))
		var top := MarginContainer.new()
		top.set_anchors_preset(Control.PRESET_FULL_RECT)
		top.add_theme_constant_override("margin_top", 24)
		add_child(top)
		var holder := HBoxContainer.new()
		holder.alignment = BoxContainer.ALIGNMENT_CENTER
		holder.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
		top.add_child(holder)
		var panel := UiKit.make_panel()
		holder.add_child(panel)
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 10)
		panel.add_child(vb)

		vb.add_child(UiKit.make_title("Сетевая игра (бета)", 36))
		var info := UiKit.make_label("Сервер Godot 4.3 headless из папки server/godot_server (до 50 игроков). Введите адрес сервера в той же Wi-Fi сети или на VPS.", 17, UiKit.COLOR_MUTED)
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		info.custom_minimum_size = Vector2(520, 0)
		vb.add_child(info)

		_addr = UiKit.make_line_edit("Адрес: IP:порт (%s)" % DEFAULT_ADDR)
		_addr.text = str(OS.get_environment("ONEKIND_SERVER")) if OS.get_environment("ONEKIND_SERVER") != "" else ""
		vb.add_child(_addr)
		_connect_btn = UiKit.make_button("Подключиться к серверу", "blue", Vector2(540, 60))
		_connect_btn.pressed.connect(_on_connect)
		vb.add_child(_connect_btn)

		_nick = UiKit.make_line_edit("Никнейм (аккаунт на сервере)")
		_nick.max_length = 16
		vb.add_child(_nick)
		_pass = UiKit.make_line_edit("Пароль", true)
		_pass.max_length = 64
		vb.add_child(_pass)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		vb.add_child(row)
		_register_btn = UiKit.make_button("Регистрация", "blue", Vector2(258, 58), 21)
		_register_btn.disabled = true
		_register_btn.pressed.connect(_on_register)
		row.add_child(_register_btn)
		_login_btn = UiKit.make_button("Войти и играть", "gold", Vector2(258, 58), 21)
		_login_btn.disabled = true
		_login_btn.pressed.connect(_on_login)
		row.add_child(_login_btn)

		_status = UiKit.make_label("Статус: %s" % NetworkService.mode_title(), 20, UiKit.COLOR_MUTED)
		_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_status.custom_minimum_size = Vector2(520, 44)
		vb.add_child(_status)

		var back := UiKit.make_button("Назад", "dark", Vector2(300, 56))
		back.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		back.pressed.connect(func() -> void: closed.emit())
		vb.add_child(back)

		NetworkService.connection_state_changed.connect(_on_state)
		NetworkService.auth_result.connect(_on_auth)


func _exit_tree() -> void:
		if NetworkService.connection_state_changed.is_connected(_on_state):
				NetworkService.connection_state_changed.disconnect(_on_state)
		if NetworkService.auth_result.is_connected(_on_auth):
				NetworkService.auth_result.disconnect(_on_auth)


func _set_status(text: String, col: Color = UiKit.COLOR_MUTED) -> void:
		_status.text = text
		_status.add_theme_color_override("font_color", col)


func _on_connect() -> void:
		var addr := _addr.text.strip_edges()
		if addr == "":
				addr = DEFAULT_ADDR
		var r := NetworkService.connect_to_server(addr)
		if not bool(r["ok"]):
				_set_status(String(r["error"]), UiKit.COLOR_ERROR)
				AudioManager.play_sfx("error")
		else:
				_connect_btn.disabled = true
				_set_status("Подключение к %s…" % NetworkService.server_addr)


func _on_state(online: bool) -> void:
		_connect_btn.disabled = NetworkService.is_online() or NetworkService.connecting
		_connect_btn.text = "Отключиться" if NetworkService.is_online() else "Подключиться к серверу"
		if online:
				_set_status("Подключено к %s! Введите ник и пароль." % NetworkService.server_addr, UiKit.COLOR_OK)
				_register_btn.disabled = false
				_login_btn.disabled = false
		elif not NetworkService.connecting:
				_register_btn.disabled = true
				_login_btn.disabled = true


func _on_register() -> void:
		if _pass.text.length() < 6:
				_set_status("Пароль: минимум 6 символов.", UiKit.COLOR_ERROR)
				return
		_set_status("Отправка регистрации…")
		NetworkService.server_register(_nick.text, _pass.text)


func _on_login() -> void:
		if _nick.text.strip_edges() == "" or _pass.text.is_empty():
				_set_status("Введите никнейм и пароль.", UiKit.COLOR_ERROR)
				return
		_set_status("Проверка на сервере…")
		NetworkService.server_auth(_nick.text, _pass.text)


func _on_auth(ok: bool, error: String) -> void:
		if not ok:
				_set_status(error, UiKit.COLOR_ERROR)
				AudioManager.play_sfx("error")
				return
		_set_status("Готово! Загружаем мир…", UiKit.COLOR_OK)
		var nick := _nick.text.strip_edges()
		GameState.start_session(nick, true)
		GameState.online_mode = true
		# Дожидаемся первого снимка профиля (до 3 с), затем входим.
		_wait_profile_and_enter(nick)


func _wait_profile_and_enter(_nick: String) -> void:
		# Даём серверу ~1.5 с прислать первый снимок профиля, затем входим в мир.
		for i in range(90):
				await get_tree().process_frame
		get_tree().change_scene_to_file(WORLD_SCENE)
