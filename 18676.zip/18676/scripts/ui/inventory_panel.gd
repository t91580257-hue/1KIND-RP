extends Control
## Инвентарь: сетка слотов, вес, использование, выбрасывание, разделение и перемещение между слотами.
## Все действия выполняет GameState (use_slot / drop_slot / split_slot / move_slot).

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

const COLUMNS := 6

var _grid: GridContainer
var _weight_label: Label
var _info_name: Label
var _info_desc: Label
var _btn_use: Button
var _btn_drop: Button
var _btn_split: Button
var _btn_move: Button
var _selected: int = -1
var _move_from: int = -1
var _buttons: Array = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(980, 600)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	panel.add_child(root)
	root.add_child(UiKit.make_title("Инвентарь", 36))
	_weight_label = UiKit.make_label("", 22, UiKit.COLOR_GOLD)
	_weight_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(_weight_label)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 18)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(560, 360)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	body.add_child(scroll)
	_grid = GridContainer.new()
	_grid.columns = COLUMNS
	_grid.add_theme_constant_override("h_separation", 6)
	_grid.add_theme_constant_override("v_separation", 6)
	scroll.add_child(_grid)
	for i in range(GameState.SLOT_COUNT):
		var b := Button.new()
		b.custom_minimum_size = Vector2(86, 86)
		b.focus_mode = Control.FOCUS_NONE
		b.clip_text = true
		b.add_theme_font_size_override("font_size", 14)
		b.pressed.connect(_on_slot_pressed.bind(i))
		_grid.add_child(b)
		_buttons.append(b)

	var side := VBoxContainer.new()
	side.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	side.add_theme_constant_override("separation", 8)
	body.add_child(side)
	_info_name = UiKit.make_label("Выберите предмет", 26, UiKit.COLOR_GOLD)
	_info_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	side.add_child(_info_name)
	_info_desc = UiKit.make_label("", 19, UiKit.COLOR_MUTED)
	_info_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_info_desc.custom_minimum_size = Vector2(300, 80)
	side.add_child(_info_desc)
	_btn_use = UiKit.make_button("Использовать", "gold", Vector2(300, 54), 22)
	_btn_use.pressed.connect(_on_use)
	side.add_child(_btn_use)
	_btn_split = UiKit.make_button("Разделить пополам", "blue", Vector2(300, 54), 22)
	_btn_split.pressed.connect(_on_split)
	side.add_child(_btn_split)
	_btn_move = UiKit.make_button("Переместить…", "blue", Vector2(300, 54), 22)
	_btn_move.pressed.connect(_on_move_mode)
	side.add_child(_btn_move)
	_btn_drop = UiKit.make_button("Выбросить 1 шт.", "dark", Vector2(300, 54), 22)
	_btn_drop.pressed.connect(_on_drop)
	side.add_child(_btn_drop)

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)

	GameState.inventory_changed.connect(_refresh)
	GameState.stats_changed.connect(_refresh_weight)
	_refresh()


func _exit_tree() -> void:
	if GameState.inventory_changed.is_connected(_refresh):
		GameState.inventory_changed.disconnect(_refresh)
	if GameState.stats_changed.is_connected(_refresh_weight):
		GameState.stats_changed.disconnect(_refresh_weight)


func _refresh_weight() -> void:
	_weight_label.text = "Вес: %.1f / %.0f кг  ·  Наличные: %s" % [GameState.total_weight(), GameState.MAX_WEIGHT, GameState.fmt_money(GameState.cash)]


func _refresh() -> void:
	_refresh_weight()
	for i in range(GameState.SLOT_COUNT):
		var b: Button = _buttons[i]
		var s: Dictionary = GameState.slots[i]
		if s.is_empty():
			b.text = ""
			b.icon = null
		else:
			var def := Catalogs.item_def(String(s["id"]))
			b.text = "%s\n×%d" % [String(def["name"]), int(s["count"])]
			b.icon = UiKit.icon(String(def.get("icon", "star")))
			b.expand_icon = true
			b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
			b.vertical_icon_alignment = VERTICAL_ALIGNMENT_TOP
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.06, 0.14, 0.3, 0.85)
		sb.set_corner_radius_all(10)
		sb.set_border_width_all(2)
		sb.border_color = UiKit.COLOR_GOLD if i == _selected else (UiKit.COLOR_OK if i == _move_from else UiKit.COLOR_BLUE)
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
	_update_info()


func _update_info() -> void:
	var has := _selected >= 0 and _selected < GameState.SLOT_COUNT and not GameState.slots[_selected].is_empty()
	if not has:
		_selected = -1
		_info_name.text = "Выберите предмет"
		_info_desc.text = "Нажмите слот, чтобы увидеть описание и действия."
	else:
		var s: Dictionary = GameState.slots[_selected]
		var def := Catalogs.item_def(String(s["id"]))
		_info_name.text = "%s × %d" % [String(def["name"]), int(s["count"])]
		_info_desc.text = "%s\nВес: %.1f кг за штуку" % [String(def.get("desc", "")), float(def.get("weight", 0.0))]
	_btn_use.disabled = not has
	_btn_drop.disabled = not has
	_btn_move.disabled = not has
	_btn_split.disabled = not has or int(GameState.slots[_selected]["count"]) < 2
	_btn_move.text = "Выберите слот-цель…" if _move_from >= 0 else "Переместить…"


func _on_slot_pressed(i: int) -> void:
	AudioManager.play_sfx("click")
	if _move_from >= 0:
		var from := _move_from
		_move_from = -1
		GameState.move_slot(from, i)
		_selected = i
		_refresh()
		return
	_selected = i
	_refresh()


func _report(result: Dictionary) -> void:
	GameState.notify(String(result["text"]))
	if not bool(result["ok"]):
		AudioManager.play_sfx("error")


func _on_use() -> void:
	if _selected < 0:
		return
	_report(GameState.use_slot(_selected))
	GameState.save_profile()


func _on_drop() -> void:
	if _selected < 0:
		return
	_report(GameState.drop_slot(_selected, 1))


func _on_split() -> void:
	if _selected < 0:
		return
	var half := int(GameState.slots[_selected]["count"]) / 2
	_report(GameState.split_slot(_selected, half))


func _on_move_mode() -> void:
	if _selected < 0:
		return
	_move_from = _selected
	_refresh()
