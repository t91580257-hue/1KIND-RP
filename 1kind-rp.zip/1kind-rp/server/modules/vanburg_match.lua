-- ЗАГОТОВКА авторитетного матча «Ванбург» (до 50 игроков). НЕ ПОДКЛЮЧЕНА к клиенту.
-- Показывает, куда будет добавлена серверная логика синхронизации игроков.
-- Документация: https://heroiclabs.com/docs/nakama/server-framework/lua-runtime/
local nk = require("nakama")

local M = {}
local MAX_PLAYERS = 50

function M.match_init(_context, _params)
  local state = { presences = {}, count = 0 }
  local tick_rate = 10
  local label = "vanburg"
  return state, tick_rate, label
end

function M.match_join_attempt(_context, _dispatcher, _tick, state, presence, _metadata)
  if state.count >= MAX_PLAYERS then
    return state, false, "Город заполнен (50/50)"
  end
  return state, true
end

function M.match_join(_context, _dispatcher, _tick, state, presences)
  for _, p in ipairs(presences) do
    state.presences[p.session_id] = p
    state.count = state.count + 1
  end
  return state
end

function M.match_leave(_context, _dispatcher, _tick, state, presences)
  for _, p in ipairs(presences) do
    if state.presences[p.session_id] ~= nil then
      state.presences[p.session_id] = nil
      state.count = state.count - 1
    end
  end
  return state
end

function M.match_loop(_context, dispatcher, _tick, state, messages)
  -- TODO (будущая версия): принять позиции игроков (op_code 1) и разослать всем остальным.
  for _, m in ipairs(messages) do
    dispatcher.broadcast_message(m.op_code, m.data, nil, m.sender)
  end
  return state
end

function M.match_terminate(_context, _dispatcher, _tick, state, _grace_seconds)
  return state
end

function M.match_signal(_context, _dispatcher, _tick, state, data)
  return state, data
end

return M
