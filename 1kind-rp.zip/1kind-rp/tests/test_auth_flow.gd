extends SceneTree
## Headless-тест: регистрация и вход через AccountManager (поток + сигнал).

const AM = preload("res://scripts/systems/account_manager.gd")

var am: Node
var stage := "register"
var done := false


func _initialize() -> void:
	am = AM.new()
	am.check_finished.connect(_on_result)
	root.add_child(am)
	await process_frame
	var nick := "test_%d" % (int(Time.get_unix_time_from_system()) % 100000)
	am.set_meta("nick", nick)
	var r: Dictionary = am.start_register(nick, "пароль123", "пароль123")
	print("REG_START=", r)
	print("THREAD=", am._thread, " alive=", am._thread.is_alive() if am._thread != null else "null")
	if not bool(r["ok"]):
		done = true
		quit(1)


func _on_result(res: Dictionary) -> void:
	print("RESULT kind=", res.get("kind"), " ok=", res.get("ok"), " err=", res.get("error"))
	if bool(res.get("ok", false)) and stage == "register":
		stage = "login"
		print("LOGIN_START=", am.start_login(am.get_meta("nick"), "пароль123"))
		return
	if bool(res.get("ok", false)) and stage == "login":
		print("ALL_OK elapsed_ms=", am.check_elapsed_ms)
		done = true
		quit(0)
		return
	print("FAILED")
	done = true
	quit(1)
