extends Node
## Тест кнопки «ИГРАТЬ» — запускается как сцена (autoloads на месте).

func _ready() -> void:
	await get_tree().process_frame
	var menu: Node = load("res://scenes/main_menu.tscn").instantiate()
	add_child(menu)
	for i in range(10):
		await get_tree().process_frame
	menu._nick_edit.text = ""
	menu._on_play()
	print("HINT_EMPTY=", menu._hint.text)
	menu._nick_edit.text = "ab"
	menu._on_play()
	print("HINT_SHORT=", menu._hint.text)
	menu._nick_edit.text = "ПроверкаКнопки"
	menu._on_play()
	await get_tree().process_frame
	print("OVERLAY=", menu._overlay != null)
	if menu._overlay != null:
		print("OVERLAY_TITLE=", menu._overlay._title.text, " MODE=", menu._overlay._mode)
	menu._close_overlay()
	menu._nick_edit.text = "Новенький_%d" % (randi() % 1000)
	menu._on_play()
	await get_tree().process_frame
	print("OVERLAY2=", menu._overlay != null)
	if menu._overlay != null:
		print("MODE2=", menu._overlay._mode)
	print("TEST_DONE")
	get_tree().quit(0)
