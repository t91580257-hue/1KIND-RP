extends SceneTree
## Headless-тест кнопки «ИГРАТЬ» главного меню: пустой ник -> подсказка,
## валидный ник -> открывается панель авторизации в нужном режиме.

const MENU = preload("res://scenes/main_menu.tscn")


func _initialize() -> void:
	# В режиме --script автозагрузки отсутствуют — поднимаем вручную.
	for pair in [["GameSettings", "res://scripts/systems/game_settings.gd"],
			["AudioManager", "res://scripts/systems/audio_manager.gd"],
			["AccountManager", "res://scripts/systems/account_manager.gd"],
			["GameState", "res://scripts/systems/game_state.gd"],
			["NetworkService", "res://scripts/systems/network_service.gd"],
			["JobSystem", "res://scripts/systems/job_system.gd"]]:
		var n: Node = (load(pair[1]) as GDScript).new()
		n.name = pair[0]
		root.add_child(n)
	await process_frame
	var menu: Node = MENU.instantiate()
	root.add_child(menu)
	for i in range(10):
		await process_frame
	# 1. Пустой ник -> подсказка.
	menu._nick_edit.text = ""
	menu._on_play()
	print("HINT_EMPTY=", menu._hint.text)
	# 2. Невалидный ник.
	menu._nick_edit.text = "ab"
	menu._on_play()
	print("HINT_SHORT=", menu._hint.text)
	# 3. Валидный ник -> оверлей авторизации.
	menu._nick_edit.text = "ПроверкаКнопки"
	menu._on_play()
	await process_frame
	var ov = menu._overlay
	print("OVERLAY=", ov != null)
	if ov != null:
		print("OVERLAY_TITLE=", ov._title.text, " MODE=", ov._mode)
	# 4. Новый ник -> режим регистрации.
	menu._close_overlay()
	menu._nick_edit.text = "Новенький_%d" % (randi() % 1000)
	menu._on_play()
	await process_frame
	print("OVERLAY2=", menu._overlay != null)
	if menu._overlay != null:
		print("MODE2=", menu._overlay._mode, " TITLE2=", menu._overlay._title.text)
	print("TEST_DONE")
	quit(0)
