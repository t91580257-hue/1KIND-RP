extends SceneTree

var th: Thread


func _initialize() -> void:
	th = Thread.new()
	var err := th.start(_job.bind(41))
	print("START_ERR=", err, " alive=", th.is_alive())
	var res: Variant = th.wait_to_finish()
	print("RES=", res, " sum=", int(res) + 1)


func _job(x: int) -> int:
	print("WORKER_RAN x=", x)
	return x + 1
