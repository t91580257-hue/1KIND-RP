extends SceneTree


func _initialize() -> void:
	var th := Thread.new()
	var err := th.start(_job)
	print("START_ERR=", err)
	var res: Variant = th.wait_to_finish()
	print("RES=", res.size())
	quit(0)


func _job() -> PackedByteArray:
	print("WORKER: creating crypto")
	var c := Crypto.new()
	print("WORKER: crypto ok, computing hmac")
	var key := "пароль".to_utf8_buffer()
	var msg := PackedByteArray([1, 2, 3])
	var u := c.hmac_digest(HashingContext.HASH_SHA256, key, msg)
	print("WORKER: hmac len=", u.size())
	return u
