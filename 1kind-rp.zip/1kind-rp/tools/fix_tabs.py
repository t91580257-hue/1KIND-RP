#!/usr/bin/env python3
"""Приводит отступы во всех .gd к табам: 4 ведущих пробела = 1 уровень таба.
GDScript в Godot допускает пробелы, но проект 1KIND RP стандартизирован на табы,
и tools/validate_project.py это проверяет."""
import os
import re
import sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
changed = 0
checked = 0
for base, dirs, names in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {".git", ".godot", "build"}]
    for n in names:
        if not n.endswith(".gd"):
            continue
        p = os.path.join(base, n)
        checked += 1
        out = []
        touched = False
        for line in open(p, encoding="utf-8"):
            m = re.match(r"^( +)", line)
            if m:
                lead = len(m.group(1))
                tabs = lead // 4
                rest = lead % 4
                new_lead = "\t" * tabs + " " * rest
                nl = new_lead + line[lead:]
                if nl != line:
                    touched = True
                out.append(nl)
            else:
                out.append(line)
        if touched:
            open(p, "w", encoding="utf-8").writelines(out)
            changed += 1
            print("табы:", os.path.relpath(p, ROOT))
print(f"Проверено файлов: {checked}, исправлено: {changed}")
