#!/usr/bin/env python3
"""Проверка данных каталога: 15 автомобилей, по 5 в каждом автосалоне, у каждого уникальная форма/цена/цвета,
все shape есть в car_factory.gd, все icon существуют, все предметы кейсов/магазина определены."""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cat = open(os.path.join(ROOT, "scripts/systems/catalogs.gd"), encoding="utf-8").read()
fac = open(os.path.join(ROOT, "scripts/world/car_factory.gd"), encoding="utf-8").read()
errors = []

cars_block = cat[cat.index("const CARS"):cat.index("const PROPERTY")]
cars = re.findall(r'^\t"(\w+)": \{"name": "([^"]+)".*?"price": (\d+).*?"shape": "(\w+)", "dealer": "(\w+)", "top_speed": (\d+), "accel": ([\d.]+), "handling": (\d+), "fuel": ([\d.]+), "tank": (\d+), "colors": \[([^\]]*)\]', cars_block, re.M)
if len(cars) != 15:
    errors.append(f"ожидалось 15 автомобилей, найдено {len(cars)}")
by_dealer = {}
for cid, name, price, shape, dealer, *_ in cars:
    by_dealer.setdefault(dealer, []).append(cid)
for d in ("econ", "mid", "premium"):
    if len(by_dealer.get(d, [])) != 5:
        errors.append(f"в салоне {d} не 5 автомобилей: {by_dealer.get(d)}")
names = [c[1] for c in cars]
if len(set(names)) != len(names):
    errors.append("повторяющиеся названия автомобилей")
prices = [int(c[2]) for c in cars]
if len(set(prices)) != len(prices):
    errors.append("повторяющиеся цены автомобилей")
profiles = set(re.findall(r'^\t"(\w+)": \{"l":', fac, re.M))
for c in cars:
    if c[3] not in profiles:
        errors.append(f"{c[0]}: нет профиля кузова {c[3]} в car_factory.gd")
# в каждом салоне форм кузова должно быть 5 разных
for d, ids in by_dealer.items():
    shapes = {c[3] for c in cars if c[0] in ids}
    if len(shapes) != 5:
        errors.append(f"салон {d}: форм кузова {len(shapes)}, ожидалось 5")
# состав салонов совпадает с DEALERS
dealers = re.findall(r'"(econ|mid|premium)": \{"name": "[^"]+", "cars": \[([^\]]*)\]\}', cat)
for d, lst in dealers:
    ids = re.findall(r'"(\w+)"', lst)
    if sorted(ids) != sorted(by_dealer.get(d, [])):
        errors.append(f"DEALERS[{d}] не совпадает с полем dealer у автомобилей")
# иконки
for ic in set(re.findall(r'"icon": "(\w+)"', cat)):
    if not os.path.exists(os.path.join(ROOT, f"assets/ui/icons/{ic}.png")):
        errors.append(f"нет иконки {ic}.png")
# SHOP_ITEMS определены
items = set(re.findall(r'^\t"(\w+)": \{"name"', cat[cat.index("const ITEMS"):cat.index("const SHOP_ITEMS")], re.M))
for sid in re.findall(r'"(\w+)"', cat[cat.index("const SHOP_ITEMS"):].split("\n")[0]):
    if sid not in items:
        errors.append(f"SHOP_ITEMS: нет предмета {sid}")
for e in errors:
    print("ОШИБКА:", e)
print(f"Автомобилей: {len(cars)}, салонов: {len(by_dealer)}, предметов: {len(items)}")
sys.exit(1 if errors else 0)
