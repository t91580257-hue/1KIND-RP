#!/usr/bin/env python3
"""Статическая проверка проекта 1KIND RP (без запуска Godot).

Проверяет:
  * все пути res://... в .gd/.tscn/.godot/.cfg существуют;
  * в .tscn все ext_resource-скрипты/сцены существуют;
  * в .gd отступы только табами и скобки сбалансированы;
  * нет вызовов из Godot 3.x (yield, onready var без @, KinematicBody, export var и т.п.);
  * стартовая сцена и автозагрузки существуют.
Это НЕ замена запуску в Godot: парсер GDScript здесь не используется.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors = []
warnings = []

SKIP_DIRS = {".git", ".godot", "build", "server", "tools", ".github"}
GODOT3_PATTERNS = [
    (r"^\s*yield\s*\(", "yield() — это Godot 3"),
    (r"^\s*onready\s+var", "onready без @ — Godot 3"),
    (r"^\s*export\s*(\(|var)", "export без @ — Godot 3"),
    (r"\bKinematicBody", "KinematicBody — Godot 3"),
    (r"\bSpatial\b", "Spatial — Godot 3 (в Godot 4 Node3D)"),
    (r"\bmove_and_slide\([^)]+\)", "move_and_slide с аргументами — Godot 3"),
    (r"\bconnect\(\s*\"", "connect со строковым именем сигнала — Godot 3"),
    (r"\brand_range\(", "rand_range — Godot 3 (randf_range)"),
    (r"\bOS\.get_ticks_msec", "OS.get_ticks_msec — Godot 3"),
    (r"\bFile\.new\(|\bDirectory\.new\(", "File/Directory.new — Godot 3"),
]


def files(exts):
    for base, dirs, names in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for n in names:
            if n.endswith(exts):
                yield os.path.join(base, n)


def rel(p):
    return os.path.relpath(p, ROOT)


def res_exists(path):
    return os.path.exists(os.path.join(ROOT, path[len("res://"):]))


def check_res_refs():
    rx = re.compile(r"res://[^\"'\s)\],]+")
    for p in list(files((".gd", ".tscn", ".cfg"))) + [os.path.join(ROOT, "project.godot")]:
        text = open(p, encoding="utf-8").read()
        for m in rx.finditer(text):
            ref = m.group(0).rstrip(".")
            if "%" in ref or "{" in ref or ref.endswith("/"):
                continue
            if not res_exists(ref):
                errors.append(f"{rel(p)}: нет файла {ref}")


def check_dynamic_assets():
    # Пути, собираемые форматированием строк: проверим все возможные файлы.
    icons = ["crown", "user", "money", "location", "settings", "health", "shop", "phone",
             "map", "star", "car", "home", "jobs", "shield"]
    for i in icons:
        if not os.path.exists(os.path.join(ROOT, "assets/ui/icons", i + ".png")):
            errors.append(f"нет иконки assets/ui/icons/{i}.png")
    for b in ["blue", "gold", "dark", "purple"]:
        if not os.path.exists(os.path.join(ROOT, "assets/ui", f"button_{b}.png")):
            errors.append(f"нет кнопки assets/ui/button_{b}.png")
    for t in ["asphalt", "concrete", "stone", "sand", "grass", "wood", "brick_red", "water", "lane_dashes"]:
        if not os.path.exists(os.path.join(ROOT, "assets/textures", t + ".png")):
            errors.append(f"нет текстуры assets/textures/{t}.png")
    if not os.path.exists(os.path.join(ROOT, "assets/ui/panel.png")):
        errors.append("нет assets/ui/panel.png")


def check_gd():
    count = 0
    for p in files((".gd",)):
        count += 1
        text = open(p, encoding="utf-8").read()
        lines = text.split("\n")
        for i, line in enumerate(lines, 1):
            if line.startswith(" ") and line.strip() and not line.strip().startswith("#"):
                errors.append(f"{rel(p)}:{i}: отступ пробелами (нужны табы)")
                break
        for i, line in enumerate(lines, 1):
            lead = line[: len(line) - len(line.lstrip("\t"))]
            if "\t" in line.lstrip("\t").split("#")[0] and False:
                pass
            for pat, msg in GODOT3_PATTERNS:
                if re.search(pat, line) and not line.strip().startswith("#"):
                    errors.append(f"{rel(p)}:{i}: {msg}")
        # баланс скобок вне строк и комментариев
        depth = {"(": 0, "[": 0, "{": 0}
        pair = {")": "(", "]": "[", "}": "{"}
        in_str = None
        for i, line in enumerate(lines, 1):
            j = 0
            while j < len(line):
                ch = line[j]
                if in_str:
                    if ch == "\\":
                        j += 2
                        continue
                    if ch == in_str:
                        in_str = None
                elif ch == "#":
                    break
                elif ch in "\"'":
                    in_str = ch
                elif ch in depth:
                    depth[ch] += 1
                elif ch in pair:
                    depth[pair[ch]] -= 1
                    if depth[pair[ch]] < 0:
                        errors.append(f"{rel(p)}:{i}: лишняя закрывающая скобка")
                        depth[pair[ch]] = 0
                j += 1
            in_str = None  # строки в GDScript не переносятся (кроме тройных кавычек, не используются)
        for k, v in depth.items():
            if v != 0:
                errors.append(f"{rel(p)}: несбалансированные скобки {k}")
        # наличие extends
        if not re.search(r"^extends\s", text, re.M):
            errors.append(f"{rel(p)}: нет extends")
    return count


def check_tscn():
    rx_ext = re.compile(r'\[ext_resource[^\]]*path="([^"]+)"')
    count = 0
    for p in files((".tscn",)):
        count += 1
        text = open(p, encoding="utf-8").read()
        for m in rx_ext.finditer(text):
            if m.group(1).startswith("res://") and not res_exists(m.group(1)):
                errors.append(f"{rel(p)}: ext_resource не найден {m.group(1)}")
        ids = re.findall(r'ExtResource\("([^"]+)"\)', text)
        declared = re.findall(r'\[ext_resource[^\]]*id="([^"]+)"', text)
        for i in ids:
            if i not in declared:
                errors.append(f"{rel(p)}: ExtResource {i} не объявлен")
        subs = re.findall(r'SubResource\("([^"]+)"\)', text)
        sub_declared = re.findall(r'\[sub_resource[^\]]*id="([^"]+)"', text)
        for s in subs:
            if s not in sub_declared:
                errors.append(f"{rel(p)}: SubResource {s} не объявлен")
    return count


def check_project():
    text = open(os.path.join(ROOT, "project.godot"), encoding="utf-8").read()
    m = re.search(r'run/main_scene="([^"]+)"', text)
    if not m or not res_exists(m.group(1)):
        errors.append("project.godot: стартовая сцена не найдена")
    for name, path in re.findall(r'^(\w+)="\*(res://[^"]+)"', text, re.M):
        if not res_exists(path):
            errors.append(f"project.godot: автозагрузка {name} -> нет {path}")
    if 'import_etc2_astc=true' not in text:
        errors.append("project.godot: не включён import_etc2_astc (нужен для Android)")
    for need in ["GodotCompat"]:
        pass
    if not os.path.exists(os.path.join(ROOT, "export_presets.cfg")):
        errors.append("нет export_presets.cfg")
    else:
        ep = open(os.path.join(ROOT, "export_presets.cfg"), encoding="utf-8").read()
        if 'platform="Android"' not in ep or 'name="Android"' not in ep:
            errors.append("export_presets.cfg: нет пресета Android")


def check_empty_files():
    for p in files((".gd", ".tscn", ".png", ".yml", ".cfg", ".godot")):
        if os.path.getsize(p) == 0:
            errors.append(f"{rel(p)}: пустой файл")


def main():
    check_project()
    check_res_refs()
    check_dynamic_assets()
    n_gd = check_gd()
    n_scn = check_tscn()
    check_empty_files()
    print(f"Проверено: {n_gd} скриптов .gd, {n_scn} сцен .tscn")
    for w in warnings:
        print("ПРЕДУПРЕЖДЕНИЕ:", w)
    if errors:
        print(f"\nНАЙДЕНО ОШИБОК: {len(errors)}")
        for e in errors:
            print(" -", e)
        sys.exit(1)
    print("Статическая проверка пройдена (без запуска Godot).")


if __name__ == "__main__":
    main()
