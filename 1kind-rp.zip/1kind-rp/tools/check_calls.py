#!/usr/bin/env python3
"""Кросс-проверка вызовов автозагрузок: GameState.*, JobSystem.*, NetworkService.*,
AudioManager.*, GameSettings.*, AccountManager.* — метод должен существовать."""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUTOLOADS = {
    "GameState": "scripts/systems/game_state.gd",
    "JobSystem": "scripts/systems/job_system.gd",
    "NetworkService": "scripts/systems/network_service.gd",
    "AudioManager": "scripts/systems/audio_manager.gd",
    "GameSettings": "scripts/systems/game_settings.gd",
    "AccountManager": "scripts/systems/account_manager.gd",
}

def methods_of(path):
    src = open(os.path.join(ROOT, path), encoding="utf-8").read()
    names = set(re.findall(r"^func (\w+)", src, re.M))
    props = set(re.findall(r"^var (\w+)", src, re.M))
    props |= set(re.findall(r"^const (\w+)", src, re.M))
    props |= set(re.findall(r"^signal (\w+)", src, re.M))
    return names | props

table = {k: methods_of(v) for k, v in AUTOLOADS.items()}
errors = []
checked = 0
for base, dirs, names in os.walk(ROOT):
    dirs[:] = [d for d in dirs if d not in {".git", ".godot", "build", "server"}]
    for n in names:
        if not n.endswith(".gd"):
            continue
        p = os.path.join(base, n)
        src = open(p, encoding="utf-8").read()
        for m in re.finditer(r"\b(GameState|JobSystem|NetworkService|AudioManager|GameSettings|AccountManager)\.(\w+)", src):
            checked += 1
            autoload, member = m.group(1), m.group(2)
            if member not in ("set", "get", "call") and member not in table[autoload]:
                errors.append(f"{os.path.relpath(p, ROOT)}: {autoload}.{member} не найден")

for e in errors:
    print("ОШИБКА:", e)
print(f"Проверено обращений: {checked}, ошибки: {len(errors)}")
sys.exit(1 if errors else 0)
