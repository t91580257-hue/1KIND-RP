#!/usr/bin/env python3
"""Проверка синхронности серверной копии каталогов: server/godot_server/catalogs.gd
должен быть идентичен scripts/systems/catalogs.gd (сервер считает цены и выплаты сам)."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
client = os.path.join(ROOT, "scripts/systems/catalogs.gd")
server = os.path.join(ROOT, "server/godot_server/catalogs.gd")

if not os.path.exists(server):
    print("ОШИБКА: нет server/godot_server/catalogs.gd")
    sys.exit(1)

hc = open(client, "rb").read()
hs = open(server, "rb").read()
if hc != hs:
    print("ОШИБКА: серверный catalogs.gd отличается от клиентского.")
    print("Выполните: cp scripts/systems/catalogs.gd server/godot_server/catalogs.gd")
    sys.exit(1)
print("Серверный каталог синхронен с клиентским: OK")
