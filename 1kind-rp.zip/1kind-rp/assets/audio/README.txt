Папка для аудио (.ogg/.wav). В первой версии звуки генерируются кодом (scripts/systems/audio_manager.gd), внешних файлов нет.
