extends CharacterBody3D
## Игрок от третьего лица: движение, бег, прыжок, камера, поиск объектов для взаимодействия.
## Управление: сенсорное (TouchControls) и клавиатура (WASD/стрелки, Shift, Space) для отладки.

signal focus_changed(target)

const ModelScript = preload("res://scripts/player/character_model.gd")

const WALK_SPEED := 4.0
const RUN_SPEED := 7.2
const JUMP_SPEED := 6.2
const GRAVITY := 20.0
const GROUND_ACCEL := 45.0
const AIR_ACCEL := 12.0
const CAM_SPEED := 0.0045
const PITCH_MIN := -1.15
const PITCH_MAX := 0.35

## Узел сенсорного управления (устанавливается миром). Не типизирован намеренно.
var controls = null
var input_enabled: bool = true
var focus_target = null
var driving: bool = false          # игрок за рулём: физика персонажа отключена, ввод идёт в автомобиль
var _yaw: float = 0.0
var _pitch: float = -0.25
var _jump_buffer: float = 0.0
var _focus_timer: float = 0.0
var _was_running: bool = false

@onready var _model: ModelScript = $Model
@onready var _pivot: Node3D = $CameraPivot
@onready var _camera: Camera3D = $CameraPivot/SpringArm3D/Camera3D


func _ready() -> void:
		_yaw = 0.0  # камера за спиной, взгляд на север (к -Z, на фонтан)
		_apply_camera()
		apply_quality()
		GameSettings.settings_changed.connect(apply_quality)


func apply_quality() -> void:
		_camera.far = GameSettings.camera_far()


func request_jump() -> void:
		_jump_buffer = 0.15


func _unhandled_input(event: InputEvent) -> void:
		var key := event as InputEventKey
		if key != null and key.pressed and not key.echo and key.physical_keycode == KEY_SPACE and input_enabled:
				request_jump()


func _physics_process(delta: float) -> void:
		if driving:
				# Вождение: игрок привязан к автомобилю (мир двигает его сам).
				velocity = Vector3.ZERO
				if controls != null and controls.drive_mode:
						var world := get_tree().current_scene
						var car = world.get("_car") if world != null else null
						if car != null and is_instance_valid(car):
								car.steer_input = controls.drive_steer()
								car.throttle = controls.drive_throttle()
								car.brake = controls.drive_brake()
				return
		var move_input := Vector2.ZERO
		var wants_run := false
		if input_enabled:
				move_input = _read_move()
				wants_run = _read_run()
				_read_camera()
		_apply_camera()

		var basis_yaw := Basis(Vector3.UP, _yaw)
		var forward := -basis_yaw.z
		var right := basis_yaw.x
		var wish := right * move_input.x - forward * move_input.y
		var strength := minf(wish.length(), 1.0)
		if wish.length() > 0.001:
				wish = wish.normalized()
		var speed := (RUN_SPEED if wants_run else WALK_SPEED) * strength
		var target_h := wish * speed

		var accel := GROUND_ACCEL if is_on_floor() else AIR_ACCEL
		var h := Vector3(velocity.x, 0.0, velocity.z)
		h = h.move_toward(target_h, accel * delta)
		velocity.x = h.x
		velocity.z = h.z

		if not is_on_floor():
				velocity.y -= GRAVITY * delta
		_jump_buffer = maxf(0.0, _jump_buffer - delta)
		if _jump_buffer > 0.0 and is_on_floor():
				velocity.y = JUMP_SPEED
				_jump_buffer = 0.0

		move_and_slide()

		var hs := Vector2(velocity.x, velocity.z).length()
		if hs > 0.3 and strength > 0.05:
				var target_yaw := atan2(-wish.x, -wish.z)
				_model.rotation.y = lerp_angle(_model.rotation.y, target_yaw, minf(1.0, 14.0 * delta))
		_model.animate(hs, wants_run and hs > WALK_SPEED + 0.5, is_on_floor(), delta)

		_focus_timer -= delta
		if _focus_timer <= 0.0:
				_focus_timer = 0.12
				_update_focus()


func _read_move() -> Vector2:
		var v := Vector2.ZERO
		if controls != null:
				v = controls.move_vector
		if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
				v.x -= 1.0
		if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
				v.x += 1.0
		if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
				v.y -= 1.0
		if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
				v.y += 1.0
		if v.length() > 1.0:
				v = v.normalized()
		return v


func _read_run() -> bool:
		if Input.is_physical_key_pressed(KEY_SHIFT):
				return true
		if controls != null:
				return controls.run_active
		return false


func _read_camera() -> void:
		if controls == null:
				return
		var d: Vector2 = controls.consume_camera_delta()
		if d == Vector2.ZERO:
				return
		var k := CAM_SPEED * GameSettings.camera_sensitivity
		var sign_y := 1.0 if GameSettings.invert_y else -1.0
		_yaw -= d.x * k
		_pitch = clampf(_pitch + sign_y * d.y * k, PITCH_MIN, PITCH_MAX)


func _apply_camera() -> void:
		_pivot.rotation = Vector3(_pitch, _yaw, 0.0)


func _update_focus() -> void:
		if driving:
				return
		var best = null
		var best_d := 1.0e9
		for n in get_tree().get_nodes_in_group("interactable"):
				var node := n as Node3D
				if node == null:
						continue
				var dx := node.global_position.x - global_position.x
				var dz := node.global_position.z - global_position.z
				var d := sqrt(dx * dx + dz * dz)
				var r: float = node.get("radius")
				if d <= r and d < best_d:
						best_d = d
						best = node
		# Посадка в автомобиль рядом (без interactable — проверяем напрямую).
		if best == null and world_car_near():
				best = _car_prompt_stub()
		if best != focus_target:
				focus_target = best
				focus_changed.emit(best)


## Рядом ли управляемый автомобиль игрока.
func world_car_near() -> bool:
		var world := get_tree().current_scene
		if world == null:
				return false
		var car = world.get("_car")
		if car == null or not is_instance_valid(car):
				return false
		return global_position.distance_to(car.global_position) < 3.6 and not car.driven


## Фиктивная цель-подсказка для посадки в автомобиль.
func _car_prompt_stub() -> Node3D:
		if _seat_stub == null:
				_seat_stub = Node3D.new()
				_seat_stub.set_meta("action_id", "car_seat")
				_seat_stub.set_meta("title", "Ваш автомобиль")
				_seat_stub.set_meta("prompt", "Сесть за руль")
				_seat_stub.set_meta("radius", 99.0)
				add_child(_seat_stub)
		return _seat_stub

var _seat_stub: Node3D = null
