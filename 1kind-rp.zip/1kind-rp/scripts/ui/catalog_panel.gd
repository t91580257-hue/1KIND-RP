extends Control
## Универсальная панель каталога: магазин 24/7, агентство недвижимости,
## салон одежды, мебель для квартиры и лицензии мэрии.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

const TITLES: Dictionary = {
		"shop": "Магазин 24/7",
		"property": "Агентство «Золотой ключ»",
		"clothes": "Салон «Мода Ванбург»",
		"furniture": "Мебельный каталог",
		"licenses": "Приёмная мэрии",
}
const NOTES: Dictionary = {
		"shop": "Оплата: наличные, затем банковская карта. Товары попадают в инвентарь.",
		"property": "Покупка записывается в профиль. Войти в своё жильё: Телефон → Дом.",
		"clothes": "Одежда меняет внешний вид персонажа сразу после покупки.",
		"furniture": "Мебель доставляется в квартиру (не занимает рюкзак).",
		"licenses": "Лицензии открывают бизнес и новые работы.",
}

## Варианты одежды (внешность). kind внешности -> цена.
const CLOTHES: Dictionary = {
		"shirt_crimson": {"name": "Рубашка «Алая корона»", "price": 4500, "key": "shirt", "hex": "c0392b"},
		"shirt_gold": {"name": "Рубашка «Золотой трон»", "price": 12000, "key": "shirt", "hex": "ffbe28"},
		"shirt_navy": {"name": "Рубашка «Глубина»", "price": 4500, "key": "shirt", "hex": "0a1630"},
		"shirt_forest": {"name": "Рубашка «Хвоя»", "price": 4500, "key": "shirt", "hex": "27ae60"},
		"shirt_white": {"name": "Рубашка «Снег»", "price": 6000, "key": "shirt", "hex": "f2f2f2"},
		"shirt_violet": {"name": "Рубашка «Аметист»", "price": 9000, "key": "shirt", "hex": "8e44ad"},
		"pants_slate": {"name": "Брюки «Сланец»", "price": 3800, "key": "pants", "hex": "2c3e50"},
		"pants_sand": {"name": "Брюки «Песок»", "price": 3800, "key": "pants", "hex": "5a4634"},
		"pants_ash": {"name": "Джинсы «Пепел»", "price": 4200, "key": "pants", "hex": "7f8c8d"},
		"pants_ink": {"name": "Брюки «Чернила»", "price": 5000, "key": "pants", "hex": "1d1f24"},
		"shoes_white": {"name": "Кроссовки «Облако»", "price": 7000, "key": "shoes", "hex": "f2f2f2"},
		"shoes_night": {"name": "Кроссовки «Полночь»", "price": 7000, "key": "shoes", "hex": "1d1f24"},
}

var kind: String = "shop"
var purchase_target_property: String = ""   # для kind="furniture": куда доставлять

var _rows: Dictionary = {}
var _balance_label: Label


func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(UiKit.make_dim())
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(center)
		var panel := UiKit.make_panel()
		panel.custom_minimum_size = Vector2(860, 580)
		center.add_child(panel)
		var root := VBoxContainer.new()
		root.add_theme_constant_override("separation", 10)
		panel.add_child(root)

		root.add_child(UiKit.make_title(String(TITLES.get(kind, "Каталог")), 36))
		_balance_label = UiKit.make_label("", 26, UiKit.COLOR_GOLD)
		_balance_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		root.add_child(_balance_label)
		var note := UiKit.make_label(String(NOTES.get(kind, "")), 18, UiKit.COLOR_MUTED)
		note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		note.custom_minimum_size = Vector2(720, 0)
		root.add_child(note)

		var scroll := ScrollContainer.new()
		scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
		scroll.custom_minimum_size = Vector2(0, 300)
		scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		root.add_child(scroll)
		var list := VBoxContainer.new()
		list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		list.add_theme_constant_override("separation", 8)
		scroll.add_child(list)

		var catalog := _catalog()
		for id in catalog.keys():
				_add_row(list, String(id), catalog[id])

		var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 62))
		close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		close.pressed.connect(func() -> void: closed.emit())
		root.add_child(close)

		GameState.balance_changed.connect(_on_balance_changed)
		GameState.inventory_changed.connect(_update_states)
		_update_states()


func _catalog() -> Dictionary:
		match kind:
				"shop":
						return Catalogs.get_catalog("shop")
				"property":
						return Catalogs.PROPERTY
				"clothes":
						return CLOTHES
				"furniture":
						var out: Dictionary = {}
						for id in Catalogs.ITEMS:
								if String(Catalogs.ITEMS[id].get("kind", "")) == "furniture":
										out[id] = Catalogs.ITEMS[id]
						return out
				"licenses":
						return Catalogs.LICENSES
		return {}


func _item_name(id: String, entry: Dictionary) -> String:
		if kind == "property":
				return Catalogs.property_name(id)
		return String(entry.get("name", id))


func _item_price(entry: Dictionary) -> int:
		return int(entry.get("price", 0))


func _item_desc(entry: Dictionary) -> String:
		return String(entry.get("desc", ""))


func _on_balance_changed(_value: int) -> void:
		_update_states()


func _add_row(parent: Control, id: String, entry: Dictionary) -> void:
		var row_panel := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.06, 0.14, 0.3, 0.8)
		sb.border_color = UiKit.COLOR_BLUE
		sb.set_border_width_all(1)
		sb.set_corner_radius_all(12)
		sb.content_margin_left = 12
		sb.content_margin_right = 12
		sb.content_margin_top = 8
		sb.content_margin_bottom = 8
		row_panel.add_theme_stylebox_override("panel", sb)
		parent.add_child(row_panel)

		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 14)
		row_panel.add_child(row)
		row.add_child(UiKit.make_icon(String(entry.get("icon", "star")), 56))

		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(info)
		info.add_child(UiKit.make_label(_item_name(id, entry), 24, UiKit.COLOR_TEXT))
		var base_desc := _item_desc(entry)
		var desc := UiKit.make_label(base_desc, 18, UiKit.COLOR_MUTED)
		info.add_child(desc)

		var value := UiKit.make_label(GameState.fmt_money(_item_price(entry)), 22, UiKit.COLOR_GOLD)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		row.add_child(value)

		var btn := UiKit.make_button("Купить", "gold", Vector2(170, 56), 24)
		btn.pressed.connect(_on_action.bind(id))
		row.add_child(btn)
		_rows[id] = {"button": btn, "desc": desc, "base_desc": base_desc}


func _on_action(id: String) -> void:
		var result: Dictionary
		match kind:
				"shop":
						result = GameState.buy("shop", id)
				"property":
						result = GameState.buy("property", id)
				"licenses":
						result = GameState.buy_license(id)
				"furniture":
						var target := purchase_target_property
						if target == "":
								for p in GameState.owned_property:
										target = String(p)
										break
						result = GameState.buy_furniture(target, id)
				"clothes":
						result = _buy_clothes(id)
				_:
						result = {"ok": false, "text": "Неизвестный раздел."}
		GameState.notify(String(result["text"]))
		if not bool(result["ok"]):
				AudioManager.play_sfx("error")
		_update_states()


func _buy_clothes(id: String) -> Dictionary:
		if not CLOTHES.has(id):
				return {"ok": false, "text": "Модель не найдена."}
		var c: Dictionary = CLOTHES[id]
		if not GameState.charge(int(c["price"]), "Одежда: %s" % String(c["name"])):
				return {"ok": false, "text": "Недостаточно средств."}
		GameState.appearance[String(c["key"])] = String(c["hex"])
		GameState.save_profile()
		# Мгновенно применяем к модели игрока.
		var world := get_tree().current_scene
		if world != null:
				var player = world.get("_player")
				if player != null and is_instance_valid(player):
						GameState.apply_appearance_to_model(player.get_node("Model"))
		return {"ok": true, "text": "Новое: %s" % String(c["name"])}


func _update_states() -> void:
		_balance_label.text = "Наличные: %s   ·   Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)]
		var catalog := _catalog()
		for id in _rows.keys():
				var row: Dictionary = _rows[id]
				var btn: Button = row["button"]
				var desc: Label = row["desc"]
				var base_desc: String = row["base_desc"]
				var entry: Dictionary = catalog.get(String(id), {})
				match kind:
						"shop":
								var have := GameState.item_total(String(id))
								desc.text = base_desc if have == 0 else "%s  (у вас: %d)" % [base_desc, have]
								btn.text = "Купить"
								btn.disabled = GameState.total_money() < _item_price(entry)
						"property":
								var owned_p := GameState.owned_property.has(id)
								btn.text = "Куплено" if owned_p else "Купить"
								btn.disabled = owned_p or GameState.total_money() < _item_price(entry)
						"licenses":
								var has_l := GameState.has_license(String(id))
								btn.text = "Получена" if has_l else "Купить"
								btn.disabled = has_l or GameState.total_money() < _item_price(entry)
						"furniture":
								var target := purchase_target_property
								if target == "":
										for p in GameState.owned_property:
												target = String(p)
												break
								var owned_f: bool = false
								if target != "":
										var spot := String(entry.get("spot", ""))
										for f in GameState.apartment_furniture(target):
												if String(Catalogs.item_def(String(f)).get("spot", "")) == spot:
														owned_f = true
								btn.text = "Стоит" if owned_f else "Купить"
								btn.disabled = owned_f or target == "" or GameState.total_money() < _item_price(entry)
								if target == "":
										btn.disabled = true
						"clothes":
								var wearing: bool = String(GameState.appearance.get(String(entry.get("key", "")), "")) == String(entry.get("hex", ""))
								desc.text = base_desc + ("  ·  на вас" if wearing else "")
								btn.text = "Надеть" if wearing else "Купить"
								btn.disabled = wearing or GameState.total_money() < _item_price(entry)
