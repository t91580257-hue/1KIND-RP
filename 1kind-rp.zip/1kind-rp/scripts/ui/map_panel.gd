extends Control
## Карта Ванбурга: сетка дорог, районы, точки интереса, игрок и маркеры заданий.
## Рисуется на _draw по данным city_layout.gd и job_points.gd.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Layout = preload("res://scripts/world/city_layout.gd")
const Points = preload("res://scripts/world/job_points.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

const WORLD_HALF := 1000.0

var _world: Node3D = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim(0.82))
	_world = get_tree().current_scene
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var root := MarginContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("margin_left", 16)
	root.add_theme_constant_override("margin_right", 16)
	root.add_theme_constant_override("margin_top", 12)
	root.add_theme_constant_override("margin_bottom", 12)
	add_child(root)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	root.add_child(vb)
	vb.add_child(UiKit.make_title("Карта Ванбурга", 34))
	var map_panel := UiKit.make_panel()
	map_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(map_panel)
	var map_holder := Control.new()
	map_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	map_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	map_holder.draw.connect(_draw_map.bind(map_holder))
	map_panel.add_child(map_holder)
	# Панель легенды.
	var legend := UiKit.make_panel()
	vb.add_child(legend)
	var lg := HBoxContainer.new()
	lg.add_theme_constant_override("separation", 16)
	legend.add_child(lg)
	_legend(lg, Color("ffbe28"), "задания/маркеры")
	_legend(lg, Color("1e90ff"), "гонки/полиция")
	_legend(lg, Color("6bffa6"), "вы/авто")
	_legend(lg, Color("e74c3c"), "банды/розыск")
	_legend(lg, Color("c9a227"), "сервисы")
	var close := UiKit.make_button("Закрыть карту", "dark", Vector2(320, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	vb.add_child(close)


func _legend(parent: Control, col: Color, text: String) -> void:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6)
	parent.add_child(row)
	var dot := ColorRect.new()
	dot.color = col
	dot.custom_minimum_size = Vector2(18, 18)
	row.add_child(dot)
	row.add_child(UiKit.make_label(text, 16, UiKit.COLOR_TEXT))


func _to_map(p: Vector3, holder: Control) -> Vector2:
	var sz := holder.size
	if sz.x < 10.0:
		sz = Vector2(600, 600)
	var k := minf(sz.x, sz.y) / (WORLD_HALF * 2.0)
	return Vector2(sz.x * 0.5 + p.x * k, sz.y * 0.5 + p.z * k)


func _draw_map(holder: Control) -> void:
	var sz := holder.size
	var center := Vector2(sz.x * 0.5, sz.y * 0.5)
	var k := minf(sz.x, sz.y) / (WORLD_HALF * 2.0)
	# Фон района площади.
	holder.draw_rect(Rect2(center + Vector2(-20, -20) * k, Vector2(40, 40) * k), Color(0.3, 0.36, 0.5, 0.5))
	# Внешние районы.
	for r in [{"c": Vector2(-105, -105), "col": Color(0.55, 0.35, 0.2, 0.35)}, {"c": Vector2(105, -105), "col": Color(0.3, 0.45, 0.6, 0.35)}, {"c": Vector2(-105, 105), "col": Color(0.25, 0.5, 0.3, 0.35)}, {"c": Vector2(105, 105), "col": Color(0.2, 0.4, 0.55, 0.35)}]:
		holder.draw_rect(Rect2(center + Vector2(r["c"].x - 26, r["c"].z - 24) * k, Vector2(52, 48) * k), r["col"])
	# Дороги.
	var road_col := Color(0.25, 0.3, 0.42)
	for line in Layout.LINES:
		var l: float = line
		holder.draw_line(center + Vector2(-WORLD_HALF, l) * k, center + Vector2(WORLD_HALF, l) * k, road_col, maxf(2.0, 12.0 * k))
		holder.draw_line(center + Vector2(l, -WORLD_HALF) * k, center + Vector2(l, WORLD_HALF) * k, road_col, maxf(2.0, 12.0 * k))
	# Места интереса.
	var p_marker := func(holder2: Control, pos: Vector3, col: Color, radius: float = 7.0) -> void:
		holder2.draw_circle(_to_map(pos, holder2), radius, col)
	# Сервисы (золотистые).
	for p in Points.FUEL_STATIONS:
		p_marker.call(holder, p, Color("c9a227"), 8.0)
	p_marker.call(holder, Points.HOSPITAL, Color("ff5a5f"), 8.0)
	p_marker.call(holder, Points.POLICE_STATION, Color("1e90ff"), 8.0)
	p_marker.call(holder, Points.MARKET_STALL, Color("c9a227"), 7.0)
	p_marker.call(holder, Points.PAWNSHOP, Color("c9a227"), 7.0)
	p_marker.call(holder, Points.BLACK_MARKET, Color("7038a0"), 7.0)
	p_marker.call(holder, Points.CLOTHING_SHOP, Color("c06fb8"), 7.0)
	p_marker.call(holder, Points.TUNING_SHOP, Color("c9a227"), 7.0)
	p_marker.call(holder, Points.RAW_DEPOT, Color("c9a227"), 7.0)
	p_marker.call(holder, Points.FARM_BARN, Color("c9a227"), 7.0)
	p_marker.call(holder, Points.RACE_FOOT_START, Color("1e90ff"), 8.0)
	p_marker.call(holder, Points.ARMY_BASE, Color("2f4f2f"), 8.0)
	# Работы (золотые точки).
	for job_pos in [Points.COURIER_GIVER, Points.LOADER_BOXES[1], Points.BUILDER_SITE, Points.MECHANIC_NPC, Points.FISH_SPOT, Points.TRUCK_LOAD, Points.TAXI_STOPS[0]]:
		p_marker.call(holder, job_pos, Color("ffbe28"), 6.0)
	# Территории банд.
	for gang_id in Points.GANG_FLAGS:
		var state := GameState.territory_state(gang_id)
		var col := Color(String(Catalogs.GANGS[gang_id]["color"]))
		if String(state.get("owner", "gang")) == "player":
			col = Color("6bffa6")
		var fp: Vector3 = Points.GANG_FLAGS[gang_id]
		holder.draw_circle(_to_map(fp, holder), 14.0 * (GANG_ZONE_SCALE), Color(col.r, col.g, col.b, 0.35))
		p_marker.call(holder, fp, col, 6.0)
	# Текущий маркер задания/гонки/обучения.
	if JobSystem.is_active() and JobSystem.current_task().has("pos"):
		var tp: Vector3 = JobSystem.current_marker_pos()
		p_marker.call(holder, tp, Color("ffbe28"), 10.0)
		holder.draw_circle(_to_map(tp, holder), 16.0, Color(1.0, 0.75, 0.16, 0.35))
	if _world != null and _world.get("races") != null:
		var races = _world.get("races")
		if races.is_active():
			var cps: Array = races.checkpoints
			if races.cp_index < cps.size():
				p_marker.call(holder, cps[races.cp_index], Color("1e90ff"), 10.0)
	# Игрок и его автомобиль.
	if _world != null:
		var player = _world.get("_player")
		if player != null and is_instance_valid(player):
			var pp: Vector3 = player.global_position
			var mp := _to_map(pp, holder)
			holder.draw_circle(mp, 8.0, Color("6bffa6"))
			holder.draw_arc(mp, 12.0, 0.0, TAU, 24, Color("6bffa6"), 2.0)
		var car = _world.get("_car")
		if car != null and is_instance_valid(car):
			p_marker.call(holder, car.global_position, Color("1e90ff"), 6.0)


const GANG_ZONE_SCALE := 2.2
