extends Control
## Телефон игрока: приложения — Паспорт, Банк, Гараж, Дом, Экстренные службы,
## Работы, Карта, Чат. Единый тёмно-синий корпус с золотой рамкой.

signal closed
signal open_map_requested
signal enter_home_requested
signal furniture_requested
signal call_car_requested
signal tow_requested

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

var _body: VBoxContainer
var _title_label: Label
var _back_btn: Button


func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(UiKit.make_dim())
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(center)

		# Корпус телефона.
		var phone_panel := PanelContainer.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.02, 0.05, 0.12, 0.98)
		sb.border_color = UiKit.COLOR_GOLD
		sb.set_border_width_all(4)
		sb.set_corner_radius_all(28)
		sb.content_margin_left = 18
		sb.content_margin_right = 18
		sb.content_margin_top = 14
		sb.content_margin_bottom = 18
		phone_panel.add_theme_stylebox_override("panel", sb)
		phone_panel.custom_minimum_size = Vector2(560, 640)
		center.add_child(phone_panel)

		_body = VBoxContainer.new()
		_body.add_theme_constant_override("separation", 12)
		phone_panel.add_child(_body)

		var head := HBoxContainer.new()
		head.add_theme_constant_override("separation", 10)
		_body.add_child(head)
		_back_btn = UiKit.make_button("◀", "dark", Vector2(80, 56), 28)
		_back_btn.pressed.connect(_show_apps)
		head.add_child(_back_btn)
		_title_label = UiKit.make_title("Телефон", 30)
		_title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		head.add_child(_title_label)
		var battery := UiKit.make_icon("phone", 44)
		head.add_child(battery)

		_show_apps()


func _clear_body() -> void:
		for c in _body.get_children():
				if c != _get_head():
						c.queue_free()


func _get_head() -> Control:
		return _body.get_child(0)


func _add(child: Control) -> void:
		_body.add_child(child)


func _set_title(t: String) -> void:
		_title_label.text = t


func _scroll() -> VBoxContainer:
		var sc := ScrollContainer.new()
		sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		_add(sc)
		var vb := VBoxContainer.new()
		vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		vb.add_theme_constant_override("separation", 8)
		sc.add_child(vb)
		return vb


# ---------------------------------------------------------------- приложения

func _show_apps() -> void:
		_set_title("Телефон · %s" % NetworkService.mode_title())
		_back_btn.visible = false
		_clear_body()
		var grid := GridContainer.new()
		grid.columns = 3
		grid.add_theme_constant_override("h_separation", 14)
		grid.add_theme_constant_override("v_separation", 14)
		grid.size_flags_vertical = Control.SIZE_EXPAND_FILL
		_add(grid)
		_app(grid, "user", "Паспорт", _show_passport)
		_app(grid, "money", "Банк", _show_bank)
		_app(grid, "car", "Гараж", _show_garage)
		_app(grid, "home", "Дом", _show_home)
		_app(grid, "health", "Экстренные", _show_emergency)
		_app(grid, "jobs", "Работа", _show_jobs)
		_app(grid, "map", "Карта", func() -> void:
				closed.emit()
				open_map_requested.emit()
		)
		_app(grid, "chat", "Чат", _show_chat)
		_app(grid, "star", "Статистика", _show_stats)
		var hint := UiKit.make_label("Клавиши: T — телефон, M — карта, I — инвентарь, E — действие", 16, UiKit.COLOR_MUTED)
		hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_add(hint)


func _app(grid: Control, icon: String, label: String, on_press: Callable) -> void:
		var b := Button.new()
		b.custom_minimum_size = Vector2(150, 130)
		b.focus_mode = Control.FOCUS_NONE
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.06, 0.14, 0.32, 0.95)
		sb.set_corner_radius_all(18)
		b.add_theme_stylebox_override("normal", sb)
		var sb2 := sb.duplicate() as StyleBoxFlat
		sb2.bg_color = Color(0.1, 0.22, 0.45)
		b.add_theme_stylebox_override("hover", sb2)
		b.add_theme_stylebox_override("pressed", sb2)
		var vb := VBoxContainer.new()
		vb.alignment = BoxContainer.ALIGNMENT_CENTER
		vb.add_theme_constant_override("separation", 8)
		vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_child(vb)
		var ic := UiKit.make_icon(icon, 56)
		ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		vb.add_child(ic)
		var l := UiKit.make_label(label, 20, UiKit.COLOR_TEXT)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.mouse_filter = Control.MOUSE_FILTER_IGNORE
		vb.add_child(l)
		b.pressed.connect(func() -> void:
				AudioManager.play_sfx("click")
				_back_btn.visible = true
				on_press.call()
		)
		grid.add_child(b)


# ---------------------------------------------------------------- паспорт

func _show_passport() -> void:
		_set_title("Паспорт гражданина")
		_clear_body()
		var p := GameState.passport
		var vb := _scroll()
		var name := String(p.get("first", "")) + " " + String(p.get("last", ""))
		if name.strip_edges() == "":
				name = GameState.nickname
		_line(vb, "ФИО", name)
		_line(vb, "Пол", "мужской" if String(p.get("gender", "м")) == "м" else "женский")
		_line(vb, "Дата рождения", String(p.get("birth", "—")))
		_line(vb, "Город", String(p.get("city", "Ванбург")))
		_line(vb, "Уровень", "%d (опыт %d/%d)" % [GameState.level, GameState.xp, GameState.xp_needed(GameState.level)])
		_line(vb, "Время в игре", GameState.fmt_time(GameState.play_seconds))
		var note := UiKit.make_label("Изменить данные и внешность можно в салоне «Мода Ванбург» (гражданский квартал).", 17, UiKit.COLOR_MUTED)
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(note)


func _line(parent: Control, k: String, v: String) -> void:
		var row := HBoxContainer.new()
		var kl := UiKit.make_label(k, 21, UiKit.COLOR_MUTED)
		kl.custom_minimum_size = Vector2(190, 0)
		row.add_child(kl)
		row.add_child(UiKit.make_label(v, 21, UiKit.COLOR_TEXT))
		parent.add_child(row)


# ---------------------------------------------------------------- банк

func _show_bank() -> void:
		_set_title("Банк «Корона»")
		_clear_body()
		var vb := _scroll()
		_line(vb, "Наличные", GameState.fmt_money(GameState.cash))
		_line(vb, "Счёт", GameState.fmt_money(GameState.bank))
		_line(vb, "КАСКО", "действует ещё %d мин" % int(maxf(0.0, GameState.insurance_until - Time.get_unix_time_from_system()) / 60.0) if GameState.insurance_active() else "не оформлено")
		var ins := UiKit.make_button("Оформить КАСКО — %s (30 мин: бесплатный ремонт и штрафстоянка)" % GameState.fmt_money(GameState.INSURANCE_PRICE), "gold", Vector2(460, 84), 19)
		ins.pressed.connect(func() -> void:
				var r := GameState.buy_insurance()
				GameState.notify(String(r["text"]))
				_show_bank()
		)
		vb.add_child(ins)
		var note := UiKit.make_label("Переводы другим игрокам и пособия — в банкомате на площади. В онлайн-режиме счёт ведёт сервер.", 17, UiKit.COLOR_MUTED)
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(note)


# ---------------------------------------------------------------- гараж

func _show_garage() -> void:
		_set_title("Гараж")
		_clear_body()
		var vb := _scroll()
		if GameState.owned_cars.is_empty():
				vb.add_child(UiKit.make_label("Гараж пуст. Автосалоны — в торговом квартале.", 21, UiKit.COLOR_MUTED))
				return
		for c in GameState.owned_cars:
				var uid := String(c["uid"])
				var def: Dictionary = Catalogs.CARS.get(String(c["id"]), {})
				var impounded := bool(c.get("impound", false))
				var active := String(GameState.active_car_uid) == uid
				var box := PanelContainer.new()
				var sb := StyleBoxFlat.new()
				sb.bg_color = Color(0.06, 0.14, 0.3, 0.9)
				sb.set_corner_radius_all(14)
				sb.content_margin_left = 12
				sb.content_margin_right = 12
				sb.content_margin_top = 8
				sb.content_margin_bottom = 8
				box.add_theme_stylebox_override("panel", sb)
				vb.add_child(box)
				var col := VBoxContainer.new()
				col.add_theme_constant_override("separation", 4)
				box.add_child(col)
				var title := "%s  ·  топливо %d/%d л  ·  износ %d%%" % [
						String(def.get("name", c["id"])),
						int(float(c.get("fuel", 0.0))),
						int(def.get("tank", 0)),
						int(float(c.get("damage", 0.0))),
				]
				col.add_child(UiKit.make_label(title + ("  · НА ШТРАФСТОЯНКЕ" if impounded else ("  · У ГАРАЖА" if not active else "")), 20, UiKit.COLOR_GOLD if not impounded else UiKit.COLOR_ERROR))
				var row := HBoxContainer.new()
				row.add_theme_constant_override("separation", 8)
				col.add_child(row)
				var call_btn := UiKit.make_button("Подать к гаражу", "blue", Vector2(200, 52), 18)
				call_btn.disabled = impounded or active
				call_btn.pressed.connect(func() -> void:
						call_car_requested.emit()
						closed.emit()
				)
				row.add_child(call_btn)
				if impounded:
						var tow_btn := UiKit.make_button("Эвакуатор (КАСКО/штраф)", "gold", Vector2(230, 52), 17)
						tow_btn.pressed.connect(func() -> void:
								tow_requested.emit(uid)
								_show_garage()
						)
						row.add_child(tow_btn)
				var sell_btn := UiKit.make_button("Продать (%s)" % GameState.fmt_money(Catalogs.car_sell_price(c)), "dark", Vector2(210, 52), 17)
				sell_btn.pressed.connect(func() -> void:
						var r := GameState.sell_car(uid)
						GameState.notify(String(r["text"]))
						_show_garage()
				)
				row.add_child(sell_btn)


# ---------------------------------------------------------------- дом

func _show_home() -> void:
		_set_title("Дом")
		_clear_body()
		var vb := _scroll()
		if GameState.owned_property.is_empty():
				vb.add_child(UiKit.make_label("Недвижимости нет. Агентство «Золотой ключ» — торговый квартал.", 21, UiKit.COLOR_MUTED))
				return
		for prop_id in GameState.owned_property:
				var def: Dictionary = Catalogs.PROPERTY.get(String(prop_id), {})
				vb.add_child(UiKit.make_label(String(def.get("name", prop_id)), 22, UiKit.COLOR_GOLD))
				var row := HBoxContainer.new()
				row.add_theme_constant_override("separation", 8)
				vb.add_child(row)
				var enter := UiKit.make_button("Войти", "gold", Vector2(170, 52), 20)
				enter.pressed.connect(func() -> void:
						enter_home_requested.emit()
						closed.emit()
				)
				row.add_child(enter)
				var fur := UiKit.make_button("Мебель", "blue", Vector2(170, 52), 20)
				fur.pressed.connect(func() -> void:
						furniture_requested.emit()
						closed.emit()
				)
				row.add_child(fur)
		var keys := UiKit.make_label("Ключи и доступ друзей к жилью появятся вместе с онлайн-режимом (проверка прав на сервере).", 17, UiKit.COLOR_MUTED)
		keys.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(keys)


# ---------------------------------------------------------------- экстренные

func _show_emergency() -> void:
		_set_title("Экстренные службы")
		_clear_body()
		var vb := _scroll()
		vb.add_child(UiKit.make_label("112 — единый номер Ванбурга", 20, UiKit.COLOR_MUTED))
		var amb := UiKit.make_button("Скорая помощь — %s (лечение через 15 с)" % GameState.fmt_money(800), "gold", Vector2(460, 64), 19)
		amb.pressed.connect(func() -> void: _call_service("ambulance"))
		vb.add_child(amb)
		var taxi := UiKit.make_button("Вызвать такси — %s (машина подаётся рядом)" % GameState.fmt_money(300), "blue", Vector2(460, 64), 19)
		taxi.pressed.connect(func() -> void: _call_service("taxi"))
		vb.add_child(taxi)
		var tow := UiKit.make_button("Эвакуатор со штрафстоянки", "blue", Vector2(460, 64), 19)
		tow.pressed.connect(func() -> void:
				_back_btn.visible = true
				_show_garage()
		)
		vb.add_child(tow)
		var note := UiKit.make_label("Полицейский участок: явка с повинной снижает срок.", 17, UiKit.COLOR_MUTED)
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(note)


func _call_service(kind: String) -> void:
		var world := get_tree().current_scene
		if world == null or not world.has_method("notify"):
				return
		var services = world.get("services")
		if services == null:
				GameState.notify("Службы недоступны.")
				return
		var r: Dictionary
		if kind == "ambulance":
				r = services.call_ambulance()
		else:
				r = services.call_taxi_car()
		GameState.notify(String(r["text"]))


# ---------------------------------------------------------------- работа

func _show_jobs() -> void:
		_set_title("Работа")
		_clear_body()
		var vb := _scroll()
		if JobSystem.is_active():
				vb.add_child(UiKit.make_label("Активная смена: %s" % Catalogs.job_name(JobSystem.active_job), 22, UiKit.COLOR_GOLD))
				vb.add_child(UiKit.make_label(JobSystem.task_text(), 20, UiKit.COLOR_TEXT))
				var ab := UiKit.make_button("Прервать смену (без выплаты)", "purple", Vector2(460, 56), 19)
				ab.pressed.connect(func() -> void:
						JobSystem.cancel_session()
						_show_jobs()
				)
				vb.add_child(ab)
		vb.add_child(UiKit.make_label("Навыки профессий:", 20, UiKit.COLOR_MUTED))
		for job_id in Catalogs.JOBS:
				var skill := GameState.job_skill(String(job_id))
				var lvl_name: String = Catalogs.JOB_LEVELS[skill["level"] - 1]
				var need: int = skill["need"]
				var xp_text := "%d XP" % int(skill["xp"]) if need == 0 else "%d/%d XP" % [int(skill["xp"]), need]
				_line(vb, Catalogs.job_name(String(job_id)), "%s · ур.%d · %s" % [lvl_name, int(skill["level"]), xp_text])
		var hint := UiKit.make_label("Устраивайтесь у NPC на местах работ или через Центр занятости в ратуше. Зарплата растёт с уровнем навыка и рангом в организации.", 17, UiKit.COLOR_MUTED)
		hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(hint)


# ---------------------------------------------------------------- чат и статистика

func _show_chat() -> void:
		_set_title("Чат")
		_clear_body()
		var vb := _scroll()
		if NetworkService.is_online():
				vb.add_child(UiKit.make_label("Онлайн-чат активен. Полная панель — в игре (кнопка Чат в HUD).", 20, UiKit.COLOR_OK))
		else:
				vb.add_child(UiKit.make_label("Вы офлайн: чат с другими игроками появится при подключении к серверу.", 20, UiKit.COLOR_MUTED))
		vb.add_child(UiKit.make_label("Последние события:", 20, UiKit.COLOR_GOLD))
		var shown := 0
		for e in GameState.ledger:
				if shown >= 10:
						break
				shown += 1
				vb.add_child(UiKit.make_label("%s" % String(e.get("text", "")), 18, UiKit.COLOR_TEXT))


func _show_stats() -> void:
		_set_title("Статистика")
		_clear_body()
		var vb := _scroll()
		_line(vb, "Смен отработано", str(int(GameState.statistics.get("jobs_done", 0))))
		_line(vb, "Задач выполнено", str(int(GameState.statistics.get("tasks_done", 0))))
		_line(vb, "Задержаний", str(int(GameState.statistics.get("arrests", 0))))
		_line(vb, "Побед в гонках", str(int(GameState.statistics.get("races_won", 0))))
		_line(vb, "Рыбы поймано", str(int(GameState.statistics.get("fish_caught", 0))))
		var bf := float(GameState.race_best.get("foot", 0.0))
		var bc := float(GameState.race_best.get("car", 0.0))
		_line(vb, "Рекорд: забег", "%d с" % int(bf) if bf > 0.0 else "—")
		_line(vb, "Рекорд: кольцо", "%d с" % int(bc) if bc > 0.0 else "—")
