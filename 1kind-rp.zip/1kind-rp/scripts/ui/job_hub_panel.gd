extends Control
## Панель работ: список всех профессий с навыком и требованиями (mode="hub")
## или одна профессия с описанием и кнопкой «Начать смену» (mode="one").

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

var mode: String = "hub"
var job_id: String = ""

var _list_vb: VBoxContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(900, 620)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)
	root.add_child(UiKit.make_title("Работа в Ванбурге" if mode == "hub" else Catalogs.job_name(job_id), 36))
	var note := UiKit.make_label("Смена — это реальные задания с маркерами. Выплата: базовая ставка × навык (до ×1.6), для организаций — ещё и ранг. Налог 13%.", 18, UiKit.COLOR_MUTED)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(800, 0)
	root.add_child(note)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 360)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	_list_vb = VBoxContainer.new()
	_list_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list_vb.add_theme_constant_override("separation", 8)
	scroll.add_child(_list_vb)

	if mode == "one":
		_add_job_row(_list_vb, job_id)
	else:
		for jid in Catalogs.JOBS:
			_add_job_row(_list_vb, String(jid))

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)


func _add_job_row(parent: Control, jid: String) -> void:
	var job: Dictionary = Catalogs.JOBS[jid]
	var skill := GameState.job_skill(jid)
	var row := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.14, 0.3, 0.85)
	sb.border_color = UiKit.COLOR_BLUE
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	row.add_theme_stylebox_override("panel", sb)
	parent.add_child(row)

	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	row.add_child(h)
	h.add_child(UiKit.make_icon(String(job.get("icon", "jobs")), 52))
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(info)
	var rank_text := ""
	if job.has("org"):
		rank_text = "  ·  ранг: %s" % String(Catalogs.RANKS[String(job["org"])][GameState.org_rank(String(job["org"])) - 1])
	info.add_child(UiKit.make_label("%s  ·  ур. %d «%s»%s" % [String(job["name"]), int(skill["level"]), String(Catalogs.JOB_LEVELS[skill["level"] - 1]), rank_text], 23, UiKit.COLOR_GOLD))
	var req := "уровень %d+" % int(job["min_level"])
	if job.has("license"):
		req += ", лицензия «%s»" % String(Catalogs.LICENSES[String(job["license"])]["name"])
	if job.has("item"):
		req += ", предмет: %s" % Catalogs.item_name(String(job["item"]))
	if String(job.get("vehicle", "")) == "any":
		req += ", автомобиль"
	var skill_need: int = skill["need"]
	var skill_text := "навык: %d XP" % int(skill["xp"]) if skill_need == 0 else "навык: %d/%d XP" % [int(skill["xp"]), skill_need]
	info.add_child(UiKit.make_label("%s. %s. %s" % [req, String(job["desc"]), skill_text], 17, UiKit.COLOR_MUTED))

	var vb2 := VBoxContainer.new()
	h.add_child(vb2)
	vb2.add_child(UiKit.make_label(GameState.fmt_money(int(job["base_pay"])) + "+", 22, UiKit.COLOR_TEXT))
	var btn := UiKit.make_button("Начать смену", "gold", Vector2(200, 52), 20)
	var check := JobSystem.can_start(jid)
	btn.disabled = not bool(check["ok"])
	btn.text = "В смене" if JobSystem.active_job == jid else btn.text
	if JobSystem.is_active() and JobSystem.active_job != jid:
		btn.disabled = true
		btn.text = "Занят"
	btn.pressed.connect(func() -> void:
		var r := JobSystem.start_job(jid)
		GameState.notify(String(r["text"]))
		if bool(r["ok"]):
			closed.emit()
		else:
			AudioManager.play_sfx("error")
			btn.disabled = not bool(JobSystem.can_start(jid)["ok"])
	)
	vb2.add_child(btn)
