extends Control
## Осмотр и покупка автомобиля в автосалоне (боковая панель, автомобиль виден слева).
## Кнопки «◀ / ▶» поворачивают выставочный автомобиль, цвета перекрашивают его, «Купить» вызывает
## GameState.buy_car(). В режиме owned_index >= 0 панель показывает автомобиль из гаража (без покупки).

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")
const CarFactory = preload("res://scripts/world/car_factory.gd")

var car_id: String = ""
var pivot: Node3D = null            # узел, в котором лежит модель "Car"
var owned_index: int = -1           # индекс в GameState.owned_cars, если режим гаража
var _color: String = ""
var _buy_btn: Button
var _money: Label
var _was_spinning: bool = true


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var def: Dictionary = Catalogs.CARS[car_id]
	_color = String(def["colors"][0])
	if owned_index >= 0:
		_color = String(GameState.owned_cars[owned_index]["color"])
	if pivot != null and pivot.get("spin") != null:
		_was_spinning = bool(pivot.get("spin"))
		pivot.set("spin", false)

	var panel := UiKit.make_panel()
	panel.anchor_left = 0.52
	panel.anchor_right = 1.0
	panel.anchor_top = 0.0
	panel.anchor_bottom = 1.0
	panel.offset_left = 0.0
	panel.offset_right = -12.0
	panel.offset_top = 12.0
	panel.offset_bottom = -12.0
	add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)

	var title := UiKit.make_label(String(def["name"]), 28, UiKit.COLOR_GOLD)
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(title)
	var desc := UiKit.make_label(String(def["desc"]), 18, UiKit.COLOR_MUTED)
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(desc)

	root.add_child(_stat_row("Макс. скорость", float(def["top_speed"]), 360.0, "%d км/ч" % int(def["top_speed"])))
	root.add_child(_stat_row("Разгон до 100", 1.0 - clampf((float(def["accel"]) - 2.5) / 12.5, 0.0, 1.0), 1.0, "%.1f с" % float(def["accel"])))
	root.add_child(_stat_row("Управляемость", float(def["handling"]), 10.0, "%d / 10" % int(def["handling"])))
	root.add_child(_stat_row("Расход топлива", 1.0 - clampf((float(def["fuel"]) - 5.0) / 12.0, 0.0, 1.0), 1.0, "%.1f л/100 км" % float(def["fuel"])))
	root.add_child(UiKit.make_label("Бак: %d л" % int(def["tank"]), 18, UiKit.COLOR_MUTED))

	# Цвет кузова.
	root.add_child(UiKit.make_label("Цвет кузова", 20, UiKit.COLOR_TEXT))
	var colors := HBoxContainer.new()
	colors.add_theme_constant_override("separation", 10)
	root.add_child(colors)
	for hex in def["colors"]:
		var b := Button.new()
		b.custom_minimum_size = Vector2(64, 48)
		b.focus_mode = Control.FOCUS_NONE
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(String(hex))
		sb.set_corner_radius_all(10)
		sb.set_border_width_all(3)
		sb.border_color = UiKit.COLOR_GOLD
		b.add_theme_stylebox_override("normal", sb)
		b.add_theme_stylebox_override("hover", sb)
		b.add_theme_stylebox_override("pressed", sb)
		b.disabled = owned_index >= 0
		b.pressed.connect(_on_color.bind(String(hex)))
		colors.add_child(b)

	var rot := HBoxContainer.new()
	rot.add_theme_constant_override("separation", 10)
	root.add_child(rot)
	var left := UiKit.make_button("◀ Повернуть", "blue", Vector2(180, 52), 20)
	left.pressed.connect(func() -> void: _rotate(-35.0))
	rot.add_child(left)
	var right := UiKit.make_button("Повернуть ▶", "blue", Vector2(180, 52), 20)
	right.pressed.connect(func() -> void: _rotate(35.0))
	rot.add_child(right)

	var price := UiKit.make_label("Цена: %s" % GameState.fmt_money(int(def["price"])), 26, UiKit.COLOR_GOLD)
	root.add_child(price)
	_money = UiKit.make_label("", 18, UiKit.COLOR_MUTED)
	root.add_child(_money)
	if owned_index >= 0:
		var fuel := float(GameState.owned_cars[owned_index]["fuel"])
		root.add_child(UiKit.make_label("Ваш автомобиль · топливо: %.0f / %d л" % [fuel, int(def["tank"])], 20, UiKit.COLOR_OK))
	else:
		_buy_btn = UiKit.make_button("Купить", "gold", Vector2(380, 62), 26)
		_buy_btn.pressed.connect(_on_buy)
		root.add_child(_buy_btn)
	var close := UiKit.make_button("Закрыть", "dark", Vector2(380, 56), 22)
	close.pressed.connect(_on_close)
	root.add_child(close)

	GameState.balance_changed.connect(_on_balance)
	_refresh()


func _exit_tree() -> void:
	if GameState.balance_changed.is_connected(_on_balance):
		GameState.balance_changed.disconnect(_on_balance)


func _stat_row(label: String, value: float, max_v: float, text: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var l := UiKit.make_label(label, 17, UiKit.COLOR_MUTED)
	l.custom_minimum_size = Vector2(150, 0)
	row.add_child(l)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(150, 12)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bar.max_value = max_v
	bar.value = value
	bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.04, 0.08, 0.18, 0.7)
	bg.set_corner_radius_all(6)
	var fg := StyleBoxFlat.new()
	fg.bg_color = UiKit.COLOR_BLUE
	fg.set_corner_radius_all(6)
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fg)
	row.add_child(bar)
	row.add_child(UiKit.make_label(text, 17, UiKit.COLOR_TEXT))
	return row


func _on_balance(_v: int) -> void:
	_refresh()


func _refresh() -> void:
	_money.text = "Наличные: %s  ·  Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)]
	if _buy_btn != null:
		var def: Dictionary = Catalogs.CARS[car_id]
		if GameState.owns_car(car_id):
			_buy_btn.text = "Уже в гараже"
			_buy_btn.disabled = true
		else:
			_buy_btn.text = "Купить"
			_buy_btn.disabled = GameState.total_money() < int(def["price"])


func _rotate(deg: float) -> void:
	if pivot != null:
		pivot.rotation_degrees.y += deg
		AudioManager.play_sfx("click")


func _on_color(hex: String) -> void:
	_color = hex
	if pivot == null:
		return
	var old := pivot.get_node_or_null("Car")
	if old != null:
		old.free()
	var car := CarFactory.build(car_id, hex)
	car.name = "Car"
	pivot.add_child(car)
	AudioManager.play_sfx("click")


func _on_buy() -> void:
	var result := GameState.buy_car(car_id, _color)
	GameState.notify(String(result["text"]))
	if not bool(result["ok"]):
		AudioManager.play_sfx("error")
	_refresh()


func _on_close() -> void:
	if pivot != null and is_instance_valid(pivot) and pivot.get("spin") != null:
		pivot.set("spin", _was_spinning)
	closed.emit()
