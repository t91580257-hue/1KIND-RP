extends Control
## Игровой HUD (v0.3.2) — раскладка как в мобильных RP-играх, сине-жёлтая гамма:
##  • СЛЕВА СВЕРХУ: миникарта + лента чата/событий под ней + район + трекер заданий;
##  • СПРАВА СВЕРХУ: деньги (крупно), банковский счёт, уровень/опыт и полоски
##    здоровья/голода/жажды;
##  • СПРАВА ПО КРАЮ: круглые кнопки Телефон / Инвентарь / Карта;
##  • СНИЗУ СЛЕВА: текущие дата и время;
##  • СВЕРХУ ПО ЦЕНТРУ: розыск, срок СИЗО, уведомления, FPS;
##  • СНИЗУ ПО ЦЕНТРУ: подсказка взаимодействия и спидометр при вождении.

signal inventory_pressed
signal phone_pressed
signal map_pressed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Cat = preload("res://scripts/systems/catalogs.gd")
const Layout = preload("res://scripts/world/city_layout.gd")

var _level_label: Label
var _xp_bar: ProgressBar
var _balance_label: Label
var _bank_label: Label
var _health_bar: ProgressBar
var _hunger_bar: ProgressBar
var _thirst_bar: ProgressBar
var _zone_label: Label
var _prompt_panel: PanelContainer
var _prompt_title: Label
var _prompt_hint: Label
var _toast_panel: PanelContainer
var _toast_label: Label
var _fps_label: Label
var _toast_tween: Tween

# Трекер заданий и обучения.
var _track_panel: PanelContainer
var _track_title: Label
var _track_task: Label
var _track_bar: ProgressBar

# Розыск и тюрьма.
var _wanted_label: Label
var _jail_label: Label

# Вождение.
var _drive_panel: PanelContainer
var _drive_speed: Label
var _drive_fuel: Label
var _drive_name: Label
var _drive_damage: Label

# Миникарта и лента чата.
var _minimap: Control
var _chat_label: Label
var _chat_log: Array = []            # последние строки чата/событий

# Дата и время (внизу слева, как на скриншотах).
var _time_label: Label


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_minimap()
	_build_chat_strip()
	_build_zone()
	_build_tracker()
	_build_money_box()
	_build_progress_box()
	_build_side_buttons()
	_build_time_label()
	_build_prompt()
	_build_toast()
	_fps_label = UiKit.make_label("", 18, UiKit.COLOR_MUTED)
	_place(_fps_label, 0.5, 0.0, 0.0, 6.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	add_child(_fps_label)
	_wanted_label = UiKit.make_label("", 30, UiKit.COLOR_ERROR)
	_wanted_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_wanted_label.add_theme_constant_override("outline_size", 8)
	_place(_wanted_label, 0.5, 0.0, 0.0, 46.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	add_child(_wanted_label)
	_jail_label = UiKit.make_label("", 24, UiKit.COLOR_ERROR)
	_jail_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_jail_label.add_theme_constant_override("outline_size", 8)
	_place(_jail_label, 0.5, 0.0, 0.0, 84.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	_jail_label.visible = false
	add_child(_jail_label)

	GameState.balance_changed.connect(_on_balance_changed)
	GameState.xp_changed.connect(_on_xp_changed)
	GameState.notification.connect(show_toast)
	GameState.notification.connect(_on_log_event)
	NetworkService.chat_received.connect(_on_log_chat)
	GameState.stats_changed.connect(_on_stats_changed)
	_on_stats_changed()
	_on_xp_changed(GameState.level, GameState.xp, GameState.xp_needed(GameState.level))
	_on_balance_changed(GameState.balance)
	_add_log("Добро пожаловать в Ванбург!")


func _place(c: Control, ax: float, ay: float, ox: float, oy: float, gh: int, gv: int) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_right = ox
	c.offset_top = oy
	c.offset_bottom = oy
	c.grow_horizontal = gh
	c.grow_vertical = gv


# ------------------------------------------------ левая колонка

func _build_minimap() -> void:
	var panel := UiKit.make_flat_panel(Color(0.02, 0.07, 0.18, 0.7), 16, UiKit.COLOR_GOLD, 2)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 0.0, 0.0, 16.0, 14.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(panel)
	_minimap = Control.new()
	_minimap.custom_minimum_size = Vector2(150, 150)
	_minimap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_minimap.draw.connect(_draw_minimap)
	panel.add_child(_minimap)


func _build_chat_strip() -> void:
	var panel := UiKit.make_flat_panel(Color(0.01, 0.04, 0.12, 0.55), 12)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 0.0, 0.0, 16.0, 188.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(panel)
	_chat_label = UiKit.make_label("", 16, UiKit.COLOR_TEXT)
	_chat_label.custom_minimum_size = Vector2(320, 44)
	_chat_label.autowrap_mode = TextServer.AUTOWRAP_OFF
	panel.add_child(_chat_label)


func _build_zone() -> void:
	_zone_label = UiKit.make_label("", 19, UiKit.COLOR_GOLD)
	_zone_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_zone_label.add_theme_constant_override("outline_size", 6)
	_place(_zone_label, 0.0, 0.0, 22.0, 256.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(_zone_label)


func _build_tracker() -> void:
	_track_panel = UiKit.make_flat_panel(Color(0.02, 0.07, 0.18, 0.72), 14, UiKit.COLOR_BLUE, 2)
	_track_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_track_panel, 0.0, 0.0, 16.0, 284.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	_track_panel.visible = false
	add_child(_track_panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	_track_panel.add_child(vb)
	_track_title = UiKit.make_label("", 21, UiKit.COLOR_GOLD)
	vb.add_child(_track_title)
	_track_task = UiKit.make_label("", 17, UiKit.COLOR_TEXT)
	_track_task.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_track_task.custom_minimum_size = Vector2(300, 0)
	vb.add_child(_track_task)
	_track_bar = ProgressBar.new()
	_track_bar.custom_minimum_size = Vector2(300, 10)
	_track_bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = UiKit.COLOR_NAVY
	bg.set_corner_radius_all(5)
	var fg := StyleBoxFlat.new()
	fg.bg_color = UiKit.COLOR_OK
	fg.set_corner_radius_all(5)
	_track_bar.add_theme_stylebox_override("background", bg)
	_track_bar.add_theme_stylebox_override("fill", fg)
	vb.add_child(_track_bar)


# ------------------------------------------------ правая колонка

func _build_money_box() -> void:
	var panel := UiKit.make_flat_panel(Color(0.02, 0.07, 0.18, 0.7), 16, UiKit.COLOR_GOLD, 2)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 1.0, 0.0, -16.0, 14.0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
	add_child(panel)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	panel.add_child(hb)
	hb.add_child(UiKit.make_icon("money", 44))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	hb.add_child(vb)
	_balance_label = UiKit.make_label("0", 28, UiKit.COLOR_GOLD)
	vb.add_child(_balance_label)
	_bank_label = UiKit.make_label("", 16, UiKit.COLOR_MUTED)
	vb.add_child(_bank_label)


func _build_progress_box() -> void:
	var panel := UiKit.make_flat_panel(Color(0.01, 0.04, 0.12, 0.6), 14)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 1.0, 0.0, -16.0, 96.0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
	add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	panel.add_child(vb)
	_level_label = UiKit.make_label("Уровень 1", 19, UiKit.COLOR_TEXT)
	vb.add_child(_level_label)
	_xp_bar = ProgressBar.new()
	_xp_bar.custom_minimum_size = Vector2(210, 12)
	_xp_bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = UiKit.COLOR_NAVY
	bg.set_corner_radius_all(6)
	var fg := StyleBoxFlat.new()
	fg.bg_color = UiKit.COLOR_GOLD
	fg.set_corner_radius_all(6)
	_xp_bar.add_theme_stylebox_override("background", bg)
	_xp_bar.add_theme_stylebox_override("fill", fg)
	vb.add_child(_xp_bar)
	_health_bar = _add_stat_bar(vb, Color("ff5a5f"), "health")
	_hunger_bar = _add_stat_bar(vb, Color("ffbe28"), "star")
	_thirst_bar = _add_stat_bar(vb, Color("1e90ff"), "shield")


func _add_stat_bar(vb: VBoxContainer, color: Color, icon_name: String) -> ProgressBar:
	var wrap := HBoxContainer.new()
	wrap.add_theme_constant_override("separation", 6)
	var icon := UiKit.make_icon(icon_name, 20)
	wrap.add_child(icon)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(180, 10)
	bar.max_value = 100.0
	bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.04, 0.08, 0.18, 0.85)
	bg.set_corner_radius_all(5)
	var fg := StyleBoxFlat.new()
	fg.bg_color = color
	fg.set_corner_radius_all(5)
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fg)
	bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	wrap.add_child(bar)
	vb.add_child(wrap)
	return bar


func _build_side_buttons() -> void:
	# Круглые кнопки правым краем под блоком статов (как на скриншотах).
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	_place(col, 1.0, 0.0, -16.0, 224.0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
	add_child(col)
	var phone := UiKit.make_round_button("phone", 64)
	phone.pressed.connect(func() -> void: phone_pressed.emit())
	col.add_child(phone)
	var inv := UiKit.make_round_button("shop", 64)
	inv.pressed.connect(func() -> void: inventory_pressed.emit())
	col.add_child(inv)
	var map_btn := UiKit.make_round_button("map", 64)
	map_btn.pressed.connect(func() -> void: map_pressed.emit())
	col.add_child(map_btn)


func _build_time_label() -> void:
	_time_label = UiKit.make_label("", 21, UiKit.COLOR_TEXT)
	_time_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_time_label.add_theme_constant_override("outline_size", 7)
	# Слева внизу, выше зоны джойстика.
	_place(_time_label, 0.0, 1.0, 18.0, -110.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_BEGIN)
	add_child(_time_label)


# ------------------------------------------------ низ и центр

func _build_prompt() -> void:
	_prompt_panel = UiKit.make_panel()
	_prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_prompt_panel, 0.5, 1.0, 0.0, -34.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BEGIN)
	_prompt_panel.visible = false
	add_child(_prompt_panel)
	var vb := VBoxContainer.new()
	_prompt_panel.add_child(vb)
	_prompt_title = UiKit.make_label("", 26, UiKit.COLOR_GOLD)
	_prompt_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_prompt_title)
	_prompt_hint = UiKit.make_label("", 20, UiKit.COLOR_TEXT)
	_prompt_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_prompt_hint)


func _build_toast() -> void:
	_toast_panel = UiKit.make_panel()
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_toast_panel, 0.5, 0.0, 0.0, 126.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	_toast_panel.modulate.a = 0.0
	add_child(_toast_panel)
	_toast_label = UiKit.make_label("", 24, UiKit.COLOR_TEXT)
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_toast_label.custom_minimum_size = Vector2(600, 0)
	_toast_panel.add_child(_toast_label)


func _build_drive_panel() -> void:
	_drive_panel = UiKit.make_flat_panel(Color(0.02, 0.07, 0.18, 0.74), 16, UiKit.COLOR_GOLD, 2)
	_drive_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_drive_panel, 0.5, 1.0, 0.0, -120.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BEGIN)
	_drive_panel.visible = false
	add_child(_drive_panel)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 22)
	_drive_panel.add_child(hb)
	var vb1 := VBoxContainer.new()
	hb.add_child(vb1)
	_drive_speed = UiKit.make_label("0 км/ч", 34, UiKit.COLOR_GOLD)
	vb1.add_child(_drive_speed)
	_drive_name = UiKit.make_label("", 17, UiKit.COLOR_MUTED)
	vb1.add_child(_drive_name)
	var vb2 := VBoxContainer.new()
	hb.add_child(vb2)
	_drive_fuel = UiKit.make_label("", 20, UiKit.COLOR_TEXT)
	vb2.add_child(_drive_fuel)
	_drive_damage = UiKit.make_label("", 17, UiKit.COLOR_MUTED)
	vb2.add_child(_drive_damage)


# ------------------------------------------------ миникарта

func _draw_minimap() -> void:
	if _minimap == null:
		return
	var sz := _minimap.size
	if sz.x < 10.0:
		return
	var center := Vector2(sz.x * 0.5, sz.y * 0.5)
	var k := minf(sz.x, sz.y) / 300.0      # видно 300 метров вокруг
	var world := get_tree().current_scene
	var me: Node3D = world.get("_player") if world != null else null
	var me_pos := Vector3.ZERO
	if me != null and is_instance_valid(me):
		me_pos = me.global_position
	# Дороги вокруг игрока.
	var road := Color(0.3, 0.36, 0.5)
	for line in Layout.LINES:
		var l: float = line
		var y := (l - me_pos.z) * k + center.y
		if y > -8.0 and y < sz.y + 8.0:
			_minimap.draw_line(Vector2(0, y), Vector2(sz.x, y), road, 3.0)
		var x := (l - me_pos.x) * k + center.x
		if x > -8.0 and x < sz.x + 8.0:
			_minimap.draw_line(Vector2(x, 0), Vector2(x, sz.y), road, 3.0)
	# Маркер задания.
	if JobSystem.is_active() and JobSystem.current_task().has("pos"):
		var d: Vector3 = JobSystem.current_marker_pos() - me_pos
		var off := Vector2(d.x * k, d.z * k)
		var clamped := off.limit_length(minf(sz.x, sz.y) * 0.45)
		_minimap.draw_circle(center + clamped, 6.0, UiKit.COLOR_GOLD)
	# Игрок в центре.
	_minimap.draw_circle(center, 5.0, UiKit.COLOR_OK)
	_minimap.draw_circle(center, 2.0, Color.WHITE)


# ------------------------------------------------ лента чата/событий

func _add_log(text: String) -> void:
	_chat_log.append(text)
	while _chat_log.size() > 2:
		_chat_log.pop_front()
	_chat_label.text = "\n".join(PackedStringArray(_chat_log))


func _on_log_event(text: String) -> void:
	_add_log(text)


func _on_log_chat(from: String, text: String) -> void:
	_add_log("%s: %s" % [from, text])


# ------------------------------------------------ публичный API (без изменений)

func set_zone(text: String) -> void:
	_zone_label.text = text


func set_prompt(title: String, hint: String) -> void:
	if title == "":
		_prompt_panel.visible = false
		return
	_prompt_title.text = title
	_prompt_hint.text = hint
	_prompt_panel.visible = true


func set_tutorial(step: int, title: String, hint: String) -> void:
	_track_panel.visible = step > 0
	if step > 0:
		_track_title.text = "Обучение %d/6 · %s" % [step, title]
		_track_task.text = hint
		_track_bar.value = float(step) / 6.0 * 100.0


func update_tracker() -> void:
	# Работа активна → показываем её вместо обучения (обучение в приоритете, если оба).
	if JobSystem.is_active():
		_track_panel.visible = true
		_track_title.text = "Смена: %s" % Catalogs_job_name(JobSystem.active_job)
		var dist := JobSystem.marker_distance()
		var dist_text := ""
		if dist >= 0.0:
			if dist > 999.0:
				dist_text = "  ·  %.1f км" % (dist / 1000.0)
			else:
				dist_text = "  ·  %d м" % int(dist)
		_track_task.text = JobSystem.task_text() + dist_text
		_track_bar.value = JobSystem.hold_fraction() * 100.0


## Имя профессии без прямого preload каталога (чтобы HUD не зависел от Catalogs).
func Catalogs_job_name(job_id: String) -> String:
	return Cat.job_name(job_id)


func update_wanted(stars: int) -> void:
	if stars > 0:
		_wanted_label.text = "★".repeat(stars) + " РОЗЫСК"
	else:
		_wanted_label.text = ""
	if GameState.is_jailed():
		_jail_label.visible = true
	else:
		_jail_label.visible = false


func update_jail(seconds_left: int) -> void:
	_jail_label.text = "Срок: %d с  ·  скамья сокращает срок, у решётки — залог" % seconds_left


func set_drive_hud(active: bool, car_name: String) -> void:
	if _drive_panel == null:
		_build_drive_panel()
	_drive_panel.visible = active
	if active:
		_drive_name.text = car_name


func show_toast(text: String) -> void:
	_toast_label.text = text
	if _toast_tween != null:
		_toast_tween.kill()
	_toast_panel.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(2.4)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.6)


func set_capture_progress(fraction: float) -> void:
	update_tracker()
	if fraction > 0.0:
		_track_panel.visible = true
		_track_title.text = "Захват территории!"
		_track_task.text = "Продержитесь у флага под атакой банды"
		_track_bar.value = clampf(fraction, 0.0, 1.0) * 100.0


# ------------------------------------------------ обновление данных

func _on_balance_changed(value: int) -> void:
	_balance_label.text = GameState.fmt_money(value)
	_bank_label.text = "Счёт: %s" % GameState.fmt_money(GameState.bank)


func _on_xp_changed(level: int, xp: int, needed: int) -> void:
	_level_label.text = "Уровень %d  ·  %d XP" % [level, xp]
	_xp_bar.max_value = float(needed)
	_xp_bar.value = float(xp)


func _on_stats_changed() -> void:
	_health_bar.value = GameState.health
	_hunger_bar.value = GameState.hunger
	_thirst_bar.value = GameState.thirst


func _process(_delta: float) -> void:
	_fps_label.visible = GameSettings.show_fps
	if GameSettings.show_fps:
		_fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
	update_tracker()
	_minimap.queue_redraw()
	# Дата и время (реальные, как на скриншотах).
	var t := Time.get_time_dict_from_system()
	var d := Time.get_date_dict_from_system()
	_time_label.text = "%02d:%02d  ·  %02d.%02d.%04d" % [int(t.hour), int(t.minute), int(d.day), int(d.month), int(d.year)]
	# Живые данные вождения.
	if _drive_panel != null and _drive_panel.visible:
		var world := get_tree().current_scene
		var car = world.get("_car") if world != null else null
		if car != null and is_instance_valid(car):
			_drive_speed.text = "%d км/ч" % int(car.speed_kmh())
			var def: Dictionary = Catalogs_car_def(car.car_id)
			_drive_fuel.text = "Топливо: %d / %d л" % [int(car.fuel), int(def.get("tank", 0))]
			_drive_fuel.add_theme_color_override("font_color", UiKit.COLOR_ERROR if car.fuel < 5.0 else UiKit.COLOR_TEXT)
			var dmg := int(car.damage)
			_drive_damage.text = "Износ: %d%%" % dmg
			_drive_damage.add_theme_color_override("font_color", UiKit.COLOR_ERROR if dmg > 60 else UiKit.COLOR_MUTED)
		_jail_label.visible = false


func Catalogs_car_def(car_id: String) -> Dictionary:
	return Cat.CARS.get(car_id, {})
