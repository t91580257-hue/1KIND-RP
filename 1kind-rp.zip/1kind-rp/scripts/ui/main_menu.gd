extends Node3D
## Главное меню (v0.3.2, минималистичное): 3D-фон с облётом города Ванбург,
## лого сверху слева, а в углу справа внизу — только ввод ника и кнопка «ИГРАТЬ».
## Пароль запрашивается ПОСЛЕ нажатия «Играть» (панель auth_panel):
## ник свободен → создание аккаунта, ник занят → вход.
## Мелкие ссылки «Сетевая игра» и «Настройки» — в левом нижнем углу.

const CityBuilder = preload("res://scripts/world/city_builder.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const AuthPanel = preload("res://scripts/ui/auth_panel.gd")
const SettingsScene = preload("res://scenes/ui/settings_screen.tscn")
const OnlinePanel = preload("res://scripts/ui/online_panel.gd")
const WORLD_SCENE := "res://scenes/world/vanburg.tscn"

var _camera: Camera3D
var _ui: CanvasLayer
var _menu_root: Control
var _overlay: Control = null
var _angle: float = 0.6

# Ввод ника и кнопка «Играть».
var _nick_edit: LineEdit
var _hint: Label
var _play_btn: Button

# Переход в мир: 2 кадра показываем «Загрузка города…», затем меняем сцену
# (чтобы надпись успела отрисоваться до постройки города).
var _enter_state: int = 0
var _enter_frames: int = 0
var _enter_nick: String = ""
var _loading_label: Label = null


func _ready() -> void:
	get_tree().paused = false
	get_tree().set_quit_on_go_back(false)
	var sun := CityBuilder.add_atmosphere(self)
	GameSettings.apply_light(sun)
	GameSettings.apply_viewport(get_viewport())
	CityBuilder.build(self)

	_camera = Camera3D.new()
	_camera.far = 450.0
	_camera.fov = 62.0
	add_child(_camera)
	_camera.current = true
	_update_camera()

	_ui = CanvasLayer.new()
	add_child(_ui)
	_build_menu()


func _process(delta: float) -> void:
	_angle += delta * 0.07
	_update_camera()
	if _enter_state == 1:
		_enter_frames += 1
		if _enter_frames >= 3:
			_enter_state = 0
			GameState.start_session(_enter_nick)
			get_tree().change_scene_to_file(WORLD_SCENE)


func _update_camera() -> void:
	var r := 92.0
	_camera.position = Vector3(cos(_angle) * r, 46.0, sin(_angle) * r)
	_camera.look_at(Vector3(0, 4, 0), Vector3.UP)


func _build_menu() -> void:
	_menu_root = Control.new()
	_menu_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_menu_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ui.add_child(_menu_root)

	# --- Лого (сверху слева, компактно) ---
	var corner := MarginContainer.new()
	corner.set_anchors_preset(Control.PRESET_TOP_LEFT)
	corner.add_theme_constant_override("margin_left", 24)
	corner.add_theme_constant_override("margin_top", 16)
	corner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_menu_root.add_child(corner)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	corner.add_child(hb)
	hb.add_child(UiKit.make_icon("crown", 56))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	hb.add_child(vb)
	vb.add_child(UiKit.make_title("1KIND RP", 40))
	var sub := UiKit.make_label("Город Ванбург", 18, UiKit.COLOR_MUTED)
	vb.add_child(sub)

	# --- Блок входа (правый нижний угол): ник + ИГРАТЬ ---
	var play_corner := MarginContainer.new()
	play_corner.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	play_corner.add_theme_constant_override("margin_right", 28)
	play_corner.add_theme_constant_override("margin_bottom", 28)
	play_corner.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	play_corner.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_menu_root.add_child(play_corner)
	var panel := UiKit.make_panel()
	play_corner.add_child(panel)
	var pvb := VBoxContainer.new()
	pvb.add_theme_constant_override("separation", 10)
	panel.add_child(pvb)
	_hint = UiKit.make_label("", 19, UiKit.COLOR_ERROR)
	_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint.custom_minimum_size = Vector2(400, 0)
	pvb.add_child(_hint)
	_nick_edit = UiKit.make_line_edit("Никнейм (3–16 символов)")
	_nick_edit.text_submitted.connect(func(_t: String) -> void: _on_play())
	pvb.add_child(_nick_edit)
	_play_btn = UiKit.make_button("ИГРАТЬ", "gold", Vector2(400, 74), 32)
	_play_btn.pressed.connect(_on_play)
	pvb.add_child(_play_btn)

	# --- Мелкие ссылки (левый нижний угол) ---
	var links := MarginContainer.new()
	links.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	links.add_theme_constant_override("margin_left", 28)
	links.add_theme_constant_override("margin_bottom", 28)
	links.grow_vertical = Control.GROW_DIRECTION_BEGIN
	_menu_root.add_child(links)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 6)
	links.add_child(lv)
	var online := UiKit.make_button("Сетевая игра (бета)", "blue", Vector2(300, 50), 21)
	online.pressed.connect(_open_online)
	lv.add_child(online)
	var settings := UiKit.make_button("Настройки", "dark", Vector2(300, 50), 21)
	settings.pressed.connect(_open_settings)
	lv.add_child(settings)
	var version := str(ProjectSettings.get_setting("application/config/version", "0.1.0"))
	var ver_label := UiKit.make_label("Версия %s  ·  %s" % [version, NetworkService.mode_title()], 17, UiKit.COLOR_MUTED)
	lv.add_child(ver_label)

	# --- Надпись загрузки (появляется перед сменой сцены) ---
	_loading_label = UiKit.make_label("Загрузка города…", 34, UiKit.COLOR_GOLD)
	_loading_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_loading_label.add_theme_constant_override("outline_size", 8)
	_loading_label.set_anchors_preset(Control.PRESET_CENTER)
	_loading_label.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_loading_label.grow_vertical = Control.GROW_DIRECTION_BOTH
	_loading_label.visible = false
	_menu_root.add_child(_loading_label)


# ---------- Играть ----------

func _on_play() -> void:
	if _overlay != null:
		return
	var nick := _nick_edit.text.strip_edges()
	if nick.is_empty():
		_set_hint("Введите никнейм — и вперёд!")
		return
	var nick_error := AccountManager.validate_nick(nick)
	if nick_error != "":
		_set_hint(nick_error)
		return
	_set_hint("")
	_open_auth(nick)


func _set_hint(text: String) -> void:
	_hint.text = text


func _open_auth(nick: String) -> void:
	var panel := AuthPanel.new()
	panel.success.connect(_on_auth_success)
	panel.closed.connect(_close_overlay)
	_show_overlay(panel)
	panel.open_for(nick)


func _on_auth_success(nick: String) -> void:
	# Закрываем оверлеи и показываем «Загрузка города…» на пару кадров —
	# чтобы игрок видел, что происходит во время постройки мира.
	_close_overlay()
	_enter_nick = nick
	_enter_frames = 0
	_enter_state = 1
	if _loading_label != null:
		_loading_label.text = "Загрузка города…\nИгрок: %s" % nick
		_loading_label.visible = true


# ---------- Оверлеи ----------

func _show_overlay(node: Control) -> void:
	_close_overlay()
	_overlay = node
	_ui.add_child(node)
	AudioManager.play_sfx("open")


func _close_overlay() -> void:
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null


func _open_settings() -> void:
	if _overlay != null:
		return
	var screen = SettingsScene.instantiate()
	screen.closed.connect(_close_overlay)
	_show_overlay(screen)


func _open_online() -> void:
	if _overlay != null:
		return
	var panel := OnlinePanel.new()
	panel.closed.connect(_close_overlay)
	_show_overlay(panel)


func _quit_game() -> void:
	GameSettings.save_settings()
	get_tree().quit()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if _overlay != null:
			_close_overlay()
		else:
			_quit_game()
