extends Control
## Торговые панели: ломбард (продажа вещей), рынок (покупка инструментов + продажа),
## чёрный рынок (нелегальные товары) и приёмка сырья (продажа ресурсов).

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

## mode: pawnshop | market | blackmarket | raw
var mode: String = "pawnshop"

var _rows_vb: VBoxContainer
var _balance: Label

const TITLES: Dictionary = {
	"pawnshop": "Ломбард «Золотой лом»",
	"market": "Рынок Ванбурга",
	"blackmarket": "Чёрный рынок",
	"raw": "Приёмка сырья",
}
const NOTES: Dictionary = {
	"pawnshop": "Принимаем вещи по рыночной цене (котировка меняется при каждом входе в игру).",
	"market": "Инструменты для работ и покупка/продажа по рыночным котировкам.",
	"blackmarket": "Товар без документов. Покупка «левых» телефонов может привлечь полицию (+1 ★ с шансом 25%).",
	"raw": "Принимаем камень, руду, брёвна, рыбу и овощи по рыночным котировкам.",
}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(880, 600)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)
	root.add_child(UiKit.make_title(String(TITLES.get(mode, "Торговля")), 34))
	_balance = UiKit.make_label("", 24, UiKit.COLOR_GOLD)
	_balance.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(_balance)
	var note := UiKit.make_label(String(NOTES.get(mode, "")), 18, UiKit.COLOR_MUTED)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(780, 0)
	root.add_child(note)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 330)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	_rows_vb = VBoxContainer.new()
	_rows_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_rows_vb.add_theme_constant_override("separation", 6)
	scroll.add_child(_rows_vb)

	_build_rows()

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)
	GameState.balance_changed.connect(func(_v: int) -> void: _refresh_balance())
	_refresh_balance()


func _refresh_balance() -> void:
	_balance.text = "Наличные: %s  ·  Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)]


func _sell_items() -> Array:
	match mode:
		"raw":
			return ["stone", "ore", "wood", "fish", "fish_big", "vegetables"]
		"blackmarket":
			return ["stolen_phone", "fireworks"]
		"market":
			return ["fish", "fish_big", "vegetables", "gold_badge", "phone_case"]
	return Catalogs.SELLABLE.duplicate()


func _buy_items() -> Array:
	match mode:
		"market":
			return ["rod", "seed_pack", "toolbox", "sandwich", "water"]
		"blackmarket":
			return ["stolen_phone", "fireworks"]
	return []


func _buy_price(item_id: String) -> int:
	var base := int(Catalogs.item_def(item_id).get("price", 0))
	if base <= 0:
		return 0
	match mode:
		"market":
			return base
		"blackmarket":
			# Нелегальные товары: базовая цена в каталоге 0 — задаём «уличную» цену здесь.
			if item_id == "stolen_phone":
				return 1100
			if item_id == "fireworks":
				return 500
			return base
	return base


func _build_rows() -> void:
	for item_id in _buy_items():
		_add_buy_row(String(item_id))
	for item_id in _sell_items():
		_add_sell_row(String(item_id))


func _add_buy_row(item_id: String) -> void:
	var def := Catalogs.item_def(item_id)
	var price := _buy_price(item_id)
	var row := _row_base()
	row.get_node("H").add_child(UiKit.make_icon(String(def.get("icon", "star")), 48))
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.get_node("H").add_child(info)
	info.add_child(UiKit.make_label(String(def["name"]), 22, UiKit.COLOR_TEXT))
	info.add_child(UiKit.make_label(String(def.get("desc", "")), 16, UiKit.COLOR_MUTED))
	row.get_node("H").add_child(UiKit.make_label(GameState.fmt_money(price), 20, UiKit.COLOR_GOLD))
	var btn := UiKit.make_button("Купить", "gold", Vector2(150, 50), 20)
	btn.pressed.connect(func() -> void:
		if not GameState.charge(price, "Покупка: %s" % String(def["name"])):
			GameState.notify("Недостаточно средств.")
			AudioManager.play_sfx("error")
			return
		var got := GameState.add_item(item_id, 1)
		if got == 0:
			GameState.credit_bank(price, "Возврат: инвентарь полон")
			GameState.notify("Инвентарь полон!")
			AudioManager.play_sfx("error")
			return
		GameState.add_xp(5)
		AudioManager.play_sfx("coin")
		GameState.notify("Куплено: %s" % String(def["name"]))
		# Чёрный рынок: риск розыска.
		if mode == "blackmarket" and randf() < 0.25:
			GameState.add_wanted(1, "Сделка на чёрном рынке замечена полицией")
		GameState.save_profile()
	)
	row.get_node("H").add_child(btn)


func _add_sell_row(item_id: String) -> void:
	var def := Catalogs.item_def(item_id)
	var row := _row_base()
	row.get_node("H").add_child(UiKit.make_icon(String(def.get("icon", "star")), 48))
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.get_node("H").add_child(info)
	info.add_child(UiKit.make_label(String(def["name"]), 22, UiKit.COLOR_TEXT))
	var have := GameState.item_total(item_id)
	var unit := GameState.market_sell_price(item_id)
	info.add_child(UiKit.make_label("У вас: %d шт.  ·  цена за штуку: %s" % [have, GameState.fmt_money(unit)], 16, UiKit.COLOR_MUTED))
	var btn := UiKit.make_button("Продать", "blue", Vector2(150, 50), 20)
	btn.disabled = have <= 0 or unit <= 0
	btn.text = "Нет в наличии" if have <= 0 else "Продать"
	btn.pressed.connect(func() -> void:
		var r := GameState.sell_item(item_id, 1)
		GameState.notify(String(r["text"]))
		if not bool(r["ok"]):
			AudioManager.play_sfx("error")
		_refresh_rows()
	)
	row.get_node("H").add_child(btn)


func _row_base() -> PanelContainer:
	var row := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.14, 0.3, 0.85)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 10
	sb.content_margin_right = 10
	sb.content_margin_top = 6
	sb.content_margin_bottom = 6
	row.add_theme_stylebox_override("panel", sb)
	_rows_vb.add_child(row)
	var h := HBoxContainer.new()
	h.name = "H"
	h.add_theme_constant_override("separation", 12)
	row.add_child(h)
	return row


func _refresh_rows() -> void:
	for c in _rows_vb.get_children():
		c.queue_free()
	_build_rows()
	_refresh_balance()
