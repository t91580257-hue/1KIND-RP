extends Control
## Панель СТО: список автомобилей игрока, ремонт кузова и тюнинг (визуал + характеристики).
## Если игрок в автомобиле — он выбирается автоматически.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

var _sel_uid: String = ""
var _list_vb: VBoxContainer
var _tune_vb: VBoxContainer
var _info: Label


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(940, 620)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)
	root.add_child(UiKit.make_title("СТО и тюнинг «Форсаж»", 34))
	_info = UiKit.make_label("", 20, UiKit.COLOR_MUTED)
	_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(_info)

	var body := HBoxContainer.new()
	body.add_theme_constant_override("separation", 18)
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(left)
	left.add_child(UiKit.make_label("Ваши автомобили:", 22, UiKit.COLOR_GOLD))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(400, 380)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	left.add_child(scroll)
	_list_vb = VBoxContainer.new()
	_list_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_list_vb.add_theme_constant_override("separation", 6)
	scroll.add_child(_list_vb)

	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(right)
	right.add_child(UiKit.make_label("Ремонт и тюнинг:", 22, UiKit.COLOR_GOLD))
	var scroll2 := ScrollContainer.new()
	scroll2.custom_minimum_size = Vector2(440, 380)
	scroll2.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(scroll2)
	_tune_vb = VBoxContainer.new()
	_tune_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tune_vb.add_theme_constant_override("separation", 6)
	scroll2.add_child(_tune_vb)

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)

	_refresh_list()


func _car_label(c: Dictionary) -> String:
	var def: Dictionary = Catalogs.CARS.get(String(c["id"]), {})
	return "%s\nтопливо %d/%d · износ %d%%" % [String(def.get("name", c["id"])), int(float(c.get("fuel", 0.0))), int(def.get("tank", 0)), int(float(c.get("damage", 0.0)))]


func _refresh_list() -> void:
	for c in _list_vb.get_children():
		c.queue_free()
	if GameState.owned_cars.is_empty():
		_list_vb.add_child(UiKit.make_label("Гараж пуст.", 20, UiKit.COLOR_MUTED))
		_refresh_tune()
		return
	for c in GameState.owned_cars:
		var uid := String(c["uid"])
		var b := UiKit.make_button(_car_label(c), "blue" if uid != _sel_uid else "gold", Vector2(400, 76), 18)
		b.pressed.connect(func() -> void:
			_sel_uid = uid
			_refresh_list()
		)
		_list_vb.add_child(b)
	if _sel_uid == "" or GameState.car_by_uid(_sel_uid).is_empty():
		_sel_uid = String(GameState.owned_cars[0]["uid"])
	_refresh_tune()


func _refresh_tune() -> void:
	for c in _tune_vb.get_children():
		c.queue_free()
	var c := GameState.car_by_uid(_sel_uid)
	if c.is_empty():
		return
	var dmg := float(c.get("damage", 0.0))
	var repair_cost := int(ceil(dmg)) * int(Catalogs.SERVICES["repair_per_percent"]["price"])
	var rep := UiKit.make_button("Ремонт кузова (%d%%) — %s" % [int(dmg), GameState.fmt_money(repair_cost)], "gold" if dmg >= 1.0 else "dark", Vector2(440, 56), 19)
	rep.disabled = dmg < 1.0
	rep.pressed.connect(func() -> void:
		var free := GameState.insurance_active()
		var r := GameState.repair_car(_sel_uid, free)
		GameState.notify(String(r["text"]))
		AudioManager.play_sfx("coin" if bool(r["ok"]) else "error")
		_refresh_list()
	)
	_tune_vb.add_child(rep)
	if GameState.insurance_active():
		_tune_vb.add_child(UiKit.make_label("КАСКО: ремонт бесплатный ✓", 17, UiKit.COLOR_OK))

	for tune_id in Catalogs.TUNING:
		var t: Dictionary = Catalogs.TUNING[tune_id]
		var owned := GameState.car_has_tuning(_sel_uid, String(tune_id))
		var b := UiKit.make_button(
			("%s — установлено ✓" % String(t["name"])) if owned else ("%s — %s" % [String(t["name"]), GameState.fmt_money(int(t["price"]))]),
			"dark" if owned else "blue",
			Vector2(440, 54), 18)
		b.disabled = owned
		b.pressed.connect(func() -> void:
			var r := GameState.buy_tuning(_sel_uid, String(tune_id))
			GameState.notify(String(r["text"]))
			AudioManager.play_sfx("coin" if bool(r["ok"]) else "error")
			_refresh_tune()
		)
		_tune_vb.add_child(b)
	var hint := UiKit.make_label("Спойлер: +управляемость · Выхлоп: +разгон · Остальное — стиль. Установленное видно на автомобиле сразу.", 16, UiKit.COLOR_MUTED)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_tune_vb.add_child(hint)
	_info.text = "Выбрано: %s" % _car_label(c).replace("\n", "  ·  ")
