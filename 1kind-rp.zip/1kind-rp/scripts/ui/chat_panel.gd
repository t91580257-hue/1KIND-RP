extends Control
## Чат: в офлайне — журнал событий игры и подсказка про онлайн;
## в онлайн-режиме — живой чат сервера (NetworkService).

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const MAX_LINES := 60

var _log_vb: VBoxContainer
var _input: LineEdit
var _scroll: ScrollContainer


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(760, 600)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)
	var mode_text := "Онлайн-чат" if NetworkService.is_online() else "Журнал событий"
	root.add_child(UiKit.make_title(mode_text, 34))

	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.custom_minimum_size = Vector2(0, 380)
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(_scroll)
	_log_vb = VBoxContainer.new()
	_log_vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_log_vb.add_theme_constant_override("separation", 4)
	_scroll.add_child(_log_vb)

	if NetworkService.is_online():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		root.add_child(row)
		_input = UiKit.make_line_edit("Сообщение (до 200 символов)")
		_input.max_length = 200
		_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		_input.text_submitted.connect(func(_t: String) -> void: _send())
		row.add_child(_input)
		var send := UiKit.make_button("Отправить", "gold", Vector2(200, 58), 21)
		send.pressed.connect(_send)
		row.add_child(send)
	else:
		var note := UiKit.make_label("Офлайн-режим: сообщения других игроков доступны после подключения к серверу «Сетевая игра» в главном меню.", 18, UiKit.COLOR_MUTED)
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		root.add_child(note)

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)

	_fill_history()
	NetworkService.chat_received.connect(_on_chat)


func _exit_tree() -> void:
	if NetworkService.chat_received.is_connected(_on_chat):
		NetworkService.chat_received.disconnect(_on_chat)


func _fill_history() -> void:
	for m in NetworkService.chat_history:
		_add_line(String(m.get("from", "?")), String(m.get("text", "")))
	if NetworkService.chat_history.is_empty():
		_add_line("Система", "Чат пуст. Ваши операции видны в журнале банкомата.")


func _on_chat(from: String, text: String) -> void:
	_add_line(from, text)


func _add_line(from: String, text: String) -> void:
	var col := UiKit.COLOR_GOLD if from == "Система" else UiKit.COLOR_TEXT
	var l := UiKit.make_label("%s: %s" % [from, text], 19, col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_log_vb.add_child(l)
	while _log_vb.get_child_count() > MAX_LINES:
		_log_vb.get_child(0).queue_free()
	await get_tree().process_frame
	_scroll.scroll_vertical = int(_scroll.get_v_scroll_bar().max_value)


func _send() -> void:
	if _input == null:
		return
	var text := _input.text.strip_edges()
	if text == "":
		return
	var r := NetworkService.send_chat(text)
	if bool(r.get("ok", false)):
		_input.text = ""
	else:
		GameState.notify(String(r.get("error", "Не отправлено.")))
		AudioManager.play_sfx("error")
