extends Control
## Универсальная панель подтверждения услуги: заголовок, описание, цена, кнопки.
## Используется больницей, заправкой, мэрией, бандами, гонками, залогом и т.д.

signal confirmed
signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _title: String = ""
var _text: String = ""
var _price: int = 0
var _ok_text: String = "Подтвердить"
var _danger: bool = false


func setup(title: String, text: String, price: int, ok_text: String, danger: bool = false) -> void:
		_title = title
		_text = text
		_price = price
		_ok_text = ok_text
		_danger = danger


func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(UiKit.make_dim())
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(center)
		var panel := UiKit.make_panel()
		panel.custom_minimum_size = Vector2(720, 0)
		center.add_child(panel)
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 14)
		panel.add_child(vb)

		vb.add_child(UiKit.make_title(_title, 36))
		var body := UiKit.make_label(_text, 22, UiKit.COLOR_TEXT)
		body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.custom_minimum_size = Vector2(620, 0)
		vb.add_child(body)
		if _price > 0:
				var price_l := UiKit.make_label("Стоимость: %s (наличные → карта)" % GameState.fmt_money(_price), 24, UiKit.COLOR_GOLD)
				price_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
				vb.add_child(price_l)
		var bal := UiKit.make_label("Наличные: %s  ·  Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)], 19, UiKit.COLOR_MUTED)
		bal.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		vb.add_child(bal)

		var row := HBoxContainer.new()
		row.alignment = BoxContainer.ALIGNMENT_CENTER
		row.add_theme_constant_override("separation", 14)
		vb.add_child(row)
		if _price > 0 or _ok_text != "Понятно":
				var ok := UiKit.make_button(_ok_text, "purple" if _danger else "gold", Vector2(300, 64))
				ok.pressed.connect(func() -> void:
						if _price > 0 and not GameState.total_money() >= _price:
								GameState.notify("Недостаточно средств.")
								AudioManager.play_sfx("error")
								return
						confirmed.emit()
						closed.emit()
				)
				row.add_child(ok)
		var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 64))
		close.pressed.connect(func() -> void: closed.emit())
		row.add_child(close)
