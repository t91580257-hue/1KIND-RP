extends Control
## Панель пароля (v0.3.2): открывается из главного меню по кнопке «Играть».
## Если аккаунт с таким ником уже есть — режим ВХОДА (одно поле пароля),
## если нет — режим СОЗДАНИЯ АККАУНТА (пароль + повтор).
##
## Безопасность от зависаний: проверку выполняет AccountManager в отдельном
## потоке; панель НИЧЕГО не делает через await — только читает состояние
## в _process и получает результат сигналом check_finished.

signal success(nick: String)
signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _nick: String = ""
var _mode: String = "login"          # "login" | "register"
var _pass: LineEdit
var _repeat: LineEdit
var _repeat_row: Control
var _status: Label
var _title: Label
var _action_btn: Button
var _waiting: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim(0.7))
	# Панель в верхней части экрана — не конфликтует с экранной клавиатурой Android.
	var top := MarginContainer.new()
	top.set_anchors_preset(Control.PRESET_FULL_RECT)
	top.add_theme_constant_override("margin_top", 20)
	add_child(top)
	var holder := HBoxContainer.new()
	holder.alignment = BoxContainer.ALIGNMENT_CENTER
	holder.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	top.add_child(holder)
	var panel := UiKit.make_panel()
	holder.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	panel.add_child(vb)

	_title = UiKit.make_title("Вход", 40)
	vb.add_child(_title)
	_status = UiKit.make_label("", 20, UiKit.COLOR_MUTED)
	_status.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.custom_minimum_size = Vector2(400, 30)
	vb.add_child(_status)

	_pass = UiKit.make_line_edit("Пароль", true)
	_pass.max_length = 64
	_pass.text_submitted.connect(func(_t: String) -> void: _do_action())
	vb.add_child(_pass)

	_repeat_row = UiKit.make_line_edit("Повторите пароль", true)
	_repeat = _repeat_row
	_repeat.max_length = 64
	_repeat.text_submitted.connect(func(_t: String) -> void: _do_action())
	vb.add_child(_repeat_row)

	_action_btn = UiKit.make_button("Войти", "gold", Vector2(400, 66))
	_action_btn.pressed.connect(_do_action)
	vb.add_child(_action_btn)
	var back := UiKit.make_button("Назад", "dark", Vector2(400, 56), 24)
	back.pressed.connect(_go_back)
	vb.add_child(back)

	AccountManager.check_finished.connect(_on_check_finished)


func _exit_tree() -> void:
	if AccountManager.check_finished.is_connected(_on_check_finished):
		AccountManager.check_finished.disconnect(_on_check_finished)


## Открыть панель для ника (режим определяется наличием аккаунта).
func open_for(nick: String) -> void:
	_nick = nick.strip_edges()
	_mode = "login" if AccountManager.account_exists(_nick) else "register"
	_waiting = false
	_action_btn.disabled = false
	if _mode == "register":
		_title.text = "Создание аккаунта"
		_action_btn.text = "Создать аккаунт"
		_repeat_row.visible = true
		_status.text = "Ник «%s» свободен — придумайте пароль." % _nick
		_status.add_theme_color_override("font_color", UiKit.COLOR_MUTED)
		_repeat.text = ""
		_repeat.grab_focus()
	else:
		_title.text = "Вход"
		_action_btn.text = "Войти"
		_repeat_row.visible = false
		_status.text = "Ник: %s" % _nick
		_status.add_theme_color_override("font_color", UiKit.COLOR_MUTED)
		_pass.text = ""
		_pass.grab_focus()
	_pass.text = ""


func _go_back() -> void:
	AccountManager.cancel_check()
	closed.emit()


func _show_error(text: String) -> void:
	_status.text = text
	_status.add_theme_color_override("font_color", UiKit.COLOR_ERROR)
	AudioManager.play_sfx("error")


func _do_action() -> void:
	if _waiting:
		return
	var pw := _pass.text
	if _mode == "register":
		var r := AccountManager.start_register(_nick, pw, _repeat.text)
		if not bool(r["ok"]):
			_show_error(String(r["error"]))
			return
	else:
		var r := AccountManager.start_login(_nick, pw)
		if not bool(r["ok"]):
			_show_error(String(r["error"]))
			return
	_waiting = true
	_action_btn.disabled = true
	_status.text = "Проверка данных…"
	_status.add_theme_color_override("font_color", UiKit.COLOR_MUTED)


func _process(_delta: float) -> void:
	if not _waiting:
		return
	if AccountManager.check_running:
		var pct := int(round(AccountManager.check_progress() * 100.0))
		var sec := int(AccountManager.check_elapsed_ms / 1000.0)
		_status.text = "Проверка данных… %d%%  (%d с)" % [pct, sec]


func _on_check_finished(result: Dictionary) -> void:
	if String(result.get("kind", "")) != _mode:
		return
	_waiting = false
	_action_btn.disabled = false
	if bool(result.get("ok", false)):
		_pass.text = ""
		_repeat.text = ""
		success.emit(String(result.get("nick", _nick)))
	else:
		_show_error(String(result.get("error", "Ошибка.")))
