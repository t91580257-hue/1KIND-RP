extends Control
## Настройки: чувствительность камеры, громкость музыки/эффектов, качество графики,
## управление (размер, прозрачность, инверсия, режим бега), показ FPS.
## Значения применяются сразу и сохраняются в user://settings.cfg при закрытии.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _quality_buttons: Array = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim(0.75))
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(840, 600)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	panel.add_child(root)
	root.add_child(UiKit.make_title("Настройки", 40))

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 420)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 14)
	scroll.add_child(list)

	_add_section(list, "Камера")
	_add_slider(list, "Чувствительность камеры", 0.3, 2.5, GameSettings.camera_sensitivity, 0.05, "camera_sensitivity", false)
	_add_toggle(list, "Инвертировать вертикаль камеры", GameSettings.invert_y, "invert_y")

	_add_section(list, "Звук")
	_add_slider(list, "Громкость музыки", 0.0, 1.0, GameSettings.music_volume, 0.05, "music_volume", true)
	_add_slider(list, "Громкость эффектов", 0.0, 1.0, GameSettings.sfx_volume, 0.05, "sfx_volume", true)

	_add_section(list, "Графика")
	_add_quality(list)
	_add_toggle(list, "Показывать FPS", GameSettings.show_fps, "show_fps")

	_add_section(list, "Управление")
	_add_slider(list, "Размер элементов управления", 0.7, 1.5, GameSettings.touch_scale, 0.05, "touch_scale", false)
	_add_slider(list, "Прозрачность элементов управления", 0.3, 1.0, GameSettings.touch_opacity, 0.05, "touch_opacity", true)
	_add_toggle(list, "Бег: удерживать кнопку (иначе — переключатель)", GameSettings.hold_to_run, "hold_to_run")

	var buttons := HBoxContainer.new()
	buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	buttons.add_theme_constant_override("separation", 20)
	root.add_child(buttons)
	var defaults := UiKit.make_button("По умолчанию", "dark", Vector2(280, 62))
	defaults.pressed.connect(_on_defaults)
	buttons.add_child(defaults)
	var done := UiKit.make_button("Сохранить и закрыть", "gold", Vector2(340, 62))
	done.pressed.connect(_on_done)
	buttons.add_child(done)


func _add_section(parent: Control, title: String) -> void:
	parent.add_child(UiKit.make_label(title, 28, UiKit.COLOR_GOLD))


func _add_slider(parent: Control, title: String, min_v: float, max_v: float, value: float, step: float, prop: String, percent: bool) -> void:
	var box := VBoxContainer.new()
	parent.add_child(box)
	var head := HBoxContainer.new()
	box.add_child(head)
	var name_label := UiKit.make_label(title, 22)
	name_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(name_label)
	var value_label := UiKit.make_label(_fmt(value, percent), 22, UiKit.COLOR_GOLD)
	head.add_child(value_label)
	var slider := UiKit.make_slider(min_v, max_v, value, step)
	box.add_child(slider)
	slider.value_changed.connect(_on_slider_changed.bind(prop, value_label, percent))


func _on_slider_changed(v: float, prop: String, value_label: Label, percent: bool) -> void:
	GameSettings.set(prop, v)
	value_label.text = _fmt(v, percent)
	GameSettings.apply_all()


func _fmt(v: float, percent: bool) -> String:
	if percent:
		return "%d%%" % int(round(v * 100.0))
	return "%.2f" % v


func _add_toggle(parent: Control, title: String, value: bool, prop: String) -> void:
	var cb := CheckButton.new()
	cb.text = title
	cb.button_pressed = value
	cb.focus_mode = Control.FOCUS_NONE
	cb.add_theme_font_size_override("font_size", 22)
	cb.add_theme_color_override("font_color", UiKit.COLOR_TEXT)
	cb.add_theme_color_override("font_pressed_color", UiKit.COLOR_TEXT)
	cb.add_theme_color_override("font_hover_color", UiKit.COLOR_TEXT)
	cb.custom_minimum_size = Vector2(0, 52)
	cb.toggled.connect(_on_toggle_changed.bind(prop))
	parent.add_child(cb)


func _on_toggle_changed(on: bool, prop: String) -> void:
	GameSettings.set(prop, on)
	AudioManager.play_sfx("click")
	GameSettings.apply_all()


func _add_quality(parent: Control) -> void:
	parent.add_child(UiKit.make_label("Качество графики", 22))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	parent.add_child(row)
	for i in range(GameSettings.QUALITY_NAMES.size()):
		var b := UiKit.make_button(String(GameSettings.QUALITY_NAMES[i]), "dark", Vector2(200, 56), 24)
		b.pressed.connect(_on_quality.bind(i))
		row.add_child(b)
		_quality_buttons.append(b)
	_refresh_quality()


func _on_quality(index: int) -> void:
	GameSettings.graphics_quality = index
	GameSettings.apply_all()
	_refresh_quality()


func _refresh_quality() -> void:
	for i in range(_quality_buttons.size()):
		var b: Button = _quality_buttons[i]
		var kind := "gold" if i == GameSettings.graphics_quality else "dark"
		var text_color := UiKit.COLOR_NAVY if kind == "gold" else Color.WHITE
		b.add_theme_stylebox_override("normal", UiKit.button_style(kind))
		b.add_theme_stylebox_override("hover", UiKit.button_style(kind, Color(1.12, 1.12, 1.12)))
		b.add_theme_stylebox_override("pressed", UiKit.button_style(kind, Color(0.72, 0.72, 0.8)))
		b.add_theme_color_override("font_color", text_color)
		b.add_theme_color_override("font_hover_color", text_color)
		b.add_theme_color_override("font_pressed_color", text_color)


func _on_defaults() -> void:
	GameSettings.reset_to_defaults()
	GameSettings.save_settings()
	closed.emit()


func _on_done() -> void:
	GameSettings.save_settings()
	closed.emit()
