extends RefCounted
## Набор статических помощников для построения интерфейса в едином
## сине-золотом стиле. Использует текстуры из ресурс-пака (assets/ui/).

const COLOR_GOLD := Color("ffbe28")
const COLOR_GOLD_DARK := Color("b9770e")
const COLOR_BLUE := Color("1e90ff")
const COLOR_NAVY := Color("0a1630")
const COLOR_NAVY_LIGHT := Color("123a73")
const COLOR_TEXT := Color("eaf2ff")
const COLOR_MUTED := Color("93a8c9")
const COLOR_ERROR := Color("ff6b6b")
const COLOR_OK := Color("6bffa6")

const UI_PATH := "res://assets/ui/"
const ICON_PATH := "res://assets/ui/icons/"

static var _circle_cache: Dictionary = {}


static func icon(icon_name: String) -> Texture2D:
	return load("%s%s.png" % [ICON_PATH, icon_name]) as Texture2D


static func panel_style() -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	sb.texture = load(UI_PATH + "panel.png") as Texture2D
	sb.texture_margin_left = 16
	sb.texture_margin_right = 16
	sb.texture_margin_top = 16
	sb.texture_margin_bottom = 16
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 18
	sb.content_margin_bottom = 18
	return sb


static func button_style(kind: String, tint: Color = Color.WHITE) -> StyleBoxTexture:
	var sb := StyleBoxTexture.new()
	# Новые виды из пака: danger/success — отдельные текстуры.
	var tex_name := kind
	if not ResourceLoader.exists("%sbutton_%s.png" % [UI_PATH, kind]):
		tex_name = "blue" if kind != "gold" else "gold"
	sb.texture = load("%sbutton_%s.png" % [UI_PATH, tex_name]) as Texture2D
	sb.texture_margin_left = 34
	sb.texture_margin_right = 34
	sb.texture_margin_top = 30
	sb.texture_margin_bottom = 30
	sb.content_margin_left = 20
	sb.content_margin_right = 20
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	sb.modulate_color = tint
	return sb


## kind: blue | gold | dark | purple | danger | success | disabled
static func make_button(text: String, kind: String = "blue", min_size: Vector2 = Vector2(280, 68), font_size: int = 28) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_stylebox_override("normal", button_style(kind))
	b.add_theme_stylebox_override("hover", button_style(kind, Color(1.12, 1.12, 1.12)))
	b.add_theme_stylebox_override("pressed", button_style(kind, Color(0.72, 0.72, 0.8)))
	if ResourceLoader.exists(UI_PATH + "button_disabled.png"):
		b.add_theme_stylebox_override("disabled", button_style("disabled", Color.WHITE))
	else:
		b.add_theme_stylebox_override("disabled", button_style(kind, Color(0.45, 0.45, 0.5, 0.75)))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	var text_color := COLOR_NAVY if kind == "gold" else Color.WHITE
	b.add_theme_color_override("font_color", text_color)
	b.add_theme_color_override("font_hover_color", text_color)
	b.add_theme_color_override("font_pressed_color", text_color)
	b.add_theme_color_override("font_disabled_color", Color(0.8, 0.8, 0.85, 0.7))
	b.add_theme_font_size_override("font_size", font_size)
	b.pressed.connect(func() -> void: AudioManager.play_sfx("click"))
	return b


static func make_label(text: String, font_size: int = 24, color: Color = COLOR_TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	return l


static func make_title(text: String, font_size: int = 40) -> Label:
	var l := make_label(text, font_size, COLOR_GOLD)
	l.add_theme_color_override("font_outline_color", COLOR_NAVY)
	l.add_theme_constant_override("outline_size", 8)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func make_icon(icon_name: String, px: int = 48) -> TextureRect:
	var t := TextureRect.new()
	t.texture = icon(icon_name)
	t.custom_minimum_size = Vector2(px, px)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


static func make_panel() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", panel_style())
	return p


static func make_line_edit(placeholder: String, secret: bool = false) -> LineEdit:
	var le := LineEdit.new()
	le.placeholder_text = placeholder
	le.secret = secret
	le.custom_minimum_size = Vector2(380, 58)
	le.add_theme_font_size_override("font_size", 26)
	le.add_theme_color_override("font_color", COLOR_TEXT)
	le.add_theme_color_override("font_placeholder_color", COLOR_MUTED)
	le.add_theme_color_override("caret_color", COLOR_GOLD)
	var sb := StyleBoxFlat.new()
	sb.bg_color = COLOR_NAVY
	sb.border_color = COLOR_BLUE
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 16
	sb.content_margin_right = 16
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	le.add_theme_stylebox_override("normal", sb)
	var focus_sb := sb.duplicate() as StyleBoxFlat
	focus_sb.border_color = COLOR_GOLD
	le.add_theme_stylebox_override("focus", focus_sb)
	return le


static func circle_texture(diameter: int, fill: Color, border: Color) -> ImageTexture:
	var key := "%d:%s:%s" % [diameter, fill.to_html(), border.to_html()]
	if _circle_cache.has(key):
		return _circle_cache[key]
	var img := Image.create(diameter, diameter, false, Image.FORMAT_RGBA8)
	var c := Vector2(diameter, diameter) * 0.5
	var r := diameter * 0.5 - 1.0
	for y in range(diameter):
		for x in range(diameter):
			var d := Vector2(x + 0.5, y + 0.5).distance_to(c)
			if d <= r - 4.0:
				img.set_pixel(x, y, fill)
			elif d <= r:
				img.set_pixel(x, y, border)
			else:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
	var tex := ImageTexture.create_from_image(img)
	_circle_cache[key] = tex
	return tex


## Ползунок в сине-золотом стиле, удобный для касаний.
static func make_slider(min_v: float, max_v: float, value: float, step: float = 0.05) -> HSlider:
	var s := HSlider.new()
	s.min_value = min_v
	s.max_value = max_v
	s.step = step
	s.value = value
	s.custom_minimum_size = Vector2(320, 44)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var track := StyleBoxFlat.new()
	track.bg_color = COLOR_NAVY_LIGHT
	track.set_corner_radius_all(6)
	track.content_margin_top = 6
	track.content_margin_bottom = 6
	var fill := StyleBoxFlat.new()
	fill.bg_color = COLOR_GOLD
	fill.set_corner_radius_all(6)
	fill.content_margin_top = 6
	fill.content_margin_bottom = 6
	s.add_theme_stylebox_override("slider", track)
	s.add_theme_stylebox_override("grabber_area", fill)
	s.add_theme_stylebox_override("grabber_area_highlight", fill)
	var grab := circle_texture(40, COLOR_BLUE, COLOR_GOLD)
	s.add_theme_icon_override("grabber", grab)
	s.add_theme_icon_override("grabber_highlight", grab)
	return s


static func make_dim(alpha: float = 0.62) -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(0.01, 0.03, 0.08, alpha)
	r.set_anchors_preset(Control.PRESET_FULL_RECT)
	r.mouse_filter = Control.MOUSE_FILTER_STOP
	return r


## Плоская полупрозрачная панель в стиле мобильных HUD (скруглённый тёмно-синий).
static func make_flat_panel(bg: Color = Color(0.02, 0.07, 0.18, 0.66), radius: int = 14, border: Color = Color(0, 0, 0, 0), border_w: int = 0) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.set_corner_radius_all(radius)
	if border_w > 0:
		sb.set_border_width_all(border_w)
		sb.border_color = border
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	p.add_theme_stylebox_override("panel", sb)
	return p


## Круглая иконка-кнопка для HUD (как в мобильных RP-играх): тёмно-синий круг
## с золотой окантовкой и иконкой по центру.
static func make_round_button(icon_name: String, px: int = 64) -> Button:
	var b := Button.new()
	b.custom_minimum_size = Vector2(px, px)
	b.icon = icon(icon_name)
	b.expand_icon = true
	b.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	b.focus_mode = Control.FOCUS_NONE
	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.02, 0.08, 0.2, 0.74)
	normal.set_corner_radius_all(int(px * 0.5))
	normal.set_border_width_all(2)
	normal.border_color = COLOR_GOLD
	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.05, 0.13, 0.3, 0.82)
	var pressed := normal.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.01, 0.04, 0.12, 0.9)
	pressed.border_color = COLOR_BLUE
	var disabled := normal.duplicate() as StyleBoxFlat
	disabled.bg_color = Color(0.02, 0.08, 0.2, 0.35)
	disabled.border_color = Color(1, 1, 1, 0.15)
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	b.add_theme_stylebox_override("disabled", disabled)
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(func() -> void: AudioManager.play_sfx("click"))
	return b
