extends Control
## Банкомат: наличные и счёт, внесение, снятие, перевод игроку, история операций, пособие.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const BENEFIT_COOLDOWN := 600.0
const BENEFIT_AMOUNT := 2500

var _info: Label
var _amount: LineEdit
var _target: LineEdit
var _history: VBoxContainer
var _benefit_btn: Button


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(860, 580)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	panel.add_child(root)
	root.add_child(UiKit.make_title("Банкомат", 36))
	_info = UiKit.make_label("", 24, UiKit.COLOR_GOLD)
	_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(_info)

	_amount = UiKit.make_line_edit("Сумма, ₽")
	_amount.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	root.add_child(_amount)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	root.add_child(row)
	var dep := UiKit.make_button("Внести", "gold", Vector2(200, 54), 22)
	dep.pressed.connect(func() -> void: _report(GameState.atm_deposit(_read_amount())))
	row.add_child(dep)
	var wd := UiKit.make_button("Снять", "blue", Vector2(200, 54), 22)
	wd.pressed.connect(func() -> void: _report(GameState.atm_withdraw(_read_amount())))
	row.add_child(wd)
	_benefit_btn = UiKit.make_button("Пособие", "dark", Vector2(240, 54), 22)
	_benefit_btn.pressed.connect(_on_benefit)
	row.add_child(_benefit_btn)

	var trow := HBoxContainer.new()
	trow.add_theme_constant_override("separation", 10)
	root.add_child(trow)
	_target = UiKit.make_line_edit("Ник получателя (аккаунт на этом устройстве)")
	_target.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	trow.add_child(_target)
	var send := UiKit.make_button("Перевести", "blue", Vector2(220, 54), 22)
	send.pressed.connect(func() -> void: _report(GameState.transfer_local(_target.text, _read_amount())))
	trow.add_child(send)

	root.add_child(UiKit.make_label("История операций", 22, UiKit.COLOR_GOLD))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 170)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	_history = VBoxContainer.new()
	_history.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_history)

	var close := UiKit.make_button("Закрыть", "dark", Vector2(280, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)

	GameState.balance_changed.connect(_on_balance)
	_refresh()


func _exit_tree() -> void:
	if GameState.balance_changed.is_connected(_on_balance):
		GameState.balance_changed.disconnect(_on_balance)


func _on_balance(_v: int) -> void:
	_refresh()


func _read_amount() -> int:
	var t := _amount.text.strip_edges().replace(" ", "")
	if not t.is_valid_int():
		return 0
	return maxi(0, t.to_int())


func _report(result: Dictionary) -> void:
	GameState.notify(String(result["text"]))
	if bool(result["ok"]):
		AudioManager.play_sfx("coin")
		GameState.save_profile()
	else:
		AudioManager.play_sfx("error")


func _on_benefit() -> void:
	var left := GameState.cooldown_left("atm_benefit")
	if left > 0.0:
		_report({"ok": false, "text": "Пособие будет доступно через %d с." % int(ceil(left))})
		return
	GameState.start_cooldown("atm_benefit", BENEFIT_COOLDOWN)
	GameState.credit_bank(BENEFIT_AMOUNT, "Социальное пособие")
	_report({"ok": true, "text": "Пособие %s зачислено на счёт." % GameState.fmt_money(BENEFIT_AMOUNT)})


func _refresh() -> void:
	_info.text = "Наличные: %s   ·   Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)]
	for c in _history.get_children():
		c.queue_free()
	if GameState.ledger.is_empty():
		_history.add_child(UiKit.make_label("Операций пока нет", 18, UiKit.COLOR_MUTED))
	var shown := 0
	for e in GameState.ledger:
		if shown >= 30:
			break
		shown += 1
		var amount := int(e["amount"])
		var col := UiKit.COLOR_OK if amount >= 0 else UiKit.COLOR_ERROR
		var t := Time.get_datetime_dict_from_unix_time(int(e["t"]))
		var line := "%02d.%02d %02d:%02d  %s%s  —  %s" % [t["day"], t["month"], t["hour"], t["minute"], "+" if amount >= 0 else "", GameState.fmt_money(amount), String(e["text"])]
		var lab := UiKit.make_label(line, 17, col)
		lab.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		_history.add_child(lab)
	_benefit_btn.text = "Пособие"
