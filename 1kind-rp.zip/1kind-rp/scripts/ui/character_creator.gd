extends Control
## Создание персонажа: имя, фамилия, пол, дата рождения и внешность
## (кожа, волосы, футболка, штаны). Модель вращается для предпросмотра.
## Показывается один раз — при первом входе в мир, если паспорт не заполнен.

signal finished

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const ModelScript = preload("res://scripts/player/character_model.gd")

var _first: LineEdit
var _last: LineEdit
var _male_btn: Button
var _female_btn: Button
var _gender: String = "м"
var _birth: String = "01.01.2000"
var _preview: Node3D
var _spin: float = 0.6
var _app: Dictionary = {}


func _ready() -> void:
		process_mode = Node.PROCESS_MODE_ALWAYS
		set_anchors_preset(Control.PRESET_FULL_RECT)
		add_child(UiKit.make_dim(0.85))

		var root := HBoxContainer.new()
		root.set_anchors_preset(Control.PRESET_FULL_RECT)
		root.add_theme_constant_override("separation", 10)
		add_child(root)

		# 3D-предпросмотр персонажа.
		var preview_holder := SubViewportContainer.new()
		preview_holder.stretch = true
		preview_holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		root.add_child(preview_holder)
		var vp := SubViewport.new()
		vp.transparent_bg = true
		vp.msaa_3d = Viewport.MSAA_2X
		preview_holder.add_child(vp)
		var cam := Camera3D.new()
		cam.position = Vector3(0, 1.3, 3.1)
		cam.fov = 45.0
		vp.add_child(cam)
		var light := DirectionalLight3D.new()
		light.rotation_degrees = Vector3(-35, 40, 0)
		light.light_energy = 1.2
		vp.add_child(light)
		_preview = Node3D.new()
		vp.add_child(_preview)
		var model := Node3D.new()
		model.set_script(ModelScript)
		_preview.add_child(model)
		_app = GameState.appearance.duplicate()
		GameState.apply_appearance_to_model(model)

		# Панель настроек.
		var panel := UiKit.make_panel()
		panel.custom_minimum_size = Vector2(560, 0)
		panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		root.add_child(panel)
		var vb := VBoxContainer.new()
		vb.add_theme_constant_override("separation", 10)
		panel.add_child(vb)
		vb.add_child(UiKit.make_title("Создание персонажа", 36))
		var sub := UiKit.make_label("Так вас увидит Ванбург. Данные попадут в паспорт.", 19, UiKit.COLOR_MUTED)
		sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(sub)

		var grid := GridContainer.new()
		grid.columns = 2
		grid.add_theme_constant_override("h_separation", 12)
		grid.add_theme_constant_override("v_separation", 8)
		vb.add_child(grid)
		_form_line(grid, "Имя")
		_first = UiKit.make_line_edit("Иван")
		_first.max_length = 16
		grid.add_child(_first)
		_form_line(grid, "Фамилия")
		_last = UiKit.make_line_edit("Ванбургов")
		_last.max_length = 20
		grid.add_child(_last)
		_form_line(grid, "Дата рождения")
		var birth := UiKit.make_line_edit("01.01.2000")
		birth.max_length = 10
		birth.text_changed.connect(func(t: String) -> void: _birth = t)
		grid.add_child(birth)
		_form_line(grid, "Пол")
		var g := HBoxContainer.new()
		g.add_theme_constant_override("separation", 8)
		grid.add_child(g)
		_male_btn = UiKit.make_button("Мужской", "gold", Vector2(130, 50), 20)
		_male_btn.pressed.connect(func() -> void: _set_gender("м"))
		g.add_child(_male_btn)
		_female_btn = UiKit.make_button("Женский", "blue", Vector2(130, 50), 20)
		_female_btn.pressed.connect(func() -> void: _set_gender("ж"))
		g.add_child(_female_btn)

		vb.add_child(UiKit.make_label("Внешность", 24, UiKit.COLOR_GOLD))
		_swatches(vb, "Кожа", "skin", GameState.SKIN_TONES)
		_swatches(vb, "Волосы", "hair", GameState.HAIR_COLORS)
		_swatches(vb, "Футболка", "shirt", GameState.SHIRT_COLORS)
		_swatches(vb, "Штаны", "pants", GameState.PANTS_COLORS)

		var create := UiKit.make_button("Начать жизнь в Ванбурге", "gold", Vector2(480, 68))
		create.pressed.connect(_on_create)
		vb.add_child(create)
		var note := UiKit.make_label("Никнейм — это ваш аккаунт. Имя и фамилия — паспортные данные.", 16, UiKit.COLOR_MUTED)
		note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		vb.add_child(note)


func _form_line(grid: Control, label: String) -> void:
		grid.add_child(UiKit.make_label(label, 21, UiKit.COLOR_MUTED))


func _set_gender(g: String) -> void:
		_gender = g
		_style_as(_male_btn, "gold" if g == "м" else "blue")
		_style_as(_female_btn, "gold" if g == "ж" else "blue")


## Перекрашивает кнопку в цветовую схему UiKit (gold/blue).
func _style_as(b: Button, kind: String) -> void:
		b.add_theme_stylebox_override("normal", UiKit.button_style(kind))
		b.add_theme_stylebox_override("hover", UiKit.button_style(kind, Color(1.12, 1.12, 1.12)))
		b.add_theme_stylebox_override("pressed", UiKit.button_style(kind, Color(0.72, 0.72, 0.8)))
		var text_color := UiKit.COLOR_NAVY if kind == "gold" else Color.WHITE
		b.add_theme_color_override("font_color", text_color)
		b.add_theme_color_override("font_hover_color", text_color)
		b.add_theme_color_override("font_pressed_color", text_color)


func _swatches(parent: Control, title: String, key: String, variants: Array) -> void:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		parent.add_child(row)
		var l := UiKit.make_label(title, 20, UiKit.COLOR_MUTED)
		l.custom_minimum_size = Vector2(110, 0)
		row.add_child(l)
		for hex in variants:
				var b := Button.new()
				b.custom_minimum_size = Vector2(52, 44)
				b.focus_mode = Control.FOCUS_NONE
				var sb := StyleBoxFlat.new()
				sb.bg_color = Color(String(hex))
				sb.set_corner_radius_all(10)
				sb.set_border_width_all(3)
				sb.border_color = UiKit.COLOR_GOLD if String(_app.get(key, "")) == String(hex) else Color(0, 0, 0, 0)
				b.add_theme_stylebox_override("normal", sb)
				b.add_theme_stylebox_override("hover", sb)
				b.add_theme_stylebox_override("pressed", sb)
				b.pressed.connect(func() -> void:
						_app[key] = String(hex)
						_refresh_preview()
						AudioManager.play_sfx("click")
				)
				row.add_child(b)


func _refresh_preview() -> void:
		for m in _preview.get_children():
				if m.has_method("set_appearance"):
						m.call("set_appearance", _app)


func _process(delta: float) -> void:
		_spin += delta * 0.8
		_preview.rotation.y = _spin


func _on_create() -> void:
		var first := _first.text.strip_edges()
		var last := _last.text.strip_edges()
		if first.is_empty():
				first = "Житель"
		if last.is_empty():
				last = "Ванбурга"
		var birth := _birth.strip_edges()
		if birth.length() != 10:
				birth = "01.01.2000"
		GameState.passport = {"first": first, "last": last, "gender": _gender, "birth": birth, "city": "Ванбург", "issued": Time.get_unix_time_from_system()}
		GameState.appearance = _app.duplicate()
		GameState.save_profile()
		finished.emit()
