extends "res://scripts/world/districts/district.gd"
## Торговый квартал (северо-восток): магазин, автосалон, агентство
## недвижимости и большая парковка с разметкой.

const Kit = preload("res://scripts/world/world_kit.gd")

const ORIGIN := Vector3(35.0, 0.0, -35.0)


func build() -> void:
	name = "Commercial"
	_build_shops()
	_build_parking_lot()


func _build_shops() -> void:
	# Ряд зданий лицом к улице (вход со стороны +Z). Каждое здание ведёт в свой интерьер.
	var shops: Array = [
		{"x": -20.5, "w": 9.0, "tex": "concrete", "sign": "ВАНБИ-АВТО", "action": "enter:dealer_econ", "title": "Автосалон «Ванби-Авто»", "prompt": "Войти в автосалон (эконом)"},
		{"x": -8.5, "w": 13.0, "tex": "brick_red", "sign": "МАГАЗИН 24/7", "action": "enter:shop247", "title": "Магазин 24/7", "prompt": "Зайти в магазин"},
		{"x": 5.5, "w": 13.0, "tex": "concrete", "sign": "КОРОНА-МОТОР", "action": "enter:dealer_mid", "title": "Автосалон «Корона-Мотор»", "prompt": "Войти в автосалон (средний класс)"},
		{"x": 19.5, "w": 13.0, "tex": "stone", "sign": "НЕДВИЖИМОСТЬ", "action": "property", "title": "Агентство «Золотый ключ»", "prompt": "Посмотреть объекты"},
	]
	for s in shops:
		var lx: float = s["x"]
		var bw: float = s["w"]
		var wall_tex: String = s["tex"]
		var sign_text: String = s["sign"]
		var action: String = s["action"]
		var title: String = s["title"]
		var prompt: String = s["prompt"]
		Kit.add_shop(self, ORIGIN + Vector3(lx, 0, 21), Vector3(bw, 7, 10), wall_tex, sign_text, 0.0)
		Kit.add_interactable(self, ORIGIN + Vector3(lx, 0, 27.5), action, title, prompt, 2.8)
	# Второй ряд лицом к парковке (вход со стороны -Z): премиум-салон и гараж.
	var back: Array = [
		{"x": 6.0, "w": 14.0, "tex": "stone", "sign": "ЗОЛОТОЙ РУЛЬ", "action": "enter:dealer_premium", "title": "Автосалон «Золотой Руль»", "prompt": "Войти в автосалон (премиум)"},
		{"x": 26.0, "w": 12.0, "tex": "concrete", "sign": "ГАРАЖ", "action": "enter:garage", "title": "Ваш гараж", "prompt": "Войти в гараж"},
	]
	for s2 in back:
		var bx: float = s2["x"]
		var bw2: float = s2["w"]
		var tex2: String = s2["tex"]
		var sign2: String = s2["sign"]
		var action2: String = s2["action"]
		var title2: String = s2["title"]
		var prompt2: String = s2["prompt"]
		Kit.add_shop(self, ORIGIN + Vector3(bx, 0, -26), Vector3(bw2, 7, 9), tex2, sign2, 180.0)
		Kit.add_interactable(self, ORIGIN + Vector3(bx, 0, -26 - 7.0), action2, title2, prompt2, 2.8)


func _build_parking_lot() -> void:
	var asphalt := Kit.tri_mat("asphalt", 6.0, Color(0.9, 0.9, 0.95))
	var white := Kit.color_mat(Color(0.95, 0.95, 0.95), 0.9)
	var center := ORIGIN + Vector3(4, 0, -10)
	Kit.add_flat(self, center.x, center.z, 36.0, 24.0, 0.05, asphalt)
	var rng := RandomNumberGenerator.new()
	rng.seed = 424242
	var colors: Array = [
		Color(0.8, 0.1, 0.1), Color(0.1, 0.35, 0.8), Color(0.95, 0.75, 0.15),
		Color(0.85, 0.85, 0.88), Color(0.1, 0.1, 0.12), Color(0.1, 0.5, 0.3), Color(0.5, 0.2, 0.6),
	]
	for row_z in [-17.0, -3.0]:
		var rz: float = row_z
		for k in range(13):
			var x := -14.0 + 3.0 * float(k)
			Kit.add_box(self, ORIGIN + Vector3(x, 0.058, rz), Vector3(0.12, 0.012, 5.5), white, false)
		for k in range(12):
			if rng.randf() < 0.55:
				var cx := -12.5 + 3.0 * float(k)
				var col: Color = colors[rng.randi() % colors.size()]
				var rot := 90.0 if rz > -10.0 else -90.0
				Kit.add_car(self, ORIGIN + Vector3(cx, 0, rz), rot, col)
	Kit.add_sign(self, ORIGIN + Vector3(-15.5, 0, -10), "parking", 90.0)
	Kit.add_sign(self, ORIGIN + Vector3(22.5, 0, -10), "parking", -90.0)
	for i in range(5):
		Kit.add_tree(self, ORIGIN + Vector3(-12.0 + 8.0 * float(i), 0, -24.0), 1.0, i + 1)
	for i in range(4):
		Kit.add_lamp(self, ORIGIN + Vector3(-12.0 + 12.0 * float(i), 0, -10.0), 0.0)
