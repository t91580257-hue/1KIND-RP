extends "res://scripts/world/districts/district.gd"
## Улицы: проезжая часть, тротуары, разметка, фонари, знаки, остановки, парковка.

const Kit = preload("res://scripts/world/world_kit.gd")
const Layout = preload("res://scripts/world/city_layout.gd")


func build() -> void:
	name = "Streets"
	_build_roads()
	_build_sidewalks()
	_build_markings()
	_build_lamps()
	_build_signs()
	_build_bus_stops()
	_build_street_parking()


func _segments_between(breaks: Array, lo: float, hi: float, min_len: float) -> Array:
	var segs: Array = []
	var start := lo
	for br in breaks:
		var a: float = br[0]
		var b: float = br[1]
		if a - start >= min_len:
			segs.append([start, a])
		start = maxf(start, b)
	if hi - start >= min_len:
		segs.append([start, hi])
	return segs


func _build_roads() -> void:
	var asphalt := Kit.tri_mat("asphalt", 6.0)
	for c in Layout.LINES:
		var line: float = c
		Kit.add_flat(self, 0.0, line, Layout.EXTENT * 2.0, Layout.ROAD_W, 0.04, asphalt)
		Kit.add_flat(self, line, 0.0, Layout.ROAD_W, Layout.EXTENT * 2.0, 0.042, asphalt)


func _build_sidewalks() -> void:
	var walk := Kit.tri_mat("concrete", 3.0, Color(0.88, 0.88, 0.92))
	var offset := Layout.HALF_ROAD + Layout.SIDEWALK_W * 0.5
	for c in Layout.LINES:
		var line: float = c
		var breaks: Array = []
		for l in Layout.LINES:
			var lf: float = l
			breaks.append([lf - Layout.HALF_ROAD, lf + Layout.HALF_ROAD])
		var segs := _segments_between(breaks, -Layout.EXTENT, Layout.EXTENT, 1.0)
		for seg in segs:
			var a: float = seg[0]
			var b: float = seg[1]
			var mid := (a + b) * 0.5
			var length := b - a
			for side in [-1.0, 1.0]:
				var s: float = side
				Kit.add_flat(self, mid, line + s * offset, length, Layout.SIDEWALK_W, 0.08, walk)
				Kit.add_flat(self, line + s * offset, mid, Layout.SIDEWALK_W, length, 0.08, walk)


func _build_markings() -> void:
	for c in Layout.LINES:
		var line: float = c
		var breaks: Array = []
		for l in Layout.LINES:
			var lf: float = l
			var half := Layout.HALF_ROAD
			if line == 0.0 and lf == 0.0:
				half = Layout.PLAZA_HALF
			breaks.append([lf - half, lf + half])
		var segs := _segments_between(breaks, -Layout.EXTENT, Layout.EXTENT, 14.0)
		for seg in segs:
			var a: float = seg[0]
			var b: float = seg[1]
			var mid := (a + b) * 0.5
			Kit.add_lane_line(self, mid, line, b - a, true)
			Kit.add_lane_line(self, line, mid, b - a, false)


func _build_lamps() -> void:
	var ts: Array = [-100.0, -45.0, 45.0, 100.0]
	for c in Layout.LINES:
		var line: float = c
		for tv in ts:
			var t: float = tv
			Kit.add_lamp(self, Vector3(t, 0, line + 8.6), 90.0)
			Kit.add_lamp(self, Vector3(t, 0, line - 8.6), -90.0)
			Kit.add_lamp(self, Vector3(line + 8.6, 0, t), 180.0)
			Kit.add_lamp(self, Vector3(line - 8.6, 0, t), 0.0)


func _build_signs() -> void:
	# Знаки «СТОП» на перекрёстках (кроме площади).
	for cx in Layout.LINES:
		for cz in Layout.LINES:
			var fx: float = cx
			var fz: float = cz
			if fx == 0.0 and fz == 0.0:
				continue
			Kit.add_sign(self, Vector3(fx + 8.2, 0, fz + 8.2), "stop", 0.0)
	Kit.add_sign(self, Vector3(34.0, 0, 8.5), "speed", 0.0)
	Kit.add_sign(self, Vector3(-34.0, 0, -8.5), "speed", 180.0)
	Kit.add_sign(self, Vector3(8.5, 0, -34.0), "speed", 90.0)
	Kit.add_sign(self, Vector3(-8.5, 0, 34.0), "speed", -90.0)
	Kit.add_sign(self, Vector3(25.0, 0, 8.5), "parking", 0.0)
	Kit.add_sign(self, Vector3(-25.0, 0, -8.5), "parking", 180.0)
	# Таблички с названиями улиц.
	Kit.add_sign(self, Vector3(50.0, 0, 8.4), "street", 0.0, "Центральный проспект")
	Kit.add_sign(self, Vector3(8.4, 0, 50.0), "street", 90.0, "Улица Короны")
	Kit.add_sign(self, Vector3(-50.0, 0, -78.4), "street", 180.0, "Синяя улица")
	Kit.add_sign(self, Vector3(-50.0, 0, 78.4), "street", 0.0, "Золотая улица")
	Kit.add_sign(self, Vector3(-78.4, 0, 50.0), "street", -90.0, "Западная улица")
	Kit.add_sign(self, Vector3(78.4, 0, -50.0), "street", 90.0, "Восточная улица")


func _build_bus_stops() -> void:
	var stops: Array = [
		{"pos": Vector3(30.0, 0, 8.2), "rot": 180.0, "name": "Остановка «Площадь»"},
		{"pos": Vector3(-30.0, 0, -8.2), "rot": 0.0, "name": "Остановка «Ратуша»"},
		{"pos": Vector3(8.2, 0, -30.0), "rot": -90.0, "name": "Остановка «Торговая»"},
		{"pos": Vector3(-8.2, 0, 30.0), "rot": 90.0, "name": "Остановка «Высотки»"},
	]
	for st in stops:
		var pos: Vector3 = st["pos"]
		var rot: float = st["rot"]
		var stop_name: String = st["name"]
		Kit.add_bus_stop(self, pos, stop_name, rot)
		var rr := deg_to_rad(rot)
		var fwd := Vector3(sin(rr), 0.0, cos(rr))
		Kit.add_interactable(self, pos + fwd * 1.9, "bus_stop", stop_name, "Осмотреть остановку", 2.4)


## Парковочные места вдоль Центрального проспекта с разметкой и машинами.
func _build_street_parking() -> void:
	var white := Kit.color_mat(Color(0.95, 0.95, 0.95), 0.9)
	var colors: Array = [Color(0.8, 0.1, 0.1), Color(0.1, 0.35, 0.8), Color(0.95, 0.75, 0.15), Color(0.85, 0.85, 0.88), Color(0.1, 0.1, 0.12), Color(0.1, 0.5, 0.3)]
	# Восток: стоянка у южного тротуара, Запад: у северного.
	for side in [1.0, -1.0]:
		var s: float = side
		var rot := 0.0 if s > 0.0 else 180.0
		Kit.add_box(self, Vector3(s * 45.0, 0.056, s * 3.3), Vector3(36.0, 0.012, 0.12), white, false)
		for k in range(7):
			var x := s * (27.0 + 6.0 * float(k))
			Kit.add_box(self, Vector3(x, 0.056, s * 4.65), Vector3(0.12, 0.012, 2.7), white, false)
		for k in [0, 1, 3, 4, 5]:
			var kk: int = k
			var x := s * (30.0 + 6.0 * float(kk))
			Kit.add_car(self, Vector3(x, 0.0, s * 4.7), rot, colors[(kk + (0 if s > 0.0 else 3)) % colors.size()])
