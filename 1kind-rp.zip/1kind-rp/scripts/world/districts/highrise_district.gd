extends "res://scripts/world/districts/district.gd"
## Жилой район: высотки (юго-запад). Три многоэтажных дома и двор.

const Kit = preload("res://scripts/world/world_kit.gd")

const ORIGIN := Vector3(-35.0, 0.0, 35.0)


func build() -> void:
	name = "Highrise"
	var t1 := Kit.add_building(self, ORIGIN + Vector3(-12, 0, -10), Vector3(14, 52, 14), Color(0.96, 0.93, 0.88))
	var t2 := Kit.add_building(self, ORIGIN + Vector3(8, 0, 12), Vector3(16, 40, 14), Color(0.86, 0.9, 1.0))
	var t3 := Kit.add_building(self, ORIGIN + Vector3(-12, 0, 14), Vector3(14, 60, 14), Color(0.95, 0.9, 0.78))
	Kit.add_label(t3, "КОРОНА-ТАУЭР", Vector3(0, 30.0, 7.15), 0.03, Color("ffbe28"))
	Kit.add_label(t2, "ЖК «СИНИЙ»", Vector3(0, 22.0, 7.15), 0.024, Color("6fb8ff"))
	Kit.add_label(t1, "ЖК «ЗОЛОТОЙ»", Vector3(0, 26.0, 7.15), 0.024, Color("ffbe28"))
	_build_courtyard()


func _build_courtyard() -> void:
	var walk := Kit.tri_mat("concrete", 3.0, Color(0.9, 0.9, 0.95))
	Kit.add_flat(self, ORIGIN.x - 2.0, ORIGIN.z + 2.0, 6.0, 40.0, 0.05, walk)
	Kit.add_flat(self, ORIGIN.x + 4.0, ORIGIN.z + 2.0, 30.0, 3.0, 0.05, walk)
	var tree_spots: Array = [
		Vector2(-22, -22), Vector2(-4, -22), Vector2(4, -22), Vector2(14, -20), Vector2(22, -6), Vector2(22, 4),
		Vector2(-23, 2), Vector2(2, 0), Vector2(14, 0), Vector2(22, 22), Vector2(-4, 24), Vector2(2, 24),
	]
	for i in range(tree_spots.size()):
		var sp: Vector2 = tree_spots[i]
		Kit.add_tree(self, ORIGIN + Vector3(sp.x, 0, sp.y), 1.0, i)
	for bs in [Vector2(-5, -4), Vector2(1, -5), Vector2(6, -3), Vector2(18, 8), Vector2(18, -4)]:
		var b: Vector2 = bs
		Kit.add_bush(self, ORIGIN + Vector3(b.x, 0, b.y), 1.0)
	Kit.add_bench(self, ORIGIN + Vector3(-4.0, 0.05, 6.0), 90.0)
	Kit.add_bench(self, ORIGIN + Vector3(10.0, 0.05, 4.2), 0.0)
	Kit.add_bench(self, ORIGIN + Vector3(18.0, 0.05, 2.0), 90.0)
	Kit.add_lamp(self, ORIGIN + Vector3(-2.0, 0, -2.0), 0.0)
	Kit.add_lamp(self, ORIGIN + Vector3(16.0, 0, 6.0), 180.0)
	Kit.add_lamp(self, ORIGIN + Vector3(-2.0, 0, 22.0), 0.0)
