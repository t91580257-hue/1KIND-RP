extends Node3D
## Базовый класс района города. Наследники переопределяют build()
## и создают свои объекты как дочерние узлы.


func build() -> void:
	push_warning("District.build() не переопределён в %s" % name)
