extends "res://scripts/world/districts/district.gd"
## Окраина: живая изгородь по границе игровой зоны, деревья, дальние холмы.

const Kit = preload("res://scripts/world/world_kit.gd")
const Layout = preload("res://scripts/world/city_layout.gd")


func build() -> void:
	name = "Outskirts"
	_build_boundary()
	_build_trees()
	_build_hills()


func _build_boundary() -> void:
	var hedge := Kit.color_mat(Color(0.12, 0.36, 0.2), 0.95)
	var b := Layout.BOUNDARY
	var span := b * 2.0 + 2.0
	Kit.add_box(self, Vector3(0, 2.0, -b), Vector3(span, 4.0, 2.0), hedge, true, 0.0, false)
	Kit.add_box(self, Vector3(0, 2.0, b), Vector3(span, 4.0, 2.0), hedge, true, 0.0, false)
	Kit.add_box(self, Vector3(-b, 2.0, 0), Vector3(2.0, 4.0, span), hedge, true, 0.0, false)
	Kit.add_box(self, Vector3(b, 2.0, 0), Vector3(2.0, 4.0, span), hedge, true, 0.0, false)


func _build_trees() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 20241
	var placed := 0
	var attempts := 0
	while placed < 150 and attempts < 3000:
		attempts += 1
		var x := rng.randf_range(-985.0, 985.0)
		var z := rng.randf_range(-985.0, 985.0)
		if maxf(absf(x), absf(z)) < 158.0:
			continue
		var on_road := false
		for c in Layout.LINES:
			var line: float = c
			if absf(x - line) < 10.0 or absf(z - line) < 10.0:
				on_road = true
		if on_road:
			continue
		Kit.add_tree(self, Vector3(x, 0, z), rng.randf_range(0.9, 1.4), rng.randi() % 3)
		placed += 1
	for i in range(100):
		var bx := rng.randf_range(-985.0, 985.0)
		var bz := rng.randf_range(-985.0, 985.0)
		if maxf(absf(bx), absf(bz)) < 158.0:
			continue
		var near_road := false
		for c in Layout.LINES:
			var line2: float = c
			if absf(bx - line2) < 10.0 or absf(bz - line2) < 10.0:
				near_road = true
		if near_road:
			continue
		Kit.add_bush(self, Vector3(bx, 0, bz), rng.randf_range(1.0, 1.6))


func _build_hills() -> void:
	var hill := Kit.color_mat(Color(0.2, 0.3, 0.5), 1.0)
	for i in range(10):
		var a := TAU * float(i) / 10.0 + 0.2
		var r := 1070.0 + 35.0 * float(i % 3)
		var h := 42.0 + 11.0 * float(i % 4)
		Kit.add_cone(self, Vector3(cos(a) * r, h * 0.5, sin(a) * r), 42.0, h, hill, 6)
