extends "res://scripts/world/districts/district.gd"
## Жилой район: дома (юго-восток). Частные дома с садами и две малоэтажки.

const Kit = preload("res://scripts/world/world_kit.gd")

const ORIGIN := Vector3(35.0, 0.0, 35.0)


func build() -> void:
	name = "Residential"
	var roofs: Array = [Color(0.1, 0.22, 0.45), Color(0.45, 0.12, 0.1), Color(0.12, 0.3, 0.3)]
	var walls: Array = ["brick_red", "concrete", "wood", "stone", "brick_red", "concrete"]
	var i := 0
	for lz in [6.0, 19.0]:
		var rz: float = lz
		for lx in [-14.0, 0.0, 14.0]:
			var rx: float = lx
			_add_house(ORIGIN + Vector3(rx, 0, rz), walls[i % walls.size()], roofs[i % roofs.size()])
			i += 1
	Kit.add_building(self, ORIGIN + Vector3(-4, 0, -18), Vector3(16, 24, 12), Color(0.9, 0.95, 1.0))
	Kit.add_building(self, ORIGIN + Vector3(14, 0, -18), Vector3(20, 18, 12), Color(1.0, 0.92, 0.82))
	# Подъездная дорожка и парковка во дворе.
	var asphalt := Kit.tri_mat("asphalt", 6.0, Color(0.9, 0.9, 0.95))
	Kit.add_flat(self, ORIGIN.x, ORIGIN.z - 6.0, 52.0, 4.0, 0.05, asphalt)
	var white := Kit.color_mat(Color(0.95, 0.95, 0.95), 0.9)
	Kit.add_car(self, ORIGIN + Vector3(-8, 0, -4.5), 0.0, Color(0.1, 0.35, 0.8))
	Kit.add_car(self, ORIGIN + Vector3(8, 0, -4.5), 180.0, Color(0.85, 0.85, 0.88))
	Kit.add_box(self, ORIGIN + Vector3(0, 0.056, -4.5), Vector3(0.12, 0.012, 2.6), white, false)
	for k in range(6):
		Kit.add_tree(self, ORIGIN + Vector3(-22.0 + 9.0 * float(k), 0, 13.0), 0.9, k)
	Kit.add_lamp(self, ORIGIN + Vector3(-7.0, 0, 13.0), 0.0)
	Kit.add_lamp(self, ORIGIN + Vector3(7.0, 0, 13.0), 0.0)
	Kit.add_lamp(self, ORIGIN + Vector3(21.0, 0, 13.0), 0.0)


func _add_house(pos: Vector3, wall_tex: String, roof_col: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	add_child(root)
	Kit.add_box(root, Vector3(0, 3, 0), Vector3(9, 6, 8), Kit.tri_mat(wall_tex, 3.0), true)
	Kit.add_prism(root, Vector3(0, 7.4, 0), Vector3(10.4, 2.8, 8.8), Kit.color_mat(roof_col, 0.7))
	Kit.add_box(root, Vector3(-1.5, 1.1, 4.03), Vector3(1.2, 2.2, 0.1), Kit.color_mat(Color("123a73"), 0.5), false)
	Kit.add_box(root, Vector3(2.0, 1.8, 4.03), Vector3(2.0, 1.4, 0.1), Kit.glass_mat(), false)
	Kit.add_box(root, Vector3(-2.0, 4.5, 4.03), Vector3(1.6, 1.3, 0.1), Kit.glass_mat(), false)
	Kit.add_box(root, Vector3(2.5, 4.5, 4.03), Vector3(1.6, 1.3, 0.1), Kit.glass_mat(), false)
	Kit.add_box(root, Vector3(2.8, 8.4, -1.0), Vector3(0.9, 2.2, 0.9), Kit.tri_mat("brick_red", 2.0), false)
	Kit.add_box(root, Vector3(-1.5, 2.45, 4.5), Vector3(2.2, 0.1, 1.2), Kit.color_mat(Color("ffbe28"), 0.4, 0.5), false)
	Kit.add_bush(root, Vector3(-3.6, 0, 5.2), 1.0)
	Kit.add_bush(root, Vector3(3.8, 0, 5.2), 1.0)
