extends "res://scripts/world/districts/district.gd"
## Гражданский квартал (северо-запад): Ратуша с Центром занятости и парк.

const Kit = preload("res://scripts/world/world_kit.gd")

const ORIGIN := Vector3(-35.0, 0.0, -35.0)


func build() -> void:
	name = "Civic"
	_build_town_hall()
	_build_park()


func _build_town_hall() -> void:
	var hall := Kit.add_building(self, ORIGIN + Vector3(0, 0, 19), Vector3(26, 14, 14), Color(1.0, 0.95, 0.85), 0.0, false)
	Kit.add_crown(hall, Vector3(0, 14.8, 0), 3.2)
	var front := 7.0
	var stone := Kit.tri_mat("stone", 2.0, Color(0.95, 0.9, 0.8))
	for cx in [-9.0, -5.4, -1.8, 1.8, 5.4, 9.0]:
		var x: float = cx
		Kit.add_cylinder(hall, Vector3(x, 2.2, front + 1.2), 0.38, 4.4, stone, true, 12)
	Kit.add_label(hall, "РАТУША · ЦЕНТР ЗАНЯТОСТИ", Vector3(0, 11.0, front + 0.12), 0.02, Color("ffbe28"))
	Kit.add_interactable(self, ORIGIN + Vector3(0, 0, 27.5), "jobs", "Центр занятости", "Найти работу", 2.8)


func _build_park() -> void:
	var sand := Kit.tri_mat("sand", 3.0, Color(1.0, 0.95, 0.82))
	Kit.add_flat(self, ORIGIN.x, ORIGIN.z, 3.0, 36.0, 0.05, sand)
	Kit.add_flat(self, ORIGIN.x, ORIGIN.z, 48.0, 3.0, 0.05, sand)
	# Памятник с короной.
	var stone := Kit.tri_mat("stone", 2.0, Color(0.85, 0.87, 0.95))
	Kit.add_box(self, ORIGIN + Vector3(0, 0.6, -10), Vector3(4.0, 1.2, 4.0), stone, true)
	Kit.add_box(self, ORIGIN + Vector3(0, 1.6, -10), Vector3(2.4, 0.8, 2.4), stone, false)
	Kit.add_crown(self, ORIGIN + Vector3(0, 2.0, -10), 2.0)
	var tree_spots: Array = [
		Vector2(-20, -20), Vector2(-12, -22), Vector2(-4, -21), Vector2(7, -22), Vector2(15, -20), Vector2(22, -22),
		Vector2(-21, -8), Vector2(-12, -11), Vector2(11, -12), Vector2(21, -9), Vector2(-21, 7), Vector2(21, 6),
		Vector2(-22, 12), Vector2(22, 12),
	]
	for i in range(tree_spots.size()):
		var sp: Vector2 = tree_spots[i]
		Kit.add_tree(self, ORIGIN + Vector3(sp.x, 0, sp.y), 1.0 + 0.1 * float(i % 3), i)
	var bush_spots: Array = [Vector2(-8, -3), Vector2(8, -3), Vector2(-8, 4), Vector2(8, 4), Vector2(-16, -14), Vector2(16, -14)]
	for bs in bush_spots:
		var b: Vector2 = bs
		Kit.add_bush(self, ORIGIN + Vector3(b.x, 0, b.y), 1.2)
	Kit.add_bench(self, ORIGIN + Vector3(-5.5, 0.05, -1.7), 0.0)
	Kit.add_bench(self, ORIGIN + Vector3(5.5, 0.05, -1.7), 0.0)
	Kit.add_bench(self, ORIGIN + Vector3(-1.9, 0.05, -16.0), 90.0)
	Kit.add_bench(self, ORIGIN + Vector3(1.9, 0.05, -16.0), -90.0)
