extends "res://scripts/world/districts/district.gd"
## Четыре новых внешних района Ванбурга: завод, аэропорт, стадион и порт.

const Kit = preload("res://scripts/world/world_kit.gd")

func build() -> void:
	name = "Expansion"
	_build_industrial()
	_build_airport()
	_build_stadium()
	_build_port()


func _build_industrial() -> void:
	var o := Vector3(-105.0, 0.0, -105.0)
	var asphalt := Kit.tri_mat("asphalt", 6.0, Color(0.8, 0.82, 0.86))
	Kit.add_flat(self, o.x, o.z, 48.0, 38.0, 0.05, asphalt)
	var factory := Kit.add_building(self, o + Vector3(-13.0, 0.0, -5.0), Vector3(22.0, 12.0, 18.0), Color(0.72, 0.76, 0.82))
	Kit.add_label(factory, "ЗАВОД 1K INDUSTRIES", Vector3(0, 8.0, 9.2), 0.025, Color("ffbe28"))
	var warehouse := Kit.add_building(self, o + Vector3(15.0, 0.0, 8.0), Vector3(18.0, 8.0, 16.0), Color(0.82, 0.72, 0.56))
	Kit.add_label(warehouse, "СКЛАД №1", Vector3(0, 5.5, 8.2), 0.022, Color("ffbe28"))
	for i in range(4):
		Kit.add_box(self, o + Vector3(-22.0 + float(i) * 13.0, 1.0, 20.0), Vector3(8.0, 2.0, 5.0), Kit.color_mat(Color(0.16, 0.28, 0.42)), true)
	Kit.add_lamp(self, o + Vector3(-24.0, 0, -27.0), 0.0)
	Kit.add_lamp(self, o + Vector3(22.0, 0, -27.0), 0.0)


func _build_airport() -> void:
	var o := Vector3(105.0, 0.0, -105.0)
	var runway := Kit.color_mat(Color(0.16, 0.18, 0.22), 0.95)
	var white := Kit.color_mat(Color(0.95, 0.95, 0.9), 0.8)
	Kit.add_flat(self, o.x, o.z - 7.0, 48.0, 15.0, 0.06, runway)
	for i in range(12):
		Kit.add_box(self, o + Vector3(-21.0 + float(i) * 3.8, 0.07, -7.0), Vector3(2.0, 0.015, 0.25), white, false)
	var terminal := Kit.add_building(self, o + Vector3(0.0, 0.0, 18.0), Vector3(34.0, 9.0, 13.0), Color(0.72, 0.84, 0.94))
	Kit.add_label(terminal, "АЭРОПОРТ ВАНБУРГ", Vector3(0, 6.5, 6.8), 0.028, Color("ffbe28"))
	Kit.add_box(self, o + Vector3(-4.0, 1.1, -1.0), Vector3(9.0, 2.2, 3.0), Kit.color_mat(Color(0.9, 0.9, 0.94)), true)
	Kit.add_box(self, o + Vector3(0.0, 2.3, -1.0), Vector3(3.0, 0.25, 2.0), Kit.color_mat(Color("ffbe28")), false)
	for x in [-20.0, 20.0]:
		Kit.add_lamp(self, o + Vector3(x, 0, -20.0), 0.0)
		Kit.add_lamp(self, o + Vector3(x, 0, 0.0), 0.0)


func _build_stadium() -> void:
	var o := Vector3(-105.0, 0.0, 105.0)
	var grass := Kit.tri_mat("grass", 5.0, Color(0.72, 0.9, 0.68))
	Kit.add_flat(self, o.x, o.z, 48.0, 42.0, 0.06, grass)
	var field := Kit.color_mat(Color(0.12, 0.48, 0.24), 0.95)
	Kit.add_flat(self, o.x, o.z, 27.0, 17.0, 0.09, field)
	var white := Kit.color_mat(Color.WHITE, 0.8)
	Kit.add_box(self, o + Vector3(0, 0.11, 0), Vector3(0.15, 0.02, 17.0), white, false)
	for x in [-13.2, 13.2]:
		Kit.add_box(self, o + Vector3(x, 0.11, 0), Vector3(0.15, 0.02, 17.0), white, false)
	var stand := Kit.add_building(self, o + Vector3(0.0, 0.0, 20.0), Vector3(34.0, 7.0, 7.0), Color(0.12, 0.25, 0.48))
	Kit.add_label(stand, "СТАДИОН КОРОНЫ", Vector3(0, 5.0, 3.8), 0.026, Color("ffbe28"))
	for i in range(8):
		Kit.add_tree(self, o + Vector3(-22.0 + float(i) * 6.2, 0, -20.0), 1.0, i % 3)
	Kit.add_interactable(self, o + Vector3(0, 0, 25.0), "info_board", "Стадион Короны", "Осмотреть стадион", 3.0)


func _build_port() -> void:
	var o := Vector3(105.0, 0.0, 105.0)
	var water := Kit.color_mat(Color(0.12, 0.38, 0.58), 0.25, 0.1)
	var concrete := Kit.tri_mat("concrete", 4.0, Color(0.72, 0.75, 0.8))
	Kit.add_flat(self, o.x + 16.0, o.z, 16.0, 44.0, 0.04, water)
	Kit.add_flat(self, o.x - 8.0, o.z, 30.0, 38.0, 0.08, concrete)
	var warehouse := Kit.add_building(self, o + Vector3(-13.0, 0.0, -11.0), Vector3(17.0, 9.0, 14.0), Color(0.82, 0.78, 0.68))
	Kit.add_label(warehouse, "ГРУЗОВОЙ ТЕРМИНАЛ", Vector3(0, 6.0, 7.2), 0.021, Color("ffbe28"))
	var colors: Array = [Color(0.82, 0.2, 0.16), Color(0.12, 0.35, 0.72), Color(0.9, 0.68, 0.16)]
	for i in range(3):
		Kit.add_box(self, o + Vector3(-17.0 + float(i) * 9.0, 1.2, 8.0), Vector3(7.0, 2.4, 5.0), Kit.color_mat(colors[i]), true)
	Kit.add_box(self, o + Vector3(16.0, 0.7, 0.0), Vector3(2.0, 1.4, 42.0), Kit.color_mat(Color(0.28, 0.3, 0.34)), true)
	Kit.add_lamp(self, o + Vector3(-20.0, 0, -25.0), 0.0)
	Kit.add_lamp(self, o + Vector3(0.0, 0, -25.0), 0.0)
	Kit.add_interactable(self, o + Vector3(-3.0, 0, 13.0), "info_board", "Порт Ванбурга", "Осмотреть порт", 3.0)
