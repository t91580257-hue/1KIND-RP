extends Node
## Обучение новичка (узел мира): 6 шагов с наставником Марком.
##   1. Подойти к наставнику (знакомство с городом).
##   2. Дойти до фонтана (управление: джойстик, камера).
##   3. Первое взаимодействие: открыть банкомат у площади.
##   4. Знакомство с работами: поговорить с диспетчером почты.
##   5. Первое задание: доставить посылку к дому.
##   6. Вернуться к наставнику за наградой (15 000 ₽ + 15 XP + кейс новичка).
## Прогресс сохраняется в профиле (tutorial_step / tutorial_done).

signal step_changed(step: int, title: String, hint: String)

const MarkerScript = preload("res://scripts/world/job_marker.gd")
const NpcScript = preload("res://scripts/world/npc_actor.gd")
const Points = preload("res://scripts/world/job_points.gd")

const STEP_TITLES: Array = [
	"Знакомство с городом",
	"Управление",
	"Первое взаимодействие",
	"Знакомство с работами",
	"Первое задание",
	"Награда за обучение",
]
const STEP_HINTS: Array = [
	"Подойдите к Наставнику Марку (золотой маркер) и нажмите ДЕЙСТВИЕ.",
	"Дойдите до золотого круга у фонтана: джойстик — движение, свайп справа — камера.",
	"Откройте банкомат у площади (подойдите и нажмите ДЕЙСТВИЕ).",
	"Найдите диспетчера почты у магазина 24/7 и поговорите с ним (ДЕЙСТВИЕ).",
	"Заберите посылку у диспетчера и доставьте её к отмеченному дому.",
	"Вернитесь к Наставнику Марку: 15 000 ₽, 15 опыта и кейс новичка!",
]

const MENTOR_POS := Vector3(8.0, 0, 8.0)
const PLAZA_TARGET := Vector3(0, 0, 7.6)
const ATM_POS := Vector3(12.0, 0, 12.0)
const DELIVERY_TARGET := Vector3(21.0, 0, 47.0)

var world: Node3D = null
var player: Node3D = null

var _mentor: Node3D = null
var _marker: Node3D = null


func setup(world_node: Node3D, player_node: Node3D) -> void:
	world = world_node
	player = player_node
	_spawn_mentor()
	_apply_step()


func _spawn_mentor() -> void:
	_mentor = NpcScript.new()
	_mentor.mode = NpcScript.Mode.STAND
	_mentor.npc_name = "Наставник Марк"
	_mentor.shirt_color = "0a1630"
	_mentor.pants_color = "2c3e50"
	_mentor.hat_color = "ffbe28"
	_mentor.position = MENTOR_POS
	_mentor.rotation_degrees.y = 200.0
	_mentor.add_to_group("tutorial_mentor")
	_mentor.name = "TutorialMentor"
	world.add_child(_mentor)


func step() -> int:
	if GameState.tutorial_done:
		return 0
	return clampi(GameState.tutorial_step + 1, 1, 6)


## Диалог с наставником (вызывает мир по кнопке действия рядом с ним).
func on_talk_mentor() -> void:
	if not GameState.tutorial_active():
		GameState.notify("Марк: «Ванбург — твой город. Удачи, новичок!»")
		return
	var s := step()
	if s == 1:
		_advance("Марк: «Добро пожаловать в Ванбург! Площадь перед тобой, магазины — на востоке. Идём дальше.»")
	elif s == 6:
		var res := GameState.grant_tutorial_reward()
		GameState.notify(String(res["text"]))
		_clear_marker()
		step_changed.emit(0, "", "")
	else:
		GameState.notify("Марк: «Следуй золотому маркеру — и всё получится!»")


## Диалог с диспетчером почты.
func on_talk_dispatcher() -> void:
	if not GameState.tutorial_active():
		return
	if step() == 4:
		GameState.add_item("package", 1)
		_advance("Диспетчер: «Вот твоя первая посылка. Доставь её к дому в жилом районе — там уже ждут.»")


## Открыт банкомат (шаг 3).
func on_atm_opened() -> void:
	if GameState.tutorial_active() and step() == 3:
		_advance("Вижу, ты разобрался с банкоматом. Теперь о работах — на востоке, у магазина 24/7.")


func _advance(text: String) -> void:
	GameState.notify(text)
	GameState.tutorial_advance(GameState.tutorial_step + 1)
	_apply_step()


func _marker_pos_for(s: int) -> Vector3:
	match s:
		1, 6:
			return MENTOR_POS
		2:
			return PLAZA_TARGET
		3:
			return ATM_POS
		4:
			return Points.COURIER_GIVER
		5:
			if GameState.has_item("package"):
				return DELIVERY_TARGET
			return Points.COURIER_GIVER
	return Vector3.ZERO


func _apply_step() -> void:
	_clear_marker()
	if not GameState.tutorial_active():
		return
	var s := step()
	if s < 1 or s > 6:
		return
	_marker = MarkerScript.new()
	_marker.kind = "job"
	_marker.label_text = "Обучение %d/6" % s
	_marker.position = _marker_pos_for(s)
	world.add_child(_marker)
	step_changed.emit(s, String(STEP_TITLES[s - 1]), String(STEP_HINTS[s - 1]))


func _process(_delta: float) -> void:
	if not GameState.tutorial_active() or player == null or not is_instance_valid(player):
		return
	var s := step()
	match s:
		2:
			if player.global_position.distance_to(PLAZA_TARGET) < 4.0:
				_advance("Чувствуешь управление? Бег — кнопка БЕГ, прыжок — ПРЫЖОК. Загляни потом в телефон.")
		5:
			if GameState.has_item("package"):
				if player.global_position.distance_to(DELIVERY_TARGET) < 5.0:
					GameState.remove_item("package", 1)
					GameState.add_xp(10)
					_advance("Первая доставка выполнена! Возвращайся к наставнику за наградой.")
			else:
				# Посылка потеряна (выброшена) — маркер снова у диспетчера.
				if _marker != null and is_instance_valid(_marker) and _marker.position != Points.COURIER_GIVER:
					_apply_step()


func _clear_marker() -> void:
	if _marker != null and is_instance_valid(_marker):
		_marker.queue_free()
	_marker = null


## Подсказка у наставника (шаги 1 и 6).
func _physics_process(_delta: float) -> void:
	if player == null or not is_instance_valid(player) or world == null:
		return
	if world.get("_hud") == null:
		return
	if GameState.tutorial_active() and step() in [1, 6]:
		if player.global_position.distance_to(MENTOR_POS) < 3.0:
			world.get("_hud").set_prompt("Наставник Марк", "Поговорить — ДЕЙСТВИЕ (E)")
