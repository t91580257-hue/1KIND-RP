extends RefCounted
## Общая сетка расширенного Ванбурга. Все размеры в метрах.
## Центральные районы сохранены, за ними добавлены четыре больших внешних района.

const ROAD_W := 12.0
const HALF_ROAD := 6.0
const SIDEWALK_W := 3.0
const LINES: Array = [-900.0, -700.0, -500.0, -300.0, -140.0, -70.0, 0.0, 70.0, 140.0, 300.0, 500.0, 700.0, 900.0]
const EXTENT := 1000.0
const PLAZA_HALF := 20.0
const BOUNDARY := 1000.0
const SPAWN := Vector3(0.0, 1.0, 13.0)


static func zone_name(p: Vector3) -> String:
	if absf(p.x) < PLAZA_HALF and absf(p.z) < PLAZA_HALF:
		return "Центральная площадь"
	if absf(p.x) > 145.0 or absf(p.z) > 145.0:
		return "Окраина Ванбурга"
	if p.x < -70.0 and p.z < -70.0:
		return "Промышленная зона"
	if p.x > 70.0 and p.z < -70.0:
		return "Аэропорт Ванбурга"
	if p.x < -70.0 and p.z > 70.0:
		return "Стадион и парк"
	if p.x > 70.0 and p.z > 70.0:
		return "Порт и набережная"
	if p.x < -6.0 and p.z < -6.0:
		return "Гражданский квартал"
	if p.x > 6.0 and p.z < -6.0:
		return "Торговый квартал"
	if p.x < -6.0 and p.z > 6.0:
		return "Жилой район: высотки"
	if p.x > 6.0 and p.z > 6.0:
		return "Жилой район: дома"
	return "Улицы Ванбурга"
