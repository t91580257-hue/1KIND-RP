extends Node3D
## Маркер задания в мире: золотой столб света, кольцо на земле и парящая стрелка.
## kind: "job" (золото) | "race" (синий) | "danger" (красный) | "police" (синий мигающий)

var kind: String = "job"
var label_text: String = ""

var _ring: MeshInstance3D
var _pillar: MeshInstance3D
var _arrow: MeshInstance3D
var _label: Label3D
var _t: float = 0.0


func _ready() -> void:
	var main_col := Color("ffbe28")
	if kind == "race":
		main_col = Color("1e90ff")
	elif kind == "danger":
		main_col = Color("e74c3c")
	elif kind == "police":
		main_col = Color("6fb8ff")

	var mat := StandardMaterial3D.new()
	mat.albedo_color = main_col
	mat.emission_enabled = true
	mat.emission = main_col
	mat.emission_energy_multiplier = 1.1
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color.a = 0.42

	_ring = MeshInstance3D.new()
	var rm := CylinderMesh.new()
	rm.top_radius = 1.6
	rm.bottom_radius = 1.6
	rm.height = 0.06
	rm.radial_segments = 24
	_ring.mesh = rm
	_ring.material_override = mat
	_ring.position = Vector3(0, 0.08, 0)
	_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_ring)

	_pillar = MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.55
	pm.bottom_radius = 0.9
	pm.height = 9.0
	pm.radial_segments = 12
	_pillar.mesh = pm
	_pillar.material_override = mat
	_pillar.position = Vector3(0, 4.5, 0)
	_pillar.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_pillar)

	_arrow = MeshInstance3D.new()
	var am := PrismMesh.new()
	am.size = Vector3(0.7, 0.9, 0.7)
	_arrow.mesh = am
	var solid := StandardMaterial3D.new()
	solid.albedo_color = main_col
	solid.emission_enabled = true
	solid.emission = main_col
	solid.emission_energy_multiplier = 1.4
	_arrow.material_override = solid
	_arrow.position = Vector3(0, 2.6, 0)
	_arrow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_arrow)

	if label_text != "":
		_label = Label3D.new()
		_label.text = label_text
		_label.font_size = 40
		_label.pixel_size = 0.008
		_label.modulate = Color.WHITE
		_label.outline_size = 10
		_label.outline_modulate = Color(0.02, 0.05, 0.12)
		_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		_label.position = Vector3(0, 3.7, 0)
		add_child(_label)


func _process(delta: float) -> void:
	_t += delta
	if _arrow != null:
		_arrow.rotation.y = _t * 1.6
		_arrow.position.y = 2.6 + sin(_t * 2.2) * 0.25
	if _pillar != null:
		_pillar.scale.x = 1.0 + sin(_t * 2.0) * 0.07
		_pillar.scale.z = 1.0 + sin(_t * 2.0) * 0.07
