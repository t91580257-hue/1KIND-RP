extends Node3D
## Точка взаимодействия в мире: золотое кольцо на земле и парящий кристалл.
## Игрок подходит ближе radius — на HUD появляется подсказка и работает кнопка действия.

@export var action_id: String = ""
@export var title: String = ""
@export var prompt: String = "Взаимодействовать"
@export var radius: float = 2.6

var _gem: MeshInstance3D
var _t: float = 0.0


func _ready() -> void:
	add_to_group("interactable")
	_t = randf() * TAU

	var gold := StandardMaterial3D.new()
	gold.albedo_color = Color("ffbe28")
	gold.emission_enabled = true
	gold.emission = Color("ffbe28")
	gold.emission_energy_multiplier = 0.9

	var ring := MeshInstance3D.new()
	var ring_mesh := CylinderMesh.new()
	ring_mesh.top_radius = 0.85
	ring_mesh.bottom_radius = 0.85
	ring_mesh.height = 0.04
	ring_mesh.radial_segments = 24
	ring.mesh = ring_mesh
	ring.material_override = gold
	ring.position = Vector3(0, 0.09, 0)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(ring)

	var hole := MeshInstance3D.new()
	var hole_mesh := CylinderMesh.new()
	hole_mesh.top_radius = 0.7
	hole_mesh.bottom_radius = 0.7
	hole_mesh.height = 0.05
	hole_mesh.radial_segments = 24
	hole.mesh = hole_mesh
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color("0a1630")
	hole.material_override = dark
	hole.position = Vector3(0, 0.095, 0)
	hole.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(hole)

	_gem = MeshInstance3D.new()
	var gem_mesh := SphereMesh.new()
	gem_mesh.radius = 0.28
	gem_mesh.height = 0.6
	gem_mesh.radial_segments = 4
	gem_mesh.rings = 2
	_gem.mesh = gem_mesh
	var blue := StandardMaterial3D.new()
	blue.albedo_color = Color("1e90ff")
	blue.emission_enabled = true
	blue.emission = Color("1e90ff")
	blue.emission_energy_multiplier = 1.2
	_gem.material_override = blue
	_gem.position = Vector3(0, 1.3, 0)
	_gem.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_gem)


func _process(delta: float) -> void:
	_t += delta
	if _gem != null:
		_gem.rotation.y = _t * 1.8
		_gem.position.y = 1.3 + sin(_t * 2.0) * 0.12
