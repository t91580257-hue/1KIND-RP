extends RefCounted
## Строит отдельные внутренние помещения (интерьеры) процедурно. Интерьер — отдельное Node3D-поддерево,
## которое мир показывает вместо города (город скрывается и отключается), а интерьер размещается
## далеко над городом, чтобы физика и свет не пересекались.
## Возвращает словарь: {"root": Node3D, "spawn": Vector3 (локальный), "title": String}.

const Kit = preload("res://scripts/world/world_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")
const CarFactory = preload("res://scripts/world/car_factory.gd")
const Turntable = preload("res://scripts/world/turntable.gd")
const ModelScript = preload("res://scripts/player/character_model.gd")

const ORIGIN := Vector3(0.0, 400.0, 0.0)

const INTERIORS: Dictionary = {
		"dealer_econ": {"title": "Автосалон «Ванби-Авто»", "kind": "dealer", "dealer": "econ", "tint": Color(0.82, 0.9, 1.0)},
		"dealer_mid": {"title": "Автосалон «Корона-Мотор»", "kind": "dealer", "dealer": "mid", "tint": Color(0.95, 0.9, 0.8)},
		"dealer_premium": {"title": "Автосалон «Золотой Руль»", "kind": "dealer", "dealer": "premium", "tint": Color(0.18, 0.2, 0.28)},
		"shop247": {"title": "Магазин 24/7", "kind": "shop"},
		"garage": {"title": "Гараж", "kind": "garage"},
		"cloth_shop": {"title": "Салон «Мода Ванбург»", "kind": "clothes"},
		"apt_studio": {"title": "Ваша студия", "kind": "apartment", "prop": "studio", "size": Vector2(14.0, 10.0)},
		"apt_flat": {"title": "Ваша квартира", "kind": "apartment", "prop": "flat", "size": Vector2(20.0, 14.0)},
		"apt_house": {"title": "Ваш дом", "kind": "apartment", "prop": "house", "size": Vector2(24.0, 18.0)},
		"jail": {"title": "СИЗО Ванбурга", "kind": "jail"},
}


static func has_interior(id: String) -> bool:
		return INTERIORS.has(id)


static func title_of(id: String) -> String:
		return String(INTERIORS.get(id, {}).get("title", "Помещение"))


static func build(id: String) -> Dictionary:
		var def: Dictionary = INTERIORS[id]
		var root := Node3D.new()
		root.name = "Interior_" + id
		root.position = ORIGIN
		var result := {"root": root, "title": String(def["title"])}
		match String(def["kind"]):
				"dealer":
						result["spawn"] = _build_dealer(root, String(def["dealer"]), def["tint"])
				"shop":
						result["spawn"] = _build_shop(root)
				"garage":
						result["spawn"] = _build_garage(root)
				"clothes":
						result["spawn"] = _build_clothes(root)
				"apartment":
						result["spawn"] = _build_apartment(root, String(def["prop"]), def["size"])
				"jail":
						result["spawn"] = _build_jail(root)
		return result


# ------------------------------------------------------------------ общие части

## Комната: пол, потолок, 4 стены, дверь с вывеской-выходом на стене +Z. Возвращает позицию спавна.
static func _room(root: Node3D, w: float, d: float, h: float, floor_mat: Material, wall_mat: Material, title: String) -> Vector3:
		Kit.add_box(root, Vector3(0, -0.25, 0), Vector3(w, 0.5, d), floor_mat, true)
		Kit.add_box(root, Vector3(0, h + 0.25, 0), Vector3(w, 0.5, d), Kit.color_mat(Color(0.92, 0.92, 0.95), 0.9), true)
		Kit.add_box(root, Vector3(0, h * 0.5, -d * 0.5 - 0.25), Vector3(w + 1.0, h, 0.5), wall_mat, true)
		Kit.add_box(root, Vector3(0, h * 0.5, d * 0.5 + 0.25), Vector3(w + 1.0, h, 0.5), wall_mat, true)
		Kit.add_box(root, Vector3(-w * 0.5 - 0.25, h * 0.5, 0), Vector3(0.5, h, d), wall_mat, true)
		Kit.add_box(root, Vector3(w * 0.5 + 0.25, h * 0.5, 0), Vector3(0.5, h, d), wall_mat, true)
		# Дверь (визуально) и табличка «Выход».
		Kit.add_box(root, Vector3(0, 1.1, d * 0.5 - 0.05), Vector3(2.2, 2.2, 0.1), Kit.color_mat(Color(0.1, 0.18, 0.34), 0.4, 0.2), false)
		Kit.add_box(root, Vector3(0, 2.4, d * 0.5 - 0.06), Vector3(1.4, 0.3, 0.06), Kit.emissive_mat(Color(0.2, 1.0, 0.5), 1.0), false)
		Kit.add_label(root, "ВЫХОД", Vector3(0, 2.4, d * 0.5 - 0.12), 0.01, Color(0.02, 0.2, 0.08), 180.0)
		Kit.add_label(root, title, Vector3(0, h - 0.7, -d * 0.5 + 0.1), 0.018, Color("ffbe28"))
		Kit.add_interactable(root, Vector3(0, 0.0, d * 0.5 - 1.6), "exit_interior", "Выход", "Выйти на улицу", 2.2)
		# Освещение.
		var cols := int(maxf(1.0, round(w / 9.0)))
		for i in range(cols):
				var lx := -w * 0.5 + (float(i) + 0.5) * (w / float(cols))
				var light := OmniLight3D.new()
				light.position = Vector3(lx, h - 0.6, 0)
				light.omni_range = maxf(w / float(cols), d) * 0.9
				light.light_energy = 1.1
				light.light_color = Color(1.0, 0.95, 0.85)
				light.shadow_enabled = false
				root.add_child(light)
				Kit.add_box(root, Vector3(lx, h - 0.05, 0), Vector3(2.4, 0.08, 0.5), Kit.emissive_mat(Color(1, 0.97, 0.88), 1.5), false)
		return Vector3(0, 0.2, d * 0.5 - 3.4)


static func _spawn_npc(parent: Node3D, pos: Vector3, rot_y: float) -> void:
		var npc := Node3D.new()
		npc.set_script(ModelScript)
		npc.position = pos
		npc.rotation_degrees.y = rot_y
		parent.add_child(npc)
		var col := CollisionShape3D.new()
		var shape := CapsuleShape3D.new()
		shape.radius = 0.35
		shape.height = 1.8
		col.shape = shape
		col.position = Vector3(0, 0.9, 0)
		var body := StaticBody3D.new()
		body.position = pos
		body.add_child(col)
		parent.add_child(body)


# ------------------------------------------------------------------ автосалон

static func _build_dealer(root: Node3D, dealer_id: String, tint: Color) -> Vector3:
		var dealer: Dictionary = Catalogs.DEALERS[dealer_id]
		var w := 30.0
		var d := 18.0
		var h := 5.0
		var floor_mat := Kit.tri_mat("stone", 3.0, Color(0.85, 0.87, 0.92), 0.35)
		var wall_mat := Kit.tri_mat("concrete", 3.0, tint)
		var spawn := _room(root, w, d, h, floor_mat, wall_mat, String(dealer["name"]))
		# Стойка администратора и NPC-консультант.
		Kit.add_box(root, Vector3(-11.0, 0.55, 5.0), Vector3(4.0, 1.1, 1.2), Kit.tri_mat("wood", 2.0), true)
		Kit.add_box(root, Vector3(-11.0, 1.12, 5.0), Vector3(4.2, 0.08, 1.3), Kit.color_mat(Color("ffbe28"), 0.4, 0.5), false)
		_spawn_npc(root, Vector3(-11.0, 0.0, 3.6), 0.0)
		# Декор: растения и диван ожидания.
		for px in [-14.0, 14.0]:
				Kit.add_cylinder(root, Vector3(px, 0.4, 7.5), 0.35, 0.8, Kit.color_mat(Color(0.3, 0.2, 0.15)), true, 10)
				Kit.add_sphere(root, Vector3(px, 1.2, 7.5), 0.6, Kit.color_mat(Color(0.15, 0.5, 0.25), 0.9))
		Kit.add_box(root, Vector3(11.5, 0.3, 6.5), Vector3(4.0, 0.6, 1.0), Kit.color_mat(Color(0.12, 0.25, 0.5)), true)
		Kit.add_box(root, Vector3(11.5, 0.75, 6.9), Vector3(4.0, 0.6, 0.25), Kit.color_mat(Color(0.12, 0.25, 0.5)), false)
		# Выставочные автомобили на вращающихся платформах.
		var cars: Array = dealer["cars"]
		var pivots: Dictionary = {}
		for i in range(cars.size()):
				var cid := String(cars[i])
				var cdef: Dictionary = Catalogs.CARS[cid]
				var x := -10.0 + 5.0 * float(i)
				Kit.add_cylinder(root, Vector3(x, 0.08, -3.0), 2.5, 0.16, Kit.color_mat(Color(0.12, 0.14, 0.2), 0.3, 0.6), true, 24)
				var pivot := Turntable.new()
				pivot.position = Vector3(x, 0.16, -3.0)
				pivot.rotation_degrees.y = -90.0 + float(i) * 15.0
				pivot.car_id = cid
				pivot.car_color = String(cdef["colors"][0])
				root.add_child(pivot)
				var car := CarFactory.build(cid, pivot.car_color)
				car.name = "Car"
				pivot.add_child(car)
				pivots[cid] = pivot
				Kit.add_label(root, "%s\n%s" % [String(cdef["name"]), _fmt_price(int(cdef["price"]))], Vector3(x, 2.9, -3.0), 0.009, Color("ffbe28"), 0.0, 48)
				Kit.add_interactable(root, Vector3(x, 0.0, 0.6), "car:%s:%s" % [dealer_id, cid], String(cdef["name"]), "Осмотреть автомобиль", 2.4)
		root.set_meta("pivots", pivots)
		return spawn


# ------------------------------------------------------------------ магазин 24/7

static func _build_shop(root: Node3D) -> Vector3:
		var floor_mat := Kit.tri_mat("concrete", 2.0, Color(0.8, 0.82, 0.88), 0.5)
		var wall_mat := Kit.tri_mat("brick_red", 3.0, Color(0.95, 0.9, 0.85))
		var w := 16.0
		var d := 12.0
		var spawn := _room(root, w, d, 4.0, floor_mat, wall_mat, "МАГАЗИН 24/7")
		var shelf_mat := Kit.color_mat(Color(0.75, 0.75, 0.8), 0.5, 0.4)
		var prod_cols: Array = [Color(0.9, 0.3, 0.2), Color(0.2, 0.5, 0.9), Color(0.95, 0.8, 0.2), Color(0.3, 0.7, 0.4)]
		for row in range(3):
				var z := -4.0 + 2.8 * float(row)
				Kit.add_box(root, Vector3(-3.0, 0.9, z), Vector3(9.0, 1.8, 0.7), shelf_mat, true)
				for k in range(10):
						var c: Color = prod_cols[(k + row) % prod_cols.size()]
						Kit.add_box(root, Vector3(-7.0 + 0.9 * float(k), 1.2 + float(k % 2) * 0.3, z - 0.1), Vector3(0.5, 0.4, 0.3), Kit.color_mat(c, 0.6), false)
		# Холодильники у задней стены.
		for i in range(4):
				Kit.add_box(root, Vector3(-6.0 + 3.0 * float(i), 1.1, -d * 0.5 + 0.7), Vector3(2.6, 2.2, 0.9), Kit.glass_mat(), true)
		# Касса и продавец.
		Kit.add_box(root, Vector3(5.5, 0.55, 2.0), Vector3(4.0, 1.1, 1.2), Kit.tri_mat("wood", 2.0), true)
		Kit.add_box(root, Vector3(4.6, 1.25, 2.0), Vector3(0.5, 0.3, 0.4), Kit.color_mat(Color(0.1, 0.1, 0.12)), false)
		_spawn_npc(root, Vector3(5.5, 0.0, 0.5), 0.0)
		Kit.add_interactable(root, Vector3(5.5, 0.0, 3.4), "shop", "Касса", "Купить товары", 2.4)
		return spawn


# ------------------------------------------------------------------ гараж

static func _build_garage(root: Node3D) -> Vector3:
		var floor_mat := Kit.tri_mat("asphalt", 4.0, Color(0.7, 0.72, 0.78), 0.6)
		var wall_mat := Kit.tri_mat("concrete", 3.0, Color(0.7, 0.74, 0.8))
		var w := 34.0
		var d := 18.0
		var spawn := _room(root, w, d, 4.5, floor_mat, wall_mat, "ВАШ ГАРАЖ")
		var cars := GameState.owned_cars
		if cars.is_empty():
				Kit.add_label(root, "Гараж пуст. Купите автомобиль в автосалоне.", Vector3(0, 2.0, 0), 0.012, Color.WHITE, 0.0, 48)
				return spawn
		for i in range(cars.size()):
				var c: Dictionary = cars[i]
				var cid := String(c["id"])
				var col := i % 6
				var row := i / 6
				var x := -12.5 + 5.0 * float(col)
				var z := -5.0 + 5.0 * float(row)
				var pivot := Node3D.new()
				pivot.position = Vector3(x, 0.0, z)
				pivot.rotation_degrees.y = -90.0
				root.add_child(pivot)
				var car := CarFactory.build(cid, String(c["color"]))
				car.name = "Car"
				pivot.add_child(car)
				Kit.add_box(root, Vector3(x, 0.01, z), Vector3(2.8, 0.02, 5.8), Kit.emissive_mat(Color(1.0, 0.75, 0.15), 0.4), false)
				Kit.add_interactable(root, Vector3(x + 2.2, 0.0, z), "owned_car:%d" % i, String(Catalogs.CARS[cid]["name"]), "Осмотреть автомобиль", 2.2)
		return spawn


static func _fmt_price(amount: int) -> String:
		var s := str(amount)
		var out := ""
		var n := 0
		for i in range(s.length() - 1, -1, -1):
				out = s[i] + out
				n += 1
				if n % 3 == 0 and i > 0:
						out = " " + out
		return out + " ₽"


# ------------------------------------------------------------------ салон одежды

static func _build_clothes(root: Node3D) -> Vector3:
		var floor_mat := Kit.tri_mat("wood", 2.0, Color(0.85, 0.72, 0.55), 0.5)
		var wall_mat := Kit.tri_mat("brick_red", 3.0, Color(0.9, 0.85, 0.9))
		var w := 18.0
		var d := 12.0
		var spawn := _room(root, w, d, 4.2, floor_mat, wall_mat, "МОДА ВАНБУРГ")
		# Вешалки с одеждой вдоль стен.
		var cols: Array = [Color("1e5fd6"), Color("c0392b"), Color("27ae60"), Color("ffbe28"), Color("8e44ad"), Color("f2f2f2")]
		for i in range(cols.size()):
				var hx := -7.0 + 2.8 * float(i)
				Kit.add_box(root, Vector3(hx, 2.2, -4.6), Vector3(1.6, 0.08, 0.08), Kit.color_mat(Color(0.55, 0.57, 0.62), 0.4, 0.7), false)
				Kit.add_box(root, Vector3(hx, 1.7, -4.6), Vector3(0.8, 0.9, 0.12), Kit.color_mat(cols[i], 0.8), false)
		# Зеркало, касса, продавец.
		Kit.add_box(root, Vector3(-7.5, 1.5, 0), Vector3(0.1, 2.6, 1.6), Kit.color_mat(Color(0.75, 0.85, 0.95), 0.1, 0.8), false)
		Kit.add_box(root, Vector3(6.5, 0.55, 3.4), Vector3(3.2, 1.1, 1.1), Kit.tri_mat("wood", 2.0), true)
		_spawn_npc(root, Vector3(6.5, 0.0, 2.2), 0.0)
		Kit.add_interactable(root, Vector3(6.5, 0.0, 4.6), "clothes", "Касса «Моды»", "Купить одежду", 2.4)
		return spawn


# ------------------------------------------------------------------ квартиры и дом

static func _build_apartment(root: Node3D, prop_id: String, sz: Vector2) -> Vector3:
		var w := sz.x
		var d := sz.y
		var floor_mat := Kit.tri_mat("wood", 2.5, Color(0.8, 0.68, 0.52), 0.5)
		var wall_mat := Kit.tri_mat("concrete", 3.0, Color(0.94, 0.92, 0.88))
		var h := 3.4
		var spawn := _room(root, w, d, h, floor_mat, wall_mat, "ВАШ ДОМ · %s" % Catalogs.property_name(prop_id))
		# Базовая отделка: кухня и ванная в углу.
		Kit.add_box(root, Vector3(-w * 0.5 + 2.2, 0.45, -d * 0.5 + 1.6), Vector3(3.4, 0.9, 0.7), Kit.color_mat(Color(0.75, 0.77, 0.82), 0.5, 0.3), true)
		Kit.add_box(root, Vector3(-w * 0.5 + 2.2, 0.98, -d * 0.5 + 1.6), Vector3(3.0, 0.06, 0.6), Kit.color_mat(Color(0.2, 0.22, 0.28)), false)
		Kit.add_box(root, Vector3(w * 0.5 - 1.6, 0.5, -d * 0.5 + 1.6), Vector3(1.6, 1.0, 1.6), Kit.color_mat(Color(0.88, 0.9, 0.94), 0.3), true)
		# Окно с видом (декор на стене).
		Kit.add_box(root, Vector3(0, h * 0.55, -d * 0.5 + 0.16), Vector3(minf(w * 0.5, 6.0), 1.6, 0.08), Kit.glass_mat(), false)
		# Мебель игрока.
		var owned: Array = GameState.apartment_furniture(prop_id)
		var spots := {
				"sofa": Vector3(0, 0, d * 0.5 - 3.2),
				"tv": Vector3(0, 0, -d * 0.5 + 1.2),
				"table": Vector3(w * 0.25, 0, 0),
				"bed": Vector3(-w * 0.25, 0, -d * 0.5 + 2.6),
				"plant": Vector3(w * 0.5 - 1.4, 0, d * 0.5 - 1.4),
				"lamp": Vector3(-w * 0.5 + 1.4, 0, d * 0.5 - 1.4),
		}
		for item_id in owned:
				var spot := String(Catalogs.item_def(String(item_id)).get("spot", ""))
				if not spots.has(spot):
						continue
				_furniture(root, spot, spots[spot])
		if owned.is_empty():
				Kit.add_label(root, "Пока пусто. Мебель можно купить через Телефон → Дом.", Vector3(0, 2.2, 0), 0.012, Color.WHITE, 0.0, 48)
		# Точка выхода-входа для честного «ключа»: замок на двери.
		Kit.add_box(root, Vector3(1.6, 1.3, d * 0.5 - 0.02), Vector3(0.16, 0.16, 0.06), Kit.emissive_mat(Color("ffbe28"), 0.8), false)
		Kit.add_label(root, "Замок вашего ключа", Vector3(1.6, 1.7, d * 0.5 - 0.1), 0.006, Color("ffbe28"), 180.0)
		return spawn


static func _furniture(root: Node3D, spot: String, pos: Vector3) -> void:
		var wood := Kit.tri_mat("wood", 2.0, Color(0.5, 0.36, 0.24))
		match spot:
				"sofa":
						Kit.add_box(root, pos + Vector3(0, 0.35, 0), Vector3(2.4, 0.5, 0.95), Kit.color_mat(Color(0.16, 0.35, 0.6), 0.85), true)
						Kit.add_box(root, pos + Vector3(0, 0.75, -0.4), Vector3(2.4, 0.55, 0.22), Kit.color_mat(Color(0.16, 0.35, 0.6), 0.85), false)
						for ax in [-1.1, 1.1]:
								Kit.add_box(root, pos + Vector3(ax, 0.6, 0), Vector3(0.22, 0.45, 0.95), Kit.color_mat(Color(0.13, 0.29, 0.5), 0.85), false)
				"tv":
						Kit.add_box(root, pos + Vector3(0, 0.3, 0), Vector3(1.8, 0.6, 0.5), wood, true)
						Kit.add_box(root, pos + Vector3(0, 1.25, 0), Vector3(2.2, 1.2, 0.1), Kit.color_mat(Color(0.05, 0.06, 0.09), 0.3, 0.4), false)
						Kit.add_box(root, pos + Vector3(0, 1.25, -0.06), Vector3(2.05, 1.05, 0.02), Kit.emissive_mat(Color(0.15, 0.35, 0.7), 0.9), false)
				"table":
						Kit.add_box(root, pos + Vector3(0, 0.72, 0), Vector3(1.8, 0.08, 1.0), wood, true)
						for lx in [-0.8, 0.8]:
								for lz in [-0.4, 0.4]:
										Kit.add_box(root, pos + Vector3(lx, 0.36, lz), Vector3(0.08, 0.72, 0.08), wood, false)
						Kit.add_box(root, pos + Vector3(-1.2, 0.45, 0), Vector3(0.5, 0.08, 0.5), wood, true)
						Kit.add_box(root, pos + Vector3(1.2, 0.45, 0), Vector3(0.5, 0.08, 0.5), wood, true)
				"bed":
						Kit.add_box(root, pos + Vector3(0, 0.3, 0), Vector3(2.2, 0.5, 1.8), wood, true)
						Kit.add_box(root, pos + Vector3(0, 0.62, 0.1), Vector3(2.0, 0.24, 1.5), Kit.color_mat(Color(0.9, 0.92, 0.98), 0.9), false)
						Kit.add_box(root, pos + Vector3(0, 0.8, -0.75), Vector3(2.2, 0.8, 0.25), wood, false)
						Kit.add_box(root, pos + Vector3(-0.6, 0.75, -0.4), Vector3(0.7, 0.2, 0.4), Kit.color_mat(Color("ffbe28"), 0.8), false)
				"plant":
						Kit.add_cylinder(root, pos + Vector3(0, 0.3, 0), 0.32, 0.6, Kit.color_mat(Color(0.45, 0.3, 0.2)), true, 10)
						Kit.add_sphere(root, pos + Vector3(0, 1.0, 0), 0.55, Kit.color_mat(Color(0.15, 0.5, 0.25), 0.9), true, 1.15)
				"lamp":
						Kit.add_cylinder(root, pos + Vector3(0, 0.7, 0), 0.05, 1.4, Kit.color_mat(Color(0.2, 0.22, 0.26), 0.4, 0.7), true, 8)
						Kit.add_cylinder(root, pos + Vector3(0, 1.55, 0), 0.3, 0.35, Kit.emissive_mat(Color(1.0, 0.8, 0.5), 1.2), false, 10)


# ------------------------------------------------------------------ камера (тюрьма)

static func _build_jail(root: Node3D) -> Vector3:
		var floor_mat := Kit.tri_mat("concrete", 3.0, Color(0.5, 0.52, 0.55))
		var wall_mat := Kit.tri_mat("concrete", 3.0, Color(0.55, 0.58, 0.62))
		var w := 10.0
		var d := 8.0
		var h := 3.2
		# Комната без обычной двери — выход только по истечении срока/залогу.
		Kit.add_box(root, Vector3(0, -0.25, 0), Vector3(w, 0.5, d), floor_mat, true)
		Kit.add_box(root, Vector3(0, h + 0.25, 0), Vector3(w, 0.5, d), Kit.color_mat(Color(0.4, 0.42, 0.46)), true)
		Kit.add_box(root, Vector3(0, h * 0.5, -d * 0.5 - 0.25), Vector3(w + 1.0, h, 0.5), wall_mat, true)
		Kit.add_box(root, Vector3(0, h * 0.5, d * 0.5 + 0.25), Vector3(w + 1.0, h, 0.5), wall_mat, true)
		Kit.add_box(root, Vector3(-w * 0.5 - 0.25, h * 0.5, 0), Vector3(0.5, h, d), wall_mat, true)
		Kit.add_box(root, Vector3(w * 0.5 + 0.25, h * 0.5, 0), Vector3(0.5, h, d), wall_mat, true)
		# Решётка на двери (выход за неё).
		for i in range(7):
				Kit.add_box(root, Vector3(-1.8 + 0.6 * float(i), h * 0.5, d * 0.5 - 0.1), Vector3(0.08, h - 0.4, 0.08), Kit.color_mat(Color(0.2, 0.22, 0.26), 0.5, 0.7), false)
		Kit.add_label(root, "СИЗО ВАНБУРГА", Vector3(0, h - 0.6, -d * 0.5 + 0.1), 0.018, Color("ff6b6b"))
		Kit.add_label(root, "Отбывайте срок у скамьи или внесите залог", Vector3(0, 2.2, d * 0.5 - 1.2), 0.01, Color.WHITE, 180.0)
		# Скамья и койка.
		Kit.add_box(root, Vector3(-3.2, 0.45, -2.4), Vector3(2.4, 0.1, 0.6), Kit.tri_mat("wood", 1.5, Color(0.6, 0.5, 0.4)), true)
		for bx in [-4.1, -2.3]:
				Kit.add_box(root, Vector3(bx, 0.22, -2.4), Vector3(0.1, 0.44, 0.5), Kit.color_mat(Color(0.3, 0.32, 0.36)), false)
		Kit.add_box(root, Vector3(3.0, 0.35, -2.4), Vector3(2.2, 0.5, 1.1), Kit.color_mat(Color(0.6, 0.62, 0.66)), true)
		Kit.add_box(root, Vector3(3.0, 0.66, -2.4), Vector3(2.0, 0.16, 0.95), Kit.color_mat(Color(0.75, 0.78, 0.84), 0.9), false)
		var light := OmniLight3D.new()
		light.position = Vector3(0, h - 0.5, 0)
		light.omni_range = 9.0
		light.light_energy = 0.9
		light.light_color = Color(0.9, 0.92, 1.0)
		root.add_child(light)
		# Кнопка «отсидеть» и залог.
		Kit.add_interactable(root, Vector3(-3.2, 0, -1.2), "jail_serve", "Скамья", "Отбывать срок", 2.2)
		Kit.add_interactable(root, Vector3(0, 0, d * 0.5 - 1.2), "jail_bail", "Дежурный у решётки", "Залог и вопросы", 2.4)
		return Vector3(0, 0.2, 1.5)
