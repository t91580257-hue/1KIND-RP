extends RefCounted
## Точки интереса Ванбурга для работ, служб и сервисов.
## Единый источник координат: город расставляет по ним NPC и здания,
## а JobSystem строит маршруты заданий. Все координаты в метрах (мир).

const COURIER_GIVER := Vector3(24.0, 0, -5.5)            # у магазина 24/7
const MAILBOXES: Array = [
	Vector3(21.0, 0, 47.0), Vector3(35.0, 0, 49.0), Vector3(49.0, 0, 47.0),
	Vector3(-47.0, 0, 32.5), Vector3(-27.0, 0, 55.0), Vector3(-47.0, 0, 56.5),
]

const LOADER_BOXES: Array = [Vector3(-127.0, 0, -85.0), Vector3(-114.0, 0, -85.0), Vector3(-101.0, 0, -85.0), Vector3(-88.0, 0, -85.0)]
const LOADER_DROP := Vector3(36.0, 0, -7.0)              # док магазина 24/7

const BUILDER_SITE := Vector3(-20.0, 0, 58.0)
const BUILDER_STAGES: Array = [
	Vector3(-26.0, 0, 54.0), Vector3(-20.0, 0, 63.0), Vector3(-14.0, 0, 54.0),
	Vector3(-14.0, 0, 63.0), Vector3(-20.0, 0, 58.0),
]

const QUARRY_ROCKS: Array = [Vector3(-150.0, 0, -100.0), Vector3(-142.0, 0, -108.0), Vector3(-156.0, 0, -112.0), Vector3(-146.0, 0, -120.0)]
const FOREST_TREES: Array = [Vector3(-250.0, 0, 20.0), Vector3(-262.0, 0, 34.0), Vector3(-238.0, 0, 44.0), Vector3(-256.0, 0, 56.0)]
const RAW_DEPOT := Vector3(-90.0, 0, -84.0)              # приёмка сырья у склада

const FISH_SPOT := Vector3(114.0, 0, 96.0)               # причал порта
const MARKET_SELL := Vector3(26.0, 0, 11.0)              # рыночный прилавок

const FARM_PLOTS: Array = [Vector3(240.0, 0, 84.0), Vector3(256.0, 0, 84.0), Vector3(240.0, 0, 100.0), Vector3(256.0, 0, 100.0)]
const FARM_BARN := Vector3(232.0, 0, 92.0)

const TAXI_STOPS: Array = [Vector3(30.0, 0, 12.0), Vector3(-30.0, 0, -12.0), Vector3(12.0, 0, -30.0), Vector3(-12.0, 0, 30.0)]

const TRUCK_LOAD := Vector3(95.0, 0, 110.0)              # контейнеры порта
const TRUCK_POINTS: Array = [Vector3(105.0, 0, -84.0), Vector3(-105.0, 0, -80.0), Vector3(-12.0, 0, 8.0)]
const TRUCK_RETURN := Vector3(95.0, 0, 110.0)

const MECHANIC_NPC := Vector3(26.0, 0, -67.5)            # СТО «Форсаж»
const MECHANIC_CARS: Array = [Vector3(14.0, 0, -52.0), Vector3(14.0, 0, -40.0)]

const POLICE_STATION := Vector3(-27.0, 0, 20.0)
const POLICE_NPC := Vector3(-27.0, 0, 28.0)
const POLICE_CHECKPOINTS: Array = [Vector3(-45.0, 0, 30.0), Vector3(-35.0, 0, -8.0), Vector3(8.0, 0, 30.0), Vector3(30.0, 0, 8.0)]

const ARMY_BASE := Vector3(240.0, 0, -240.0)
const ARMY_NPC := Vector3(240.0, 0, -222.0)
const ARMY_CHECKPOINTS: Array = [Vector3(230.0, 0, -232.0), Vector3(250.0, 0, -232.0), Vector3(250.0, 0, -250.0), Vector3(230.0, 0, -250.0)]

const BLACK_MARKET := Vector3(86.0, 0, 83.0)             # за складом порта
const MARKET_STALL := Vector3(26.0, 0, 14.0)             # рынок у площади
const PAWNSHOP := Vector3(57.0, 0, -26.0)                # ломбард
const TUNING_SHOP := Vector3(17.0, 0, -67.5)             # СТО и тюнинг «Форсаж»
const CLOTHING_SHOP := Vector3(-18.0, 0, -40.0)
const HOSPITAL := Vector3(-26.0, 0, -24.0)
const CITY_HALL_SERVICE := Vector3(-45.0, 0, -7.5)       # приёмная мэрии (лицензии)

const BUSINESS_SPOTS: Dictionary = {
	"coffee": Vector3(30.0, 0, 10.0),
	"minimart": Vector3(-10.0, 0, 14.0),
	"carwash": Vector3(14.0, 0, -86.0),
	"rentflat": Vector3.ZERO,        # собирается через телефон
}

const GANG_FLAGS: Dictionary = {
	"port": Vector3(112.0, 0, 116.0),
	"industrial": Vector3(-118.0, 0, -88.0),
	"north": Vector3(-30.0, 0, 60.0),
}
const GANG_ZONE_RADIUS := 14.0

const RACE_FOOT_CHECKPOINTS: Array = [
	Vector3(-105.0, 0, 80.0), Vector3(-75.0, 0, 90.0), Vector3(-65.0, 0, 115.0),
	Vector3(-85.0, 0, 135.0), Vector3(-115.0, 0, 140.0), Vector3(-135.0, 0, 115.0),
]
const RACE_FOOT_START := Vector3(-105.0, 0, 132.0)
const RACE_CAR_CHECKPOINTS: Array = [
	Vector3(-70.0, 0, 140.0), Vector3(0.0, 0, 300.0), Vector3(300.0, 0, 300.0),
	Vector3(300.0, 0, 0.0), Vector3(300.0, 0, -300.0), Vector3(0.0, 0, -300.0),
	Vector3(-300.0, 0, -300.0), Vector3(-300.0, 0, 300.0),
]

const FUEL_STATIONS: Array = [
	Vector3(160.0, 0, 20.0), Vector3(-160.0, 0, -18.0), Vector3(160.0, 0, 160.0),
]

## Где гуляют пешеходы (маршруты по тротуарам).
const PED_ROUTES: Array = [
	[Vector3(9.5, 0, 14.0), Vector3(-9.5, 0, 14.0), Vector3(-9.5, 0, -14.0), Vector3(9.5, 0, -14.0)],
	[Vector3(20.0, 0, 11.0), Vector3(60.0, 0, 11.0), Vector3(60.0, 0, -11.0), Vector3(20.0, 0, -11.0)],
	[Vector3(-20.0, 0, -11.0), Vector3(-60.0, 0, -11.0), Vector3(-60.0, 0, 11.0), Vector3(-20.0, 0, 11.0)],
	[Vector3(11.0, 0, 20.0), Vector3(11.0, 0, 60.0), Vector3(-11.0, 0, 60.0), Vector3(-11.0, 0, 20.0)],
]

## Точки появления «нарушителей» для полицейской работы.
const SUSPECT_SPOTS: Array = [Vector3(40.0, 0, 10.0), Vector3(-40.0, 0, -12.0), Vector3(12.0, 0, -40.0), Vector3(-12.0, 0, 40.0), Vector3(45.0, 0, -45.0)]
