extends CharacterBody3D
## NPC-актёр города: пешеходы, полиция, гангстеры, нарушители, пассажиры такси.
## Режимы: stand (стоит), wander (гуляет по маршруту), chase (преследует цель),
## attack (преследует и бьёт), flee (убегает).
## Модель — тот же блочный персонаж, что и у игрока (переиспользует анимацию).

const ModelScript = preload("res://scripts/player/character_model.gd")

enum Mode { STAND, WANDER, CHASE, ATTACK, FLEE }

const WALK := 1.6
const RUN := 5.2
const COP_RUN := 7.6
const GRAVITY := 20.0

var mode: int = Mode.STAND
var route: Array = []              # точки патруля/прогулки
var route_i: int = 0
var target: Node3D = null          # кого преследуем/от кого бежим
var npc_name: String = ""
var shirt_color: String = "1e5fd6"
var pants_color: String = "16223f"
var skin_color: String = "f2c99a"
var hat_color: String = ""         # кепка (полиция — синяя, гангстер — цвет банды)
var attack_damage: float = 6.0
var attack_interval: float = 1.4
var catch_handler: Callable = Callable()   # вызывается, когда полиция догнала игрока

var _model: Node3D
var _phase: float = 0.0
var _wait: float = 0.0
var _attack_cd: float = 0.0
var _catch_time: float = 0.0


func _ready() -> void:
	collision_layer = 8
	collision_mask = 1
	var cs := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.32
	shape.height = 1.7
	cs.shape = shape
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)

	_model = Node3D.new()
	_model.set_script(ModelScript)
	add_child(_model)
	if _model.has_method("set_appearance"):
		var app := {"skin": skin_color, "hair": "2b1c10", "shirt": shirt_color, "pants": pants_color, "shoes": "1d1f24"}
		_model.call("set_appearance", app)
	if hat_color != "":
		_add_hat()
	if npc_name != "":
		_add_nameplate()
	_wait = randf_range(0.5, 2.5)


func _add_hat() -> void:
	var col := Color(hat_color)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.roughness = 0.7
	var visor := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.42, 0.1, 0.42)
	visor.mesh = bm
	visor.material_override = mat
	visor.position = Vector3(0, 1.92, 0)
	_model.add_child(visor)
	var peak := MeshInstance3D.new()
	var pm := BoxMesh.new()
	pm.size = Vector3(0.36, 0.04, 0.22)
	peak.mesh = pm
	peak.material_override = mat
	peak.position = Vector3(0, 1.87, -0.3)
	_model.add_child(peak)


func _add_nameplate() -> void:
	var l := Label3D.new()
	l.text = npc_name
	l.font_size = 34
	l.pixel_size = 0.006
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.modulate = Color("ffbe28")
	l.outline_size = 8
	l.outline_modulate = Color(0.02, 0.05, 0.12)
	l.position = Vector3(0, 2.25, 0)
	add_child(l)


func _physics_process(delta: float) -> void:
	var wish := Vector3.ZERO
	var speed := WALK
	match mode:
		Mode.STAND:
			_wait -= delta
			if _wait <= 0.0:
				rotation.y += randf_range(-1.2, 1.2)
				_wait = randf_range(2.0, 6.0)
		Mode.WANDER:
			if route.size() >= 2:
				var dst: Vector3 = route[route_i]
				var flat := Vector3(dst.x - global_position.x, 0, dst.z - global_position.z)
				if flat.length() < 1.2:
					route_i = (route_i + 1) % route.size()
					_wait = randf_range(1.0, 4.0)
				elif _wait <= 0.0:
					wish = flat.normalized()
					speed = WALK
			_wait -= delta
		Mode.CHASE, Mode.ATTACK:
			if target != null and is_instance_valid(target):
				var to := target.global_position - global_position
				to.y = 0.0
				var chase_mode := mode == Mode.CHASE
				if mode == Mode.ATTACK:
					chase_mode = to.length() > 1.6
				if to.length() < 90.0:
					wish = to.normalized()
					speed = COP_RUN if target is CharacterBody3D else RUN
				else:
					mode = Mode.WANDER if route.size() >= 2 else Mode.STAND
				if mode == Mode.ATTACK or to.length() < 1.9:
					_attack_cd -= delta
					if _attack_cd <= 0.0:
						_attack_cd = attack_interval
						if target.has_method("take_hit"):
							target.call("take_hit", attack_damage, self)
						if catch_handler.is_valid() and to.length() < 2.2:
							_catch_time += delta
							if _catch_time >= 1.2:
								_catch_time = 0.0
								catch_handler.call()
		Mode.FLEE:
			if target != null and is_instance_valid(target):
				var away := global_position - target.global_position
				away.y = 0.0
				wish = away.normalized()
				speed = RUN
	velocity.x = wish.x * speed
	velocity.z = wish.z * speed
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	move_and_slide()
	if wish.length() > 0.01:
		rotation.y = lerp_angle(rotation.y, atan2(-wish.x, -wish.z), 8.0 * delta)
	if _model.has_method("animate"):
		var hs := Vector2(velocity.x, velocity.z).length()
		_model.call("animate", hs, speed > 2.0 and hs > 1.9, is_on_floor(), delta)


## Напугать NPC (игрок грабит) — убегает.
func scare_from(node: Node3D) -> void:
	target = node
	mode = Mode.FLEE
	_wait = 6.0
	if route.is_empty():
		route = [global_position + Vector3(randf_range(-20, 20), 0, randf_range(-20, 20))]
		route_i = 0
