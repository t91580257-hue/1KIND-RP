extends Node
## Городские службы (узел мира): пешеходы, патрули полиции, погоня и арест,
## «нарушители» для полицейской работы, вызов скорой и эвакуатора.
## Добавляется миром (vanburg.gd). Требует ссылки на игрока.

const NpcScript = preload("res://scripts/world/npc_actor.gd")
const Points = preload("res://scripts/world/job_points.gd")

const PED_COUNT := 12
const COP_COUNT := 3
const CHASE_GIVEUP_DIST := 70.0
const ARREST_RANGE := 2.2

var world: Node3D = null
var player: Node3D = null

var _peds: Array = []
var _cops: Array = []
var _suspect: Node3D = null
var _suspect_respawn: float = 0.0
var _ambulance_pending: float = 0.0
var _chased: bool = false


func setup(world_node: Node3D, player_node: Node3D) -> void:
	world = world_node
	player = player_node
	_spawn_pedestrians()
	_spawn_cops()
	_spawn_suspect()


# ---------------------------------------------------------------- пешеходы

func _spawn_pedestrians() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(PED_COUNT):
		var route: Array = Points.PED_ROUTES[i % Points.PED_ROUTES.size()]
		var ped := NpcScript.new()
		ped.mode = NpcScript.Mode.WANDER
		ped.route = route.duplicate()
		ped.route_i = rng.randi() % route.size()
		var start: Vector3 = route[ped.route_i]
		ped.position = start + Vector3(rng.randf_range(-2, 2), 0.1, rng.randf_range(-2, 2))
		ped.shirt_color = ["1e5fd6", "c0392b", "27ae60", "f2f2f2", "8e44ad", "ffbe28"][i % 6]
		ped.pants_color = ["16223f", "2c3e50", "5a4634", "7f8c8d"][i % 4]
		ped.skin_color = GameState.SKIN_TONES[i % GameState.SKIN_TONES.size()]
		ped.name = "Ped_%d" % i
		world.add_child(ped)
		_peds.append(ped)


# ---------------------------------------------------------------- полиция

func _spawn_cops() -> void:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	for i in range(COP_COUNT):
		var cop := NpcScript.new()
		cop.mode = NpcScript.Mode.WANDER
		cop.npc_name = "Патруль"
		cop.shirt_color = "1e5fd6"
		cop.pants_color = "0a1630"
		cop.hat_color = "1e5fd6"
		cop.route = [
			Points.POLICE_CHECKPOINTS[0], Points.POLICE_CHECKPOINTS[1],
			Points.POLICE_CHECKPOINTS[2], Points.POLICE_CHECKPOINTS[3],
		]
		cop.route_i = i % cop.route.size()
		cop.position = cop.route[cop.route_i]
		cop.name = "Cop_%d" % i
		world.add_child(cop)
		_cops.append(cop)


func _spawn_suspect() -> void:
	if _suspect != null and is_instance_valid(_suspect):
		return
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	var spot: Vector3 = Points.SUSPECT_SPOTS[rng.randi() % Points.SUSPECT_SPOTS.size()]
	var s := NpcScript.new()
	s.mode = NpcScript.Mode.WANDER
	s.npc_name = "Подозрительный тип"
	s.shirt_color = "1d1f24"
	s.pants_color = "1d1f24"
	s.hat_color = "1d1f24"
	s.route = [spot + Vector3(6, 0, 4), spot + Vector3(-6, 0, -4), spot + Vector3(4, 0, -6), spot + Vector3(-4, 0, 6)]
	s.position = spot
	s.name = "Suspect"
	world.add_child(s)
	_suspect = s


## Есть ли задерживаемый нарушитель рядом с игроком (для кнопки действия).
func suspect_near(max_dist: float = 3.5) -> bool:
	if _suspect == null or not is_instance_valid(_suspect) or player == null:
		return false
	return player.global_position.distance_to(_suspect.global_position) <= max_dist


## Игрок-полицейский задерживает нарушителя рядом (вызывает мир по кнопке действия).
func try_arrest_suspect() -> Dictionary:
	if _suspect == null or not is_instance_valid(_suspect):
		return {"ok": false, "text": "Нарушителей рядом нет."}
	if player == null:
		return {"ok": false, "text": "Игрок недоступен."}
	if player.global_position.distance_to(_suspect.global_position) > 3.5:
		return {"ok": false, "text": "Подойдите ближе к нарушителю."}
	if not GameState.has_job_org_access():
		return {"ok": false, "text": "Задержания доступны только сотрудникам полиции (работа «Полицейский»)."}
	var bonus := 900 + 150 * GameState.org_rank("police")
	GameState.credit_bank(bonus, "Премия за задержание нарушителя")
	GameState.statistics["arrests"] = int(GameState.statistics.get("arrests", 0)) + 1
	GameState.add_job_skill_xp("police", 25)
	AudioManager.play_sfx("coin")
	GameState.notify("Нарушитель задержан! Премия: %s" % GameState.fmt_money(bonus))
	_suspect.queue_free()
	_suspect = null
	_suspect_respawn = Time.get_unix_time_from_system() + 60.0
	GameState.save_profile()
	return {"ok": true, "text": "Задержание оформлено."}


# ---------------------------------------------------------------- розыск и погоня

func _process(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	# Возобновление нарушителя.
	if _suspect == null and _suspect_respawn > 0.0 and Time.get_unix_time_from_system() >= _suspect_respawn:
		_suspect_respawn = 0.0
		_spawn_suspect()

	# Спад розыска со временем.
	if GameState.is_wanted():
		var now := Time.get_unix_time_from_system()
		if now >= GameState.wanted_decay_at:
			GameState.wanted = GameState.wanted - 1
			GameState.wanted_decay_at = now + 240.0
			if GameState.wanted <= 0:
				GameState.wanted = 0
				GameState.notify("Розыск снят — вы больше не в списке полиции.")

	# Погоня: копы видят разыскиваемого в радиусе 40 м.
	if GameState.is_wanted() and not GameState.is_jailed():
		_chased = true
		for cop in _cops:
			if not is_instance_valid(cop):
				continue
			var d: float = cop.global_position.distance_to(player.global_position)
			if d < 40.0:
				cop.mode = NpcScript.Mode.CHASE
				cop.target = player
				cop.catch_handler = _on_cop_catch
			elif d > CHASE_GIVEUP_DIST and cop.mode == NpcScript.Mode.CHASE:
				cop.mode = NpcScript.Mode.WANDER
				cop.target = null
	elif _chased:
		_chased = false
		for cop in _cops:
			if is_instance_valid(cop) and cop.mode == NpcScript.Mode.CHASE:
				cop.mode = NpcScript.Mode.WANDER
				cop.target = null

	# Скорая едет (таймер лечения).
	if _ambulance_pending > 0.0:
		_ambulance_pending -= delta
		if _ambulance_pending <= 0.0:
			GameState.heal_player(100.0)
			GameState.notify("Скорая прибыла: здоровье восстановлено!")
			AudioManager.play_sfx("levelup")


func _on_cop_catch() -> void:
	if not GameState.is_wanted() or GameState.is_jailed():
		return
	# Арест: тюрьма в участке (мир показывает интерьер камеры).
	var stars := GameState.wanted
	var seconds := GameState.jail_time_for_current()
	GameState.jail_serve(seconds, "Арест полицией Ванбурга")
	if world != null and world.has_method("send_to_jail"):
		world.call("send_to_jail", "Арест полицией (%d ★)" % stars)


# ---------------------------------------------------------------- экстренные вызовы

func call_ambulance() -> Dictionary:
	if GameState.health >= 99.0:
		return {"ok": false, "text": "Скорая не нужна: вы здоровы."}
	if not GameState.emergency_ready("ambulance"):
		return {"ok": false, "text": "Скорая уже вызвана."}
	if not GameState.charge(800, "Вызов скорой помощи"):
		return {"ok": false, "text": "Вызов стоит %s." % GameState.fmt_money(800)}
	GameState.emergency_cooldown("ambulance", 60.0)
	_ambulance_pending = 15.0
	GameState.notify("Скорая выехала (~15 секунд). Не отходите далеко!")
	return {"ok": true, "text": "Скорая в пути."}


## Эвакуатор: освобождает и доставляет авто в гараж (штрафстоянка).
func call_tow(uid: String) -> Dictionary:
	return GameState.car_release_impound(uid)


## Вызов такси: рабочее такси подаётся к игроку на 5 минут.
func call_taxi_car() -> Dictionary:
	if not GameState.emergency_ready("taxi"):
		return {"ok": false, "text": "Такси уже вызвано — подождите."}
	if not GameState.charge(300, "Вызов такси"):
		return {"ok": false, "text": "Вызов стоит %s." % GameState.fmt_money(300)}
	GameState.emergency_cooldown("taxi", 120.0)
	if world != null and world.has_method("spawn_taxi_near_player"):
		world.call("spawn_taxi_near_player")
	return {"ok": true, "text": "Такси подано. Сядьте и работайте по вызовам!"}
