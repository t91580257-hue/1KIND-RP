extends Node
## Синхронизация других игроков (онлайн): создаёт «призраков» — блочные персонажи
## с никнеймом, плавно интерполирует позиции из сетевых срезов (10 Гц).

const NpcScript = preload("res://scripts/world/npc_actor.gd")

var world: Node3D = null
var _ghosts: Dictionary = {}   # id -> Node3D
var _targets: Dictionary = {}  # id -> {"pos": Vector3, "yaw": float}


func setup(world_node: Node3D) -> void:
	world = world_node
	NetworkService.players_changed.connect(_rebuild)
	NetworkService.connection_state_changed.connect(_on_conn)


func _exit_tree() -> void:
	if NetworkService.players_changed.is_connected(_rebuild):
		NetworkService.players_changed.disconnect(_rebuild)


func _on_conn(_online: bool) -> void:
	for id in _ghosts:
		if is_instance_valid(_ghosts[id]):
			_ghosts[id].queue_free()
	_ghosts = {}
	_targets = {}


func _rebuild() -> void:
	var seen: Dictionary = {}
	for id in NetworkService.remote_players:
		seen[id] = true
		var data: Dictionary = NetworkService.remote_players[id]
		_targets[int(id)] = {"pos": Vector3(float(data.get("x", 0.0)), float(data.get("y", 0.0)), float(data.get("z", 0.0))), "yaw": float(data.get("yaw", 0.0))}
		if not _ghosts.has(int(id)) or not is_instance_valid(_ghosts[int(id)]):
			var g := NpcScript.new()
			g.mode = NpcScript.Mode.STAND
			g.npc_name = String(data.get("nick", "Игрок"))
			g.shirt_color = "27ae60"
			g.pants_color = "2c3e50"
			g.collision_layer = 0
			g.name = "Ghost_%d" % int(id)
			world.add_child(g)
			_ghosts[int(id)] = g
			g.global_position = _targets[int(id)]["pos"]
	for id in _ghosts.keys():
		if not seen.has(id):
			if is_instance_valid(_ghosts[id]):
				_ghosts[id].queue_free()
			_ghosts.erase(id)


func _process(delta: float) -> void:
	for id in _ghosts:
		var g: Node3D = _ghosts[id]
		if g == null or not is_instance_valid(g) or not _targets.has(id):
			continue
		var t: Dictionary = _targets[id]
		var cur: Vector3 = g.global_position
		var lerp_k := clampf(10.0 * delta, 0.0, 1.0)
		g.global_position = cur.lerp(t["pos"], lerp_k)
		g.rotation.y = lerp_angle(g.rotation.y, t["yaw"], lerp_k)
		if g.get("_model") != null and g.get("_model").has_method("animate"):
			var moved: float = cur.distance_to(t["pos"]) * 10.0
			g.get("_model").call("animate", moved, moved > 5.0, true, delta)
