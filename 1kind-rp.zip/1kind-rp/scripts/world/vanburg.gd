extends Node3D
## Игровой мир Ванбург: город, игрок, HUD, сенсорное управление, вождение,
## работы (JobSystem + JobRunner), службы города, обучение, интерьеры и пауза.
## Центральный роутер взаимодействий (perform_interaction).

const CityBuilder = preload("res://scripts/world/city_builder.gd")
const Layout = preload("res://scripts/world/city_layout.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")
const PlayerScene = preload("res://scenes/player/player.tscn")
const HudScene = preload("res://scenes/ui/hud.tscn")
const TouchScene = preload("res://scenes/ui/touch_controls.tscn")
const PauseScene = preload("res://scenes/ui/pause_menu.tscn")
const ProfileScene = preload("res://scenes/ui/profile_panel.tscn")
const CatalogScene = preload("res://scenes/ui/catalog_panel.tscn")
const SettingsScene = preload("res://scenes/ui/settings_screen.tscn")
const InteriorBuilder = preload("res://scripts/world/interiors/interior_builder.gd")
const InventoryPanel = preload("res://scripts/ui/inventory_panel.gd")
const AtmPanel = preload("res://scripts/ui/atm_panel.gd")
const CarViewPanel = preload("res://scripts/ui/car_view_panel.gd")
const PhonePanel = preload("res://scripts/ui/phone_panel.gd")
const MapPanel = preload("res://scripts/ui/map_panel.gd")
const JobHubPanel = preload("res://scripts/ui/job_hub_panel.gd")
const SellPanel = preload("res://scripts/ui/sell_panel.gd")
const TuningPanel = preload("res://scripts/ui/tuning_panel.gd")
const ServiceConfirm = preload("res://scripts/ui/service_confirm.gd")
const ChatPanel = preload("res://scripts/ui/chat_panel.gd")
const GhostSync = preload("res://scripts/world/ghost_sync.gd")
const NpcActorScript = preload("res://scripts/world/npc_actor.gd")
const CharacterCreator = preload("res://scripts/ui/character_creator.gd")
const DrivableCar = preload("res://scripts/world/drivable_car.gd")
const CityServices = preload("res://scripts/world/city_services.gd")
const JobRunner = preload("res://scripts/world/job_runner.gd")
const RaceRunner = preload("res://scripts/world/race_runner.gd")
const TutorialRunner = preload("res://scripts/world/tutorial_runner.gd")
const Points = preload("res://scripts/world/job_points.gd")
const MENU_SCENE := "res://scenes/main_menu.tscn"
const GARAGE_SPAWN := Vector3(39.0, 0.2, -50.0)

const POS_SAVE_INTERVAL := 5.0
const CAR_LEAVE_LIFETIME := 180.0

var _player = null
var _hud = null
var _touch = null
var _ui: CanvasLayer
var _sun: DirectionalLight3D
var _overlay: Control = null
var _overlay_from_pause: bool = false
var _zone_timer: float = 0.0
var _city: Node3D = null
var _interior: Node3D = null
var _interior_id: String = ""
var _return_pos: Vector3 = Vector3.ZERO
var _pos_timer: float = 0.0

# Вождение.
var _car: DrivableCar = null
var _car_leave_timer: float = 0.0

# Подсистемы мира.
var services: CityServices = null
var jobs_world: JobRunner = null
var races: RaceRunner = null
var tutorial: TutorialRunner = null

# Флаг первого входа: показать создание персонажа, если нет паспорта.
var _capture_gang: String = ""
var _capture_progress: float = 0.0
var _capture_gangsters: Array = []


func _ready() -> void:
		get_tree().set_quit_on_go_back(false)
		if not GameState.session_active:
				GameState.start_session("Тестер")

		_ui = CanvasLayer.new()
		_ui.layer = 10
		add_child(_ui)
		var loading := _make_loading()
		_ui.add_child(loading)
		await get_tree().process_frame
		await get_tree().process_frame

		_sun = CityBuilder.add_atmosphere(self)
		GameSettings.apply_light(_sun)
		GameSettings.apply_viewport(get_viewport())
		GameSettings.settings_changed.connect(_on_settings_changed)
		_city = Node3D.new()
		_city.name = "City"
		add_child(_city)
		var info := CityBuilder.build(_city)

		_player = PlayerScene.instantiate()
		add_child(_player)
		_player.global_position = _initial_spawn(info["spawn"])
		GameState.apply_appearance_to_model(_player.get_node("Model"))
		_player.focus_changed.connect(_on_focus_changed)

		_hud = HudScene.instantiate()
		_ui.add_child(_hud)
		_hud.inventory_pressed.connect(_open_inventory)
		_hud.phone_pressed.connect(_open_phone)
		_hud.map_pressed.connect(_open_map)

		_touch = TouchScene.instantiate()
		_ui.add_child(_touch)
		_player.controls = _touch
		_touch.jump_pressed.connect(_player.request_jump)
		_touch.interact_pressed.connect(_on_interact_button)
		_touch.menu_pressed.connect(_open_pause)
		_touch.exit_car_pressed.connect(_exit_car)

		# Подсистемы.
		services = CityServices.new()
		services.name = "CityServices"
		add_child(services)
		services.setup(self, _player)

		jobs_world = JobRunner.new()
		jobs_world.name = "JobRunner"
		add_child(jobs_world)
		jobs_world.setup(self, _player)
		JobSystem.player = _player

		races = RaceRunner.new()
		races.name = "RaceRunner"
		add_child(races)
		races.setup(self, _player)

		tutorial = TutorialRunner.new()
		tutorial.name = "Tutorial"
		add_child(tutorial)
		tutorial.setup(self, _player)
		tutorial.step_changed.connect(_on_tutorial_step)

		# Онлайн: призраки других игроков.
		if GameState.online_mode and NetworkService.is_online():
				var ghosts := GhostSync.new()
				ghosts.name = "GhostSync"
				add_child(ghosts)
				ghosts.setup(self)
				NetworkService.profile_synced.emit()

		loading.queue_free()
		GameState.notify("Добро пожаловать в Ванбург, %s!" % GameState.nickname)

		# Создание персонажа: паспорт и внешность ещё не заполнены.
		if String(GameState.passport.get("first", "")) == "":
				_open_creator.call_deferred()

		# Игрок отбывает срок из прошлого запуска.
		if GameState.is_jailed():
				_enter_jail_silently()


func _initial_spawn(default_pos: Vector3) -> Vector3:
		var p: Array = GameState.last_world_pos
		if p.size() == 3:
				var v := Vector3(float(p[0]), float(p[1]), float(p[2]))
				if absf(v.x) < 990.0 and absf(v.z) < 990.0 and v.y > -1.0 and v.y < 50.0:
						return v
		return default_pos


func _exit_tree() -> void:
		if GameSettings.settings_changed.is_connected(_on_settings_changed):
				GameSettings.settings_changed.disconnect(_on_settings_changed)


func _make_loading() -> Control:
		var root := Control.new()
		root.set_anchors_preset(Control.PRESET_FULL_RECT)
		var bg := ColorRect.new()
		bg.color = UiKit.COLOR_NAVY
		bg.set_anchors_preset(Control.PRESET_FULL_RECT)
		root.add_child(bg)
		# Фон экрана загрузки из ресурс-пака (сине-жёлтый стиль).
		if ResourceLoader.exists("res://assets/ui/backgrounds/loading_background.png"):
				var pic := TextureRect.new()
				pic.texture = load("res://assets/ui/backgrounds/loading_background.png")
				pic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
				pic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
				pic.set_anchors_preset(Control.PRESET_FULL_RECT)
				pic.modulate = Color(1, 1, 1, 0.92)
				root.add_child(pic)
		var center := CenterContainer.new()
		center.set_anchors_preset(Control.PRESET_FULL_RECT)
		root.add_child(center)
		var vb := VBoxContainer.new()
		center.add_child(vb)
		var icon := UiKit.make_icon("crown", 120)
		icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		vb.add_child(icon)
		vb.add_child(UiKit.make_title("Загрузка Ванбурга…", 40))
		return root


func _on_settings_changed() -> void:
		GameSettings.apply_light(_sun)
		GameSettings.apply_viewport(get_viewport())


func _on_tutorial_step(step: int, title: String, hint: String) -> void:
		_hud.set_tutorial(step, title, hint)


func _process(delta: float) -> void:
		if _player == null or _hud == null:
				return
		# Игрок в машине: персонаж следует за автомобилем.
		if _car != null and is_instance_valid(_car) and _car.driven:
				_player.global_position = _car.global_position + Vector3(-0.35, 0.4, 0)

		if _interior == null:
				_zone_timer -= delta
				if _zone_timer <= 0.0:
						_zone_timer = 0.4
						_hud.set_zone(Layout.zone_name(_player.global_position))
		_pos_timer -= delta
		if _pos_timer <= 0.0:
				_pos_timer = POS_SAVE_INTERVAL
				if _car == null:
						var gp: Vector3 = _player.global_position
						GameState.last_world_pos = [gp.x, gp.y, gp.z]
		# Таймер оставленной машины.
		if _car != null and is_instance_valid(_car) and not _car.driven:
				_car_leave_timer -= delta
				if _car_leave_timer <= 0.0:
						_despawn_car(true)
		# Выход из тюрьмы по таймеру.
		if _interior_id == "jail" and not GameState.is_jailed():
				GameState.notify("Срок отбыт. Двери открыты!")
				exit_interior()
		# Обновление HUD-розыска и тюрьмы.
		# Захват территории.
		_process_capture(delta)
		_hud.update_wanted(GameState.wanted)
		if GameState.is_jailed() and _interior_id == "jail":
				_hud.update_jail(int(ceil(GameState.jail_seconds_left())))


# ---------- Ввод ----------

func _unhandled_input(event: InputEvent) -> void:
		var key := event as InputEventKey
		if key == null or not key.pressed or key.echo:
				return
		if key.physical_keycode == KEY_E and _overlay == null:
				_on_interact_button()
		elif key.physical_keycode == KEY_I and _overlay == null:
				_open_inventory()
		elif key.physical_keycode == KEY_M and _overlay == null:
				_open_map()
		elif key.physical_keycode == KEY_T and _overlay == null:
				_open_phone()
		elif key.physical_keycode == KEY_ESCAPE:
				_toggle_pause()


func _notification(what: int) -> void:
		if what == NOTIFICATION_WM_GO_BACK_REQUEST:
				_toggle_pause()


func _toggle_pause() -> void:
		if _player == null:
				return
		if _overlay == null:
				_open_pause()
		else:
				_close_overlay()


# ---------- Взаимодействия ----------

func _on_focus_changed(target) -> void:
		if target == null:
				_hud.set_prompt("", "")
				return
		_hud.set_prompt(String(target.get("title")), "%s — кнопка «ДЕЙСТВИЕ» (E)" % String(target.get("prompt")))


func _on_interact_button() -> void:
		if _overlay != null or _player == null:
				return
		# Рыбалка: подсечка.
		if JobSystem.is_active():
				JobSystem.on_interact_pressed()
		# Диалог с наставником/диспетчером обучения.
		var mentor = _player.focus_target
		if mentor != null and is_instance_valid(mentor):
				var g: Array = mentor.get_groups()
				if g.has("tutorial_mentor"):
						AudioManager.play_sfx("click")
						tutorial.on_talk_mentor()
						return
				if g.has("tutorial_dispatcher"):
						AudioManager.play_sfx("click")
						tutorial.on_talk_dispatcher()
						return
		# Диалог диспетчера в обучении (шаг 4).
		var focus_now = _player.focus_target
		if focus_now != null and is_instance_valid(focus_now) and focus_now.get_groups().has("tutorial_dispatcher") and GameState.tutorial_active():
			AudioManager.play_sfx("click")
			tutorial.on_talk_dispatcher()
			return
		# Полицейский задерживает нарушителя рядом.
		if GameState.has_job_org_access() and services.suspect_near():
			AudioManager.play_sfx("click")
			var arr := services.try_arrest_suspect()
			GameState.notify(String(arr["text"]))
			return
		var giver = jobs_world.giver_near_player()
		if giver != null:
				AudioManager.play_sfx("click")
				_open_job_panel(String(giver.get_meta("job_id", "")))
				return
		if mentor == null or not is_instance_valid(mentor):
				if GameState.is_jailed():
						GameState.notify("Вы в камере. Отбывайте срок у скамьи или внесите залог у решётки.")
						return
				GameState.notify("Рядом нет объектов для взаимодействия.")
				return
		AudioManager.play_sfx("click")
		perform_interaction(String(mentor.get("action_id")), String(mentor.get("title")))


func perform_interaction(action_id: String, title: String) -> void:
		if action_id.begins_with("enter:"):
				enter_interior(action_id.substr(6))
				return
		if action_id.begins_with("car:"):
				var parts := action_id.split(":")
				if parts.size() == 3:
						_open_car_view(parts[2], -1)
				return
		if action_id.begins_with("owned_car:"):
				var idx := action_id.substr(10).to_int()
				if idx >= 0 and idx < GameState.owned_cars.size():
						var entry: Dictionary = GameState.owned_cars[idx]
						_open_car_view(String(entry["id"]), idx)
				return
		if action_id.begins_with("job:"):
				_open_job_panel(action_id.substr(4))
				return
		if action_id.begins_with("business:"):
				_open_business(action_id.substr(9), title)
				return
		if action_id.begins_with("gang:"):
				_open_gang(action_id.substr(5), title)
				return
		match action_id:
				"exit_interior":
						exit_interior()
				"atm":
						_open_atm()
						tutorial.on_atm_opened()
				"fountain":
						if GameState.try_spend(1, "Монета в фонтан"):
								GameState.add_xp(5)
								GameState.notify("Монета брошена в фонтан. Загадайте желание! (+5 опыта)")
								AudioManager.play_sfx("coin")
						else:
								GameState.notify("Нет мелочи: наличных не осталось.")
								AudioManager.play_sfx("error")
				"info_board":
						GameState.notify("Ванбург: площадь, торговый и гражданский кварталы, высотки, порт, аэропорт и фермы. Онлайн-режим — через главное меню.")
				"bus_stop":
						GameState.notify("%s: вызовите такси через телефон, если нужна поездка." % title)
				"shop", "property":
						_open_catalog(action_id)
				"jobs":
						_open_job_hub()
				"police_station":
						_open_police_station()
				"police_bail":
						_bail_desk()
				"hospital":
						_confirm("Больница Ванбурга", "Полное лечение и консультация врача.", GameState.HEAL_PRICE, func() -> void:
								var r := GameState.hospital_treat()
								GameState.notify(String(r["text"]))
						)
				"fuel":
						_open_fuel()
				"tuning":
						_open_tuning()
				"pawnshop":
						var sp := SellPanel.new()
						sp.mode = "pawnshop"
						sp.closed.connect(_close_overlay)
						_set_overlay(sp, false)
				"market":
						var mp := SellPanel.new()
						mp.mode = "market"
						mp.closed.connect(_close_overlay)
						_set_overlay(mp, false)
				"blackmarket":
						var bp := SellPanel.new()
						bp.mode = "blackmarket"
						bp.closed.connect(_close_overlay)
						_set_overlay(bp, false)
				"clothes":
						_open_catalog("clothes")
				"cityhall":
						_open_catalog("licenses")
				"raw_depot":
						var rp := SellPanel.new()
						rp.mode = "raw"
						rp.closed.connect(_close_overlay)
						_set_overlay(rp, false)
				"race":
						_open_race()
				"race_foot_start":
						var rf := races.start_race("foot")
						GameState.notify(String(rf["text"]))
				"race_car_start":
						if _car == null:
								GameState.notify("Кольцевая гонка — на автомобиле! Сядьте за руль.")
						else:
								var rc := races.start_race("car")
								GameState.notify(String(rc["text"]))
				"jail_serve":
						_jail_work()
				"jail_bail":
						_bail_desk()
				"enter_own_home":
						_enter_own_home()
				"car_seat":
						_enter_car()
				_:
						GameState.notify(title)


# ---------- Обучение: dispatcher group ----------

func mark_tutorial_dispatcher(node: Node3D) -> void:
		node.add_to_group("tutorial_dispatcher")


# ---------- Создание персонажа ----------

func _open_creator() -> void:
		if _overlay != null:
				_overlay.queue_free()
				_overlay = null
		var panel := CharacterCreator.new()
		panel.finished.connect(_on_creator_done)
		_set_overlay(panel, true, true)


func _on_creator_done() -> void:
		GameState.apply_appearance_to_model(_player.get_node("Model"))
		_close_overlay()


# ---------- Панели ----------

func _set_overlay(node: Control, from_pause: bool, keep_input: bool = false) -> void:
		if _overlay != null:
				_overlay.queue_free()
		_overlay = node
		_overlay_from_pause = from_pause
		_ui.add_child(node)
		get_tree().paused = true
		_touch.enabled = false
		if not keep_input:
				_player.input_enabled = false
		_hud.set_prompt("", "")
		AudioManager.play_sfx("open")


func _close_overlay() -> void:
		if _overlay != null:
				_overlay.queue_free()
				_overlay = null
		get_tree().paused = false
		_touch.enabled = true
		_player.input_enabled = true
		_player.focus_changed.emit(_player.focus_target)
		if not GameState.online_mode:
				GameState.save_profile()


func _back_to_pause() -> void:
		var menu = PauseScene.instantiate()
		menu.resume_requested.connect(_close_overlay)
		menu.profile_requested.connect(_open_profile)
		menu.chat_requested.connect(_open_chat)
		menu.settings_requested.connect(_open_settings)
		menu.exit_requested.connect(_exit_to_menu)
		_set_overlay(menu, true)


func _open_chat() -> void:
		var panel := ChatPanel.new()
		panel.closed.connect(_back_to_pause)
		_set_overlay(panel, true)


func _open_pause() -> void:
		if _overlay != null:
				return
		_back_to_pause()


func _open_profile() -> void:
		var panel = ProfileScene.instantiate()
		panel.closed.connect(_back_to_pause)
		_set_overlay(panel, true)


func _open_settings() -> void:
		var screen = SettingsScene.instantiate()
		screen.closed.connect(_back_to_pause)
		_set_overlay(screen, true)


func _open_catalog(kind: String) -> void:
		var panel = CatalogScene.instantiate()
		panel.kind = kind
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_inventory() -> void:
		if _overlay != null:
				return
		var panel := InventoryPanel.new()
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_atm() -> void:
		var panel := AtmPanel.new()
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_car_view(car_id: String, owned_index: int) -> void:
		var panel := CarViewPanel.new()
		panel.car_id = car_id
		panel.owned_index = owned_index
		if owned_index < 0 and _interior != null and _interior.has_meta("pivots"):
				var pivots: Dictionary = _interior.get_meta("pivots")
				panel.pivot = pivots.get(car_id, null)
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_phone() -> void:
		if _overlay != null:
				return
		var panel := PhonePanel.new()
		panel.closed.connect(_close_overlay)
		panel.open_map_requested.connect(_open_map)
		panel.enter_home_requested.connect(_enter_own_home)
		panel.furniture_requested.connect(_open_furniture)
		panel.call_car_requested.connect(_call_car_from_phone)
		panel.tow_requested.connect(_tow_from_phone)
		_set_overlay(panel, false)


func _open_map() -> void:
		if _overlay != null:
				return
		var panel := MapPanel.new()
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_job_panel(job_id: String) -> void:
		if job_id == "" or not Catalogs.JOBS.has(job_id):
				return
		var panel := JobHubPanel.new()
		panel.mode = "one"
		panel.job_id = job_id
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_job_hub() -> void:
		var panel := JobHubPanel.new()
		panel.mode = "hub"
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _open_business(biz_id: String, title: String) -> void:
		var b: Dictionary = Catalogs.BUSINESSES.get(biz_id, {})
		if b.is_empty():
				return
		if GameState.businesses.has(biz_id):
				var inc: Dictionary = GameState.business_income(biz_id)
				var info := "Ваша точка. Выручка: %s (максимум %s).\nНалог 6%% при выводе." % [GameState.fmt_money(int(inc["amount"])), GameState.fmt_money(int(inc["cap"]))]
				_confirm(title, info, 0, func() -> void:
						var r := GameState.collect_business(biz_id)
						GameState.notify(String(r["text"]))
				, "Собрать выручку")
		else:
				var need_license := not GameState.has_license("business")
				var extra := "\nНужна лицензия предпринимателя (мэрия)." if need_license else ""
				_confirm(title, String(b["desc"]) + extra, int(b["price"]), func() -> void:
						var r := GameState.buy_business(biz_id)
						GameState.notify(String(r["text"]))
				, "Купить бизнес")


func _open_gang(gang_id: String, title: String) -> void:
		var state := GameState.territory_state(gang_id)
		if state.is_empty():
				return
		var mine: bool = String(state["owner"]) == "player"
		var info := ""
		if mine:
				info = "Зона под вашим контролем. Дань собирается каждые 10 минут."
				_confirm(title, info, 0, func() -> void:
						var r := GameState.collect_tribute(gang_id)
						GameState.notify(String(r["text"]))
				, "Собрать дань")
		else:
				var def: Dictionary = state["def"]
				info = "Зону держит банда «%s». Захват: 20 секунд удержания под атакой бойцов. За захват дадут +2 звезды розыска!" % String(def["name"])
				_confirm(title, info, 0, func() -> void:
						if world_can_capture(gang_id):
								var r := GameState.capture_territory(gang_id)
								GameState.notify(String(r["text"]))
								, "Начать захват", true)


## Захват территории: удержание 20 с у флага; бойцы банды атакуют.
func world_can_capture(gang_id: String) -> bool:
	if _capture_gang != "":
		return false
	var state := GameState.territory_state(gang_id)
	if String(state.get("owner", "gang")) == "player":
		return false
	_capture_gang = gang_id
	_capture_progress = 0.0
	_spawn_gangsters(gang_id)
	GameState.notify("Захват начался! Продержитесь 20 секунд у флага!")
	AudioManager.play_sfx("levelup")
	return true


func _spawn_gangsters(gang_id: String) -> void:
	var flag: Vector3 = Points.GANG_FLAGS.get(gang_id, Vector3.ZERO)
	var def: Dictionary = Catalogs.GANGS.get(gang_id, {})
	for i in range(2):
		var gangster := NpcActorScript.new()
		gangster.mode = NpcActorScript.Mode.ATTACK
		gangster.target = _player
		gangster.npc_name = String(def.get("name", "Банда"))
		gangster.shirt_color = String(def.get("color", "c0392b"))
		gangster.pants_color = "1d1f24"
		gangster.attack_damage = 7.0
		gangster.attack_interval = 1.6
		gangster.position = flag + Vector3(randf_range(-6.0, 6.0), 0.2, randf_range(-6.0, 6.0))
		gangster.name = "Gangster_%s_%d" % [gang_id, i]
		add_child(gangster)
		_capture_gangsters.append(gangster)


func _process_capture(delta: float) -> void:
	if _capture_gang == "":
		return
	var flag: Vector3 = Points.GANG_FLAGS.get(_capture_gang, Vector3.ZERO)
	if _player == null or not is_instance_valid(_player) or _player.global_position.distance_to(flag) > 16.0:
		_cancel_capture("Захват сорван: вы покинули зону.")
		return
	_capture_progress += delta
	if _hud != null:
		_hud.set_capture_progress(_capture_progress / 20.0)
	if _capture_progress >= 20.0:
		var r := GameState.capture_territory(_capture_gang)
		GameState.notify(String(r["text"]))
		_finish_capture()


func _cancel_capture(text: String) -> void:
	GameState.notify(text)
	_finish_capture()


func _finish_capture() -> void:
	_capture_gang = ""
	_capture_progress = 0.0
	for gangster in _capture_gangsters:
		if is_instance_valid(gangster):
			gangster.queue_free()
	_capture_gangsters.clear()


func _open_fuel() -> void:
		if _car == null:
				_confirm("Заправка «Корона-Ойл»", "Подъезжайте на автомобиле — заправим полный бак.\nЦена: %s за литр." % GameState.fmt_money(int(Catalogs.SERVICES["fuel_per_liter"]["price"])), 0, func() -> void: pass, "Понятно")
				return
		var def: Dictionary = Catalogs.CARS.get(_car.car_id, {})
		var missing := maxf(0.0, float(def.get("tank", 40)) - _car.fuel)
		var liters := int(ceil(missing))
		var price := liters * int(Catalogs.SERVICES["fuel_per_liter"]["price"])
		if liters <= 0:
				GameState.notify("Бак уже полный!")
				return
		_confirm("Заправка «Корона-Ойл»", "%d литров до полного бака. Оплата наличными или картой." % liters, price, func() -> void:
				if GameState.charge(price, "Заправка: %d л" % liters):
						_car.fuel = float(def.get("tank", 40))
						GameState.notify("Бак заправлен: +%d л" % liters)
						AudioManager.play_sfx("coin")
				else:
						GameState.notify("Не хватает средств на заправку.")
		, "Заправить")


func _open_tuning() -> void:
		var panel := TuningPanel.new()
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


	# Панель гонок: два заезда со взносом.
func _open_race() -> void:
	if _overlay != null:
		return
	var root := Control.new()
	root.process_mode = Node.PROCESS_MODE_ALWAYS
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(720, 0)
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	vb.add_child(UiKit.make_title("Гонки Ванбурга", 36))
	var info := UiKit.make_label("Приз зависит от времени финиша. Рекорды — Телефон → Статистика. Кольцевая гонка требует автомобиля (сядьте за руль до старта).", 20, UiKit.COLOR_MUTED)
	info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	info.custom_minimum_size = Vector2(640, 0)
	vb.add_child(info)
	var foot := UiKit.make_button("Пеший забег — взнос %s (приз до %s)" % [GameState.fmt_money(int(Catalogs.SERVICES["race_entry_foot"]["price"])), GameState.fmt_money(int(Catalogs.RACES["foot"]["base_prize"]))], "gold", Vector2(660, 66), 21)
	foot.pressed.connect(func() -> void:
		_start_race_entry("foot")
		closed_race()
	)
	vb.add_child(foot)
	var car := UiKit.make_button("Кольцевая гонка — взнос %s (приз до %s)" % [GameState.fmt_money(int(Catalogs.SERVICES["race_entry_car"]["price"])), GameState.fmt_money(int(Catalogs.RACES["car"]["base_prize"]))], "blue", Vector2(660, 66), 21)
	car.pressed.connect(func() -> void:
		_start_race_entry("car")
		closed_race()
	)
	vb.add_child(car)
	var best_f := float(GameState.race_best.get("foot", 0.0))
	var best_c := float(GameState.race_best.get("car", 0.0))
	var rec := UiKit.make_label("Рекорды: забег — %s · кольцо — %s" % [("%d с" % int(best_f)) if best_f > 0.0 else "—", ("%d с" % int(best_c)) if best_c > 0.0 else "—"], 18, UiKit.COLOR_OK)
	rec.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(rec)
	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 58))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(closed_race)
	vb.add_child(close)
	_set_overlay(root, false)


func closed_race() -> void:
	_close_overlay()


func _start_race_entry(race_id: String) -> void:
	var fee := int(Catalogs.SERVICES["race_entry_foot"]["price"]) if race_id == "foot" else int(Catalogs.SERVICES["race_entry_car"]["price"])
	if race_id == "car" and (_car == null or not is_instance_valid(_car) or not _car.driven):
		GameState.notify("Кольцевая гонка — на автомобиле! Сядьте за руль и вернитесь.")
		return
	if not GameState.charge(fee, "Взнос за гонку"):
		GameState.notify("Нужен взнос %s." % GameState.fmt_money(fee))
		AudioManager.play_sfx("error")
		return
	var r := races.start_race(race_id)
	if not bool(r["ok"]):
		GameState.credit_bank(fee, "Возврат взноса")
	GameState.notify(String(r["text"]))


func _open_police_station() -> void:
		if GameState.is_wanted():
				_confirm("Дежурная часть", "Вы в розыске (%d ★)! Сдайтесь добровольно: срок меньше, залог не нужен." % GameState.wanted, 0, func() -> void:
						var seconds := GameState.jail_time_for_current() * 0.6
						GameState.jail_serve(seconds, "Явка с повинной")
						send_to_jail("Явка с повинной")
				, "Сдаться", true)
		else:
				var res := services.try_arrest_suspect()
				if not bool(res["ok"]):
						_confirm("Дежурная часть", "Работа «Полицейский» доступна у шефа полиции (см. Работа в телефоне). Нарушителей рядом нет.", 0, func() -> void: pass, "Понятно")
				else:
						GameState.notify(String(res["text"]))


func _bail_desk() -> void:
		if not GameState.is_jailed():
				_confirm("Стойка залога", "Залог работает, когда вы в камере. Срок отбывается у скамьи — жмите «Отбывать срок».", 0, func() -> void: pass, "Понятно")
				return
		var left := GameState.jail_seconds_left()
		var cost := int(ceil(left / Catalogs.JAIL_SEC_PER_STAR)) * Catalogs.BAIL_PER_STAR
		_confirm("Стойка залога", "Осталось сидеть: %d с. Залог: %s." % [int(left), GameState.fmt_money(cost)], cost, func() -> void:
				var r := GameState.jail_bail()
				GameState.notify(String(r["text"]))
		, "Внести залог")


func _jail_work() -> void:
		if not GameState.is_jailed():
				return
		# Работа за решёткой: сколачивание ящиков сокращает срок.
		GameState.jail_until = maxf(Time.get_unix_time_from_system(), GameState.jail_until - 8.0)
		GameState.add_xp(2)
		AudioManager.play_sfx("click")
		GameState.notify("Сколотили ящик: −8 с срока. Осталось: %d с." % int(ceil(GameState.jail_seconds_left())))


# ---------- Тюрьма ----------

func send_to_jail(reason: String) -> void:
		# Забрать игрока с улицы в камеру.
		_despawn_car(false)
		GameState.last_world_pos = [_player.global_position.x, _player.global_position.y, _player.global_position.z]
		GameState.save_profile()
		enter_interior("jail")
		_hud.set_zone("СИЗО Ванбурга")
		GameState.notify("%s. Срок: %d с. Отбывайте у скамьи или внесите залог." % [reason, int(ceil(GameState.jail_seconds_left()))])


func _enter_jail_silently() -> void:
		enter_interior("jail")
		GameState.notify("Вы отбываете срок: %d с осталось." % int(ceil(GameState.jail_seconds_left())))


# ---------- Недвижимость: вход в своё жильё и мебель ----------

func _enter_own_home() -> void:
		var first_owned := ""
		for p in GameState.owned_property:
				if Catalogs.PROPERTY.has(String(p)):
						first_owned = String(p)
						break
		if first_owned == "":
				GameState.notify("У вас пока нет недвижимости. Агентство «Золотой ключ» в торговом квартале.")
				return
		enter_interior(String(Catalogs.PROPERTY[first_owned]["interior"]))


func _open_furniture() -> void:
		var first_owned := ""
		for p in GameState.owned_property:
				if Catalogs.PROPERTY.has(String(p)):
						first_owned = String(p)
						break
		if first_owned == "":
				GameState.notify("Сначала купите квартиру или дом.")
				return
		var panel = CatalogScene.instantiate()
		panel.kind = "furniture"
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)
		# Каталог покупает мебель в первую Owned-квартиру (см. catalog_panel).
		panel.purchase_target_property = first_owned


# ---------- Автомобили: вызов, посадка, высадка ----------

func _call_car_from_phone() -> void:
		if _car != null and is_instance_valid(_car):
				GameState.notify("Автомобиль уже подан!")
				return
		var free_car := ""
		for c in GameState.owned_cars:
				if not bool(c.get("impound", false)):
						free_car = String(c["uid"])
						break
		if free_car == "":
				GameState.notify("Нет доступных автомобилей (проверьте штрафстоянку).")
				return
		_spawn_player_car(free_car)
		GameState.notify("Автомобиль подан к гаражу (торговый квартал). Кнопка «ДЕЙСТВИЕ» рядом с ним — сесть за руль.")


func _spawn_player_car(uid: String) -> void:
		if _car != null and is_instance_valid(_car):
				_car.queue_free()
		_car = DrivableCar.new()
		var entry: Dictionary = GameState.car_by_uid(uid)
		if entry.is_empty():
				return
		_car.car_uid = uid
		_car.car_id = String(entry["id"])
		_car.color_hex = String(entry["color"])
		_car.position = GARAGE_SPAWN + Vector3(randf_range(-2, 2), 0.2, randf_range(-2, 2))
		_car.rotation_degrees.y = 90.0
		_car.name = "PlayerCar"
		_city.add_child(_car)
		# Точка посадки.
		Kit_add_seat_marker(_car)
		_car_leave_timer = CAR_LEAVE_LIFETIME


func Kit_add_seat_marker(car: Node3D) -> void:
		pass  # Посадка выполняется кнопкой действия рядом с автомобилем (см. _car_seat_available).


func _car_seat_available() -> bool:
		if _car == null or not is_instance_valid(_car):
				return false
		return _player.global_position.distance_to(_car.global_position) < 3.6 and not _car.driven


func _enter_car() -> void:
		if not _car_seat_available():
				return
		_car.driven = true
		GameState.active_car_uid = _car.car_uid
		_car_leave_timer = 0.0
		_player.driving = true
		_player.focus_target = null
		_hud.set_prompt("", "")
		_player.visible = false
		_player.get_node("CollisionShape3D").set_deferred("disabled", true)
		_player.velocity = Vector3.ZERO
		_touch.set_drive_mode(true)
		_hud.set_drive_hud(true, String(Catalogs.CARS.get(_car.car_id, {}).get("name", "Автомобиль")))
		GameState.notify("Поехали! Газ/тормоз справа, руль слева. Кнопка «ВЫЙТИ» — покинуть автомобиль.")
		AudioManager.play_sfx("open")


func _exit_car() -> void:
		if _car == null or not is_instance_valid(_car) or not _car.driven:
				return
		_car.driven = false
		_car.steer_input = 0.0
		_car.throttle = 0.0
		_car.brake = 0.0
		_car.sync_to_profile()
		GameState.active_car_uid = ""
		_player.driving = false
		_player.visible = true
		_player.get_node("CollisionShape3D").set_deferred("disabled", false)
		var side := _car.global_transform.basis.z.normalized()
		_player.global_position = _car.global_position + side * 2.2 + Vector3(0, 0.5, 0)
		_player.velocity = Vector3.ZERO
		_touch.set_drive_mode(false)
		_hud.set_drive_hud(false, "")
		_car_leave_timer = CAR_LEAVE_LIFETIME
		if GameState.is_wanted():
				GameState.impound_car(_car.car_uid, "оставлен в розыск")
				_despawn_car(false)
		GameState.notify("Вы вышли из автомобиля. Он постоит здесь %d мин, затем вернётся в гараж." % int(CAR_LEAVE_LIFETIME / 60.0))


func _despawn_car(to_garage: bool) -> void:
		if _car == null or not is_instance_valid(_car):
				return
		if _car.driven:
				_exit_car()
		if to_garage:
				GameState.notify("Автомобиль вернулся в гараж (подайте снова через телефон).")
		_car.queue_free()
		_car = null


func spawn_taxi_near_player() -> void:
		jobs_world.spawn_taxi_car(_player.global_position)


func _tow_from_phone(uid: String) -> void:
		var r := services.call_tow(uid)
		GameState.notify(String(r["text"]))


# ---------- Интерьеры ----------

func enter_interior(id: String) -> void:
		if _interior != null or not InteriorBuilder.has_interior(id):
				return
		if id.begins_with("apt_") and not _owns_property_for_interior(id):
				GameState.notify("Это жильё вам не принадлежит.")
				return
		var door = _player.focus_target
		var door_pos: Vector3 = _player.global_position
		if door != null and is_instance_valid(door):
				door_pos = door.global_position
		_return_pos = door_pos + Vector3(0.0, 1.0, 0.0)
		GameState.last_world_pos = [_return_pos.x, _return_pos.y, _return_pos.z]
		GameState.save_profile()
		var built: Dictionary = InteriorBuilder.build(id)
		_interior = built["root"]
		_interior_id = id
		add_child(_interior)
		_city.visible = false
		_city.process_mode = Node.PROCESS_MODE_DISABLED
		_player.velocity = Vector3.ZERO
		_player.global_position = _interior.global_position + Vector3(built["spawn"])
		_player.focus_target = null
		_hud.set_prompt("", "")
		_hud.set_zone(String(built["title"]))
		AudioManager.play_sfx("open")


func _owns_property_for_interior(id: String) -> bool:
		for prop_id in Catalogs.PROPERTY:
				if String(Catalogs.PROPERTY[prop_id]["interior"]) == id:
						return GameState.owned_property.has(prop_id)
		return false


func exit_interior() -> void:
		if _interior == null:
				return
		var was_jail := _interior_id == "jail"
		_interior.queue_free()
		_interior = null
		_interior_id = ""
		_city.visible = true
		_city.process_mode = Node.PROCESS_MODE_INHERIT
		_player.velocity = Vector3.ZERO
		if was_jail:
				# Выход из камеры — к участку.
				_player.global_position = Points.POLICE_STATION + Vector3(0, 0.5, 18.0)
		else:
				_player.global_position = _return_pos
		_player.focus_target = null
		_hud.set_prompt("", "")
		_pos_timer = POS_SAVE_INTERVAL
		AudioManager.play_sfx("open")


# ---------- Подтверждение услуг ----------

func _confirm(title: String, text: String, price: int, on_ok: Callable, ok_text: String = "Подтвердить", danger: bool = false) -> void:
		var panel := ServiceConfirm.new()
		panel.setup(title, text, price, ok_text, danger)
		panel.confirmed.connect(on_ok)
		panel.closed.connect(_close_overlay)
		_set_overlay(panel, false)


func _exit_to_menu() -> void:
		_finish_capture()
		if JobSystem.is_active():
			JobSystem.cancel_session()
		if _car != null and is_instance_valid(_car):
				_despawn_car(true)
		GameState.end_session()
		get_tree().paused = false
		get_tree().change_scene_to_file(MENU_SCENE)
