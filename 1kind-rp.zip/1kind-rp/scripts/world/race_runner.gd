extends Node
## Гонки Ванбурга: пешеходный забег вокруг парка и кольцевая гонка на автомобиле.
## Чекпоинты из Points, таймер, приз за финиш (быстрее — больше), рекорд в профиле.

const MarkerScript = preload("res://scripts/world/job_marker.gd")
const Points = preload("res://scripts/world/job_points.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

signal race_state(active: bool, info: String)

var world: Node3D = null
var player: Node3D = null

var active_race: String = ""      # "" | "foot" | "car"
var checkpoints: Array = []
var cp_index: int = 0
var start_time: float = 0.0

var _marker: Node3D = null


func setup(world_node: Node3D, player_node: Node3D) -> void:
	world = world_node
	player = player_node


func is_active() -> bool:
	return active_race != ""


func start_race(race_id: String) -> Dictionary:
	if not Catalogs.RACES.has(race_id):
		return {"ok": false, "text": "Гонка не найдена."}
	if is_active():
		return {"ok": false, "text": "Сначала завершите текущий заезд."}
	if race_id == "foot" and GameState.is_wanted():
		return {"ok": false, "text": "Полиция не выпустит на забег с розыском."}
	checkpoints = (Points.RACE_FOOT_CHECKPOINTS if race_id == "foot" else Points.RACE_CAR_CHECKPOINTS).duplicate()
	checkpoints.append(Points.RACE_FOOT_START)   # финиш у организатора
	cp_index = 0
	active_race = race_id
	start_time = Time.get_unix_time_from_system()
	_show_next_marker()
	race_state.emit(true, "Старт: %s!" % String(Catalogs.RACES[race_id]["name"]))
	AudioManager.play_sfx("levelup")
	return {"ok": true, "text": "На старт! Следуйте маркерам."}


func cancel_race() -> void:
	if active_race == "":
		return
	active_race = ""
	_clear_marker()
	race_state.emit(false, "Заезд прерван.")


func _show_next_marker() -> void:
	_clear_marker()
	if cp_index >= checkpoints.size():
		return
	_marker = MarkerScript.new()
	_marker.kind = "race"
	_marker.label_text = "Чекпоинт %d/%d" % [cp_index + 1, checkpoints.size()]
	_marker.position = checkpoints[cp_index]
	world.add_child(_marker)


func _clear_marker() -> void:
	if _marker != null and is_instance_valid(_marker):
		_marker.queue_free()
	_marker = null


func _process(_delta: float) -> void:
	if not is_active() or player == null or not is_instance_valid(player):
		return
	var target: Vector3 = checkpoints[cp_index]
	var d := Vector2(player.global_position.x - target.x, player.global_position.z - target.z).length()
	if d < 6.0:
		cp_index += 1
		AudioManager.play_sfx("click")
		if cp_index >= checkpoints.size():
			_finish()
		else:
			_show_next_marker()
			race_state.emit(true, "Чекпоинт %d/%d" % [cp_index, checkpoints.size()])


func _finish() -> void:
	var race_id := active_race
	var def: Dictionary = Catalogs.RACES[race_id]
	var t := Time.get_unix_time_from_system() - start_time
	var prize := maxi(500, int(def["base_prize"]) - int(t * float(def["prize_per_sec"])))
	GameState.credit_bank(prize, "Гонка «%s» — приз" % String(def["name"]))
	GameState.add_xp(60)
	var best := float(GameState.race_best.get(race_id, 0.0))
	var record_text := ""
	if best <= 0.0 or t < best:
		GameState.race_best[race_id] = t
		record_text = " Новый рекорд!"
		GameState.statistics["races_won"] = int(GameState.statistics.get("races_won", 0)) + 1
	GameState.save_profile()
	active_race = ""
	_clear_marker()
	AudioManager.play_sfx("coin")
	race_state.emit(false, "")
	GameState.notify("Финиш: %d с. Приз: %s.%s" % [int(t), GameState.fmt_money(prize), record_text])
