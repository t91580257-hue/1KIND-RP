extends Node
## JobRunner (узел мира): рисует маркер текущей задачи, расставляет NPC приёма
## по точкам работ, пассажиров такси для работы таксистом и следит за завершением задач.
## Живёт в мире (vanburg.gd), подписан на сигналы JobSystem.

const MarkerScript = preload("res://scripts/world/job_marker.gd")
const NpcScript = preload("res://scripts/world/npc_actor.gd")
const Points = preload("res://scripts/world/job_points.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")
const CarFactory = preload("res://scripts/world/car_factory.gd")

var world: Node3D = null
var player: Node3D = null

var _marker: Node3D = null
var _passenger: Node3D = null
var _giver_npcs: Array = []


func setup(world_node: Node3D, player_node: Node3D) -> void:
	world = world_node
	player = player_node
	_spawn_giver_npcs()
	JobSystem.session_started.connect(_on_session)
	JobSystem.task_changed.connect(_on_task_changed)
	JobSystem.session_finished.connect(_on_finished)
	JobSystem.session_cancelled.connect(func(_t: String) -> void: _clear_marker())
	JobSystem.fish_bite.connect(_on_fish_bite)


# ---------------------------------------------------------------- NPC работ

func _spawn_giver_npcs() -> void:
	var spots: Array = [
		{"pos": Points.COURIER_GIVER, "job": "courier", "name": "Диспетчер почты", "shirt": "ffbe28", "hat": "ffbe28"},
		{"pos": Points.LOADER_BOXES[1] + Vector3(0, 0, 3.0), "job": "loader", "name": "Старший склада", "shirt": "8a8f98", "hat": ""},
		{"pos": Points.BUILDER_SITE + Vector3(4.0, 0, -2.0), "job": "builder", "name": "Прораб", "shirt": "ff8c00", "hat": "ff8c00"},
		{"pos": Points.TAXI_STOPS[0] + Vector3(2.5, 0, 1.5), "job": "taxi", "name": "Диспетчер такси", "shirt": "ffbe28", "hat": ""},
		{"pos": Points.TRUCK_LOAD + Vector3(3.0, 0, -2.5), "job": "trucker", "name": "Логист порта", "shirt": "1e5fd6", "hat": ""},
		{"pos": Points.MECHANIC_NPC + Vector3(0, 0, -1.5), "job": "mechanic", "name": "Мастер СТО", "shirt": "1d1f24", "hat": ""},
		{"pos": Points.POLICE_NPC, "job": "police", "name": "Шеф полиции", "shirt": "1e5fd6", "hat": "1e5fd6"},
		{"pos": Points.ARMY_NPC, "job": "army", "name": "Командир части", "shirt": "2f4f2f", "hat": "2f4f2f"},
		{"pos": Points.FISH_SPOT + Vector3(3.0, 0, 0), "job": "fisher", "name": "Старый рыбак", "shirt": "5a7d3c", "hat": ""},
		{"pos": Points.RAW_DEPOT + Vector3(-3.5, 0, 0), "job": "miner", "name": "Мастер карьера", "shirt": "8a8f98", "hat": "ff8c00"},
	]
	for s in spots:
		var npc := NpcScript.new()
		npc.mode = NpcScript.Mode.STAND
		npc.npc_name = String(s["name"])
		npc.shirt_color = String(s["shirt"])
		npc.hat_color = String(s["hat"])
		npc.position = s["pos"]
		npc.rotation_degrees.y = _yaw_toward(s["pos"], Vector3.ZERO) if not bool(s["pos"].is_equal_approx(Vector3.ZERO)) else 0.0
		npc.name = "JobNPC_%s" % String(s["job"])
		npc.add_to_group("job_giver")
		npc.set_meta("job_id", String(s["job"]))
		if String(s["job"]) == "courier":
			npc.add_to_group("tutorial_dispatcher")
		world.add_child(npc)
		_giver_npcs.append(npc)


func _yaw_toward(origin: Vector3, target: Vector3) -> float:
	var d := target - origin
	return rad_to_deg(atan2(d.x, d.z))


## NPC приёма рядом с игроком (для взаимодействия через кнопку действия).
func giver_near_player(max_dist: float = 3.0) -> Node3D:
	if player == null:
		return null
	var best: Node3D = null
	var best_d := max_dist
	for n in get_tree().get_nodes_in_group("job_giver"):
		var node := n as Node3D
		if node == null or not is_instance_valid(node):
			continue
		var d: float = node.global_position.distance_to(player.global_position)
		if d < best_d:
			best_d = d
			best = node
	return best


# ---------------------------------------------------------------- маркер задачи

func _on_session(job_id: String) -> void:
	_on_task_changed()
	GameState.notify("Смена началась: %s. Следуйте маркеру." % Catalogs.job_name(job_id))


func _on_task_changed() -> void:
	_clear_marker()
	_clear_passenger()
	if not JobSystem.is_active():
		return
	var t := JobSystem.current_task()
	if t.is_empty() or not t.has("pos"):
		return
	var kind := "job"
	if String(t.get("type", "")) == "fish":
		kind = "race"
	_marker = MarkerScript.new()
	_marker.kind = kind
	_marker.label_text = String(t.get("label", ""))
	_marker.position = t["pos"]
	world.add_child(_marker)
	_spawn_task_props(t)


## Пассажир такси и ящик грузчика появляются на текущей задаче.
func _spawn_task_props(t: Dictionary) -> void:
	var label := String(t.get("label", ""))
	if label.begins_with("Подберите пассажира"):
		_passenger = NpcScript.new()
		_passenger.mode = NpcScript.Mode.STAND
		_passenger.npc_name = "Пассажир"
		_passenger.shirt_color = ["c0392b", "27ae60", "8e44ad", "f2f2f2"][randi() % 4]
		_passenger.position = t["pos"] + Vector3(1.6, 0, 0.8)
		_passenger.name = "TaxiPassenger"
		world.add_child(_passenger)
	elif label.begins_with("Возьмите коробку"):
		var box := Node3D.new()
		box.name = "LoaderBox"
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(0.7, 0.7, 0.7)
		mi.mesh = bm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.78, 0.6, 0.35)
		mat.roughness = 0.9
		mi.material_override = mat
		mi.position = Vector3(0, 0.35, 0)
		box.add_child(mi)
		box.position = t["pos"] + Vector3(0, 0.1, 0)
		world.add_child(box)


func _clear_marker() -> void:
	if _marker != null and is_instance_valid(_marker):
		_marker.queue_free()
	_marker = null


func _clear_passenger() -> void:
	if _passenger != null and is_instance_valid(_passenger):
		_passenger.queue_free()
	_passenger = null


func _on_finished(text: String) -> void:
	_clear_marker()
	_clear_passenger()
	GameState.notify(text)


func _on_fish_bite(active: bool) -> void:
	if _marker == null or not is_instance_valid(_marker):
		return
	# При поклёвке маркер меняет подпись — игрок должен успеть нажать «Действие».
	if active:
		_marker.label_text = "ПОКЛЁВКА! Жмите ДЕЙСТВИЕ!"
		if _marker.has_method("queue_free"):
			var pos: Vector3 = _marker.position
			var kind := "race"
			_marker.queue_free()
			_marker = MarkerScript.new()
			_marker.kind = kind
			_marker.label_text = "ПОКЛЁВКА! Жмите ДЕЙСТВИЕ!"
			_marker.position = pos
			world.add_child(_marker)
	else:
		_on_task_changed()


# ---------------------------------------------------------------- вызов такси

func spawn_taxi_car(near: Vector3) -> void:
	# Временное такси для вызова через телефон: живёт 5 минут.
	var taxi := Node3D.new()
	taxi.name = "CalledTaxi"
	var visual := CarFactory.build("taxi_sedan", "ffbe28")
	visual.name = "Visual"
	taxi.add_child(visual)
	taxi.position = near + Vector3(6.0, 0.2, 2.0)
	taxi.rotation_degrees.y = -90.0
	world.add_child(taxi)
	var timer := world.get_tree().create_timer(300.0)
	timer.timeout.connect(func() -> void:
		if is_instance_valid(taxi):
			taxi.queue_free()
	)


func _process(_delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	var world_node := get_tree().current_scene
	if world_node == null or world_node.get("_hud") == null:
		return
	var giver = giver_near_player()
	if giver != null:
		var job_id := String(giver.get_meta("job_id", ""))
		world_node.get("_hud").set_prompt(Catalogs.job_name(job_id), "Устроиться на работу — ДЕЙСТВИЕ (E)")
