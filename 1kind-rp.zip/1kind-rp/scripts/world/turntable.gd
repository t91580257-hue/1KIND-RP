extends Node3D
## Вращающаяся платформа для выставочного автомобиля. Вращение можно останавливать (осмотр вручную).

@export var spin_speed: float = 0.35
var spin: bool = true
var car_id: String = ""
var car_color: String = ""


func _process(delta: float) -> void:
	if spin:
		rotation.y += spin_speed * delta
