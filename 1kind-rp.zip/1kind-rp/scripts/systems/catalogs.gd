extends RefCounted
## Каталоги игровых данных: товары, автомобили, недвижимость, работы, бизнесы, услуги.
## Все данные описаны в одном месте, чтобы позже их можно было заменить
## данными с сервера (Nakama storage) без переписывания интерфейса.

## kind: food | drink | misc | key | quest | case | resource | illegal | furniture | clothes | tool
const ITEMS: Dictionary = {
	"water": {"name": "Бутылка воды", "desc": "Утоляет жажду.", "price": 60, "icon": "health", "kind": "drink", "weight": 0.5, "stack": 10, "thirst": 35.0},
	"cola": {"name": "Лимонад", "desc": "Холодный газированный напиток.", "price": 90, "icon": "shop", "kind": "drink", "weight": 0.5, "stack": 10, "thirst": 25.0, "hunger": 3.0},
	"sandwich": {"name": "Сэндвич", "desc": "Сытный перекус.", "price": 150, "icon": "shop", "kind": "food", "weight": 0.3, "stack": 10, "hunger": 30.0},
	"burger": {"name": "Бургер", "desc": "Горячий бургер из кафе.", "price": 290, "icon": "shop", "kind": "food", "weight": 0.4, "stack": 10, "hunger": 45.0, "thirst": -5.0},
	"medkit": {"name": "Аптечка", "desc": "Восстанавливает 40 здоровья.", "price": 900, "icon": "health", "kind": "misc", "weight": 0.8, "stack": 5, "heal": 40.0},
	"phone_case": {"name": "Чехол для телефона", "desc": "Сине-золотой, с короной.", "price": 450, "icon": "phone", "kind": "misc", "weight": 0.1, "stack": 5},
	"map_vanburg": {"name": "Карта Ванбурга", "desc": "Бумажная карта города.", "price": 250, "icon": "map", "kind": "misc", "weight": 0.1, "stack": 1},
	"gold_badge": {"name": "Золотой значок", "desc": "Знак отличия жителя Ванбурга.", "price": 3000, "icon": "star", "kind": "misc", "weight": 0.1, "stack": 1},
	"case_basic": {"name": "Обычный кейс", "desc": "Откройте: случайная награда в ₽ или предметы.", "price": 1500, "icon": "premium", "kind": "case", "weight": 1.0, "stack": 20},
	"case_starter": {"name": "Кейс новичка", "desc": "Награда за обучение. Внутри — деньги или предметы.", "price": 0, "icon": "premium", "kind": "case", "weight": 1.0, "stack": 1},
	# Ресурсы (добываются работами, продаются на рынке/приёмке).
	"package": {"name": "Посылка", "desc": "Заказ курьера. Доставьте по адресу.", "price": 0, "icon": "shop", "kind": "quest", "weight": 1.2, "stack": 5},
	"stone": {"name": "Камень", "desc": "Добыт в карьере. Примите на складе сырья.", "price": 0, "icon": "shield", "kind": "resource", "weight": 4.0, "stack": 20},
	"ore": {"name": "Руда", "desc": "Ценная находка шахтёра.", "price": 0, "icon": "shield", "kind": "resource", "weight": 3.0, "stack": 20},
	"wood": {"name": "Бревно", "desc": "Свежесрубленное дерево.", "price": 0, "icon": "shop", "kind": "resource", "weight": 5.0, "stack": 20},
	"fish": {"name": "Речная рыба", "desc": "Улов рыбака.", "price": 0, "icon": "star", "kind": "resource", "weight": 1.0, "stack": 20},
	"fish_big": {"name": "Сом-рекордсмен", "desc": "Редкий улов. Дорого стоит на рынке.", "price": 0, "icon": "trophy", "kind": "resource", "weight": 3.0, "stack": 5},
	"vegetables": {"name": "Овощи", "desc": "Свежий урожай с фермы.", "price": 0, "icon": "health", "kind": "resource", "weight": 1.5, "stack": 20, "hunger": 12.0, "thirst": 4.0},
	# Инструменты и материалы.
	"rod": {"name": "Спиннинг", "desc": "Нужен для рыбалки. Купить можно на рынке.", "price": 2500, "icon": "jobs", "kind": "tool", "weight": 1.5, "stack": 1},
	"seed_pack": {"name": "Семена", "desc": "Пакет семян для фермы.", "price": 100, "icon": "jobs", "kind": "tool", "weight": 0.2, "stack": 20},
	"toolbox": {"name": "Ящик инструментов", "desc": "Набор механика. Нужен для подработки в сервисе.", "price": 3500, "icon": "jobs", "kind": "tool", "weight": 3.0, "stack": 1},
	# Нелегальные товары (чёрный рынок).
	"stolen_phone": {"name": "«Левый» телефон", "desc": "Без документов. Дорогое приобретение с риском.", "price": 0, "icon": "phone", "kind": "illegal", "weight": 0.3, "stack": 5},
	"fireworks": {"name": "Фейерверк", "desc": "Салют во дворе. Полиция не одобряет.", "price": 0, "icon": "premium", "kind": "illegal", "weight": 0.8, "stack": 10},
	# Мебель для квартиры.
	"fur_sofa": {"name": "Диван «Навигатор»", "desc": "Мягкий диван в гостиную.", "price": 18000, "icon": "home", "kind": "furniture", "weight": 30.0, "stack": 1, "spot": "sofa"},
	"fur_tv": {"name": "ТВ-панель «Корона 55»", "desc": "Телевизор с золотой рамкой.", "price": 45000, "icon": "home", "kind": "furniture", "weight": 12.0, "stack": 1, "spot": "tv"},
	"fur_table": {"name": "Обеденный стол", "desc": "Стол и два стула.", "price": 14000, "icon": "home", "kind": "furniture", "weight": 22.0, "stack": 1, "spot": "table"},
	"fur_bed": {"name": "Кровать «Сон-Король»", "desc": "Спать на ней — сплошное удовольствие.", "price": 26000, "icon": "home", "kind": "furniture", "weight": 35.0, "stack": 1, "spot": "bed"},
	"fur_plant": {"name": "Фикус в кадке", "desc": "Живая зелень в интерьере.", "price": 3500, "icon": "home", "kind": "furniture", "weight": 6.0, "stack": 1, "spot": "plant"},
	"fur_lamp": {"name": "Торшер «Закат»", "desc": "Тёплый свет для вечера.", "price": 6000, "icon": "home", "kind": "furniture", "weight": 5.0, "stack": 1, "spot": "lamp"},
}

## Предметы, которые нельзя купить в магазине 24/7 (кейсы выдаются заданиями, ключи — покупкой).
const SHOP_ITEMS: Array = ["water", "cola", "sandwich", "burger", "medkit", "phone_case", "map_vanburg", "gold_badge", "case_basic", "seed_pack", "rod", "toolbox"]

## Что можно сдать в ломбард (процент от цены задаётGameState по рыночному фактору).
const SELLABLE: Array = ["gold_badge", "phone_case", "map_vanburg", "case_basic", "medkit", "fireworks", "stolen_phone",
	"stone", "ore", "wood", "fish", "fish_big", "vegetables", "fur_sofa", "fur_tv", "fur_table", "fur_bed", "fur_plant", "fur_lamp"]

## Базовая доля цены при продаже в ломбарде (рынок «гуляет» вокруг неё).
const SELL_FACTOR := 0.62

## Автосалоны: id -> название и список автомобилей (по 5 в каждом).
const DEALERS: Dictionary = {
	"econ": {"name": "Автосалон «Ванби-Авто» (эконом)", "cars": ["vanbi", "step", "kombi", "tropa", "master"]},
	"mid": {"name": "Автосалон «Корона-Мотор» (средний класс)", "cars": ["korona_s", "putnik", "gorets", "strela", "briz"]},
	"premium": {"name": "Автосалон «Золотой Руль» (премиум)", "cars": ["regent", "titan", "strela_gt", "faeton", "molniya"]},
}

## shape — тип процедурной 3D-модели (см. car_factory.gd). Скорость в км/ч, разгон 0-100 в секундах,
## handling 1..10, fuel — л/100 км, tank — объём бака в литрах.
const CARS: Dictionary = {
	"vanbi": {"name": "«Ванби» городской хэтчбек", "desc": "Компактный и экономичный.", "price": 450000, "icon": "car", "shape": "hatch", "dealer": "econ", "top_speed": 150, "accel": 14.5, "handling": 6, "fuel": 5.8, "tank": 40, "colors": ["d94b3f", "f2f2f2", "2f6fd6", "f0b429"]},
	"step": {"name": "«Степь» седан", "desc": "Простой надёжный седан.", "price": 620000, "icon": "car", "shape": "sedan", "dealer": "econ", "top_speed": 170, "accel": 12.8, "handling": 5, "fuel": 7.2, "tank": 50, "colors": ["8a8f98", "1d1f24", "f2f2f2", "5a7d3c"]},
	"kombi": {"name": "«Комби» компактвэн", "desc": "Просторный семейный фургон.", "price": 780000, "icon": "car", "shape": "van", "dealer": "econ", "top_speed": 160, "accel": 14.0, "handling": 4, "fuel": 8.4, "tank": 55, "colors": ["f2f2f2", "3a6ea5", "c9a227", "7b4a9e"]},
	"tropa": {"name": "«Тропа» кроссовер", "desc": "Городской кроссовер.", "price": 890000, "icon": "car", "shape": "crossover", "dealer": "econ", "top_speed": 175, "accel": 11.8, "handling": 5, "fuel": 8.1, "tank": 55, "colors": ["b5651d", "1d1f24", "e8e8e8", "2b7a6f"]},
	"master": {"name": "«Мастер» пикап", "desc": "Рабочая лошадка с кузовом.", "price": 950000, "icon": "car", "shape": "pickup", "dealer": "econ", "top_speed": 165, "accel": 12.5, "handling": 4, "fuel": 10.2, "tank": 70, "colors": ["c0392b", "34495e", "f2f2f2", "27ae60"]},

	"korona_s": {"name": "«Корона S» седан", "desc": "Комфортный седан бизнес-класса.", "price": 2100000, "icon": "car", "shape": "sedan", "dealer": "mid", "top_speed": 210, "accel": 8.4, "handling": 7, "fuel": 8.0, "tank": 62, "colors": ["0a1630", "c0c4cc", "ffbe28", "7a1f2b"]},
	"putnik": {"name": "«Путник» универсал", "desc": "Вместительный универсал.", "price": 2400000, "icon": "car", "shape": "wagon", "dealer": "mid", "top_speed": 205, "accel": 8.9, "handling": 7, "fuel": 8.6, "tank": 65, "colors": ["2e4a62", "d8d8d8", "3d3d3d", "6b8e23"]},
	"gorets": {"name": "«Горец» внедорожник", "desc": "Полноприводный внедорожник.", "price": 3100000, "icon": "car", "shape": "suv", "dealer": "mid", "top_speed": 195, "accel": 9.2, "handling": 6, "fuel": 11.5, "tank": 80, "colors": ["2f3b2a", "1d1f24", "e0e0e0", "8b5a2b"]},
	"strela": {"name": "«Стрела» купе", "desc": "Динамичное спортивное купе.", "price": 3600000, "icon": "car", "shape": "coupe", "dealer": "mid", "top_speed": 240, "accel": 6.4, "handling": 8, "fuel": 10.4, "tank": 58, "colors": ["d62828", "1e90ff", "111111", "f77f00"]},
	"briz": {"name": "«Бриз» кабриолет", "desc": "Открытый кабриолет для прогулок.", "price": 4200000, "icon": "car", "shape": "cabrio", "dealer": "mid", "top_speed": 225, "accel": 7.2, "handling": 8, "fuel": 9.6, "tank": 56, "colors": ["f2d0a4", "00a6a6", "e63946", "f1faee"]},

	"regent": {"name": "«Регент» представительский седан", "desc": "Флагманский седан с салоном люкс.", "price": 9000000, "icon": "car", "shape": "limo", "dealer": "premium", "top_speed": 250, "accel": 5.6, "handling": 8, "fuel": 11.8, "tank": 78, "colors": ["0b0b0f", "f4f4f4", "1c2541", "4a4e57"]},
	"titan": {"name": "«Титан» премиум-внедорожник", "desc": "Мощный и роскошный.", "price": 12000000, "icon": "car", "shape": "bigsuv", "dealer": "premium", "top_speed": 245, "accel": 5.4, "handling": 7, "fuel": 14.5, "tank": 95, "colors": ["111111", "ececec", "3b3f46", "5c1a1b"]},
	"strela_gt": {"name": "«Золотая стрела GT» гран-туризмо", "desc": "Гранд-турер с V8.", "price": 15000000, "icon": "car", "shape": "gt", "dealer": "premium", "top_speed": 295, "accel": 4.1, "handling": 9, "fuel": 13.2, "tank": 70, "colors": ["ffbe28", "0a1630", "d9d9d9", "8d0801"]},
	"faeton": {"name": "«Фаэтон» родстер", "desc": "Лёгкий двухместный родстер.", "price": 19000000, "icon": "car", "shape": "roadster", "dealer": "premium", "top_speed": 305, "accel": 3.8, "handling": 10, "fuel": 12.6, "tank": 60, "colors": ["1e90ff", "f2f2f2", "e63946", "2a9d8f"]},
	"molniya": {"name": "«Молния» суперкар", "desc": "Топовый суперкар с низким силуэтом.", "price": 35000000, "icon": "car", "shape": "super", "dealer": "premium", "top_speed": 350, "accel": 2.7, "handling": 10, "fuel": 16.0, "tank": 75, "colors": ["f4d03f", "e74c3c", "111111", "7d3cff"]},
	"cab_van": {"name": "«Голубь» рабочая газель", "desc": "Служебный фургон. Для дальнобойщиков.", "price": 1300000, "icon": "car", "shape": "van", "dealer": "econ", "service": true, "top_speed": 140, "accel": 16.0, "handling": 4, "fuel": 9.5, "tank": 80, "colors": ["1e90ff", "f2f2f2", "c0c4cc", "6b8e23"]},
	"taxi_sedan": {"name": "«Кэб» таксомотор", "desc": "Жёлтый седан с шашечками.", "price": 700000, "icon": "car", "shape": "sedan", "dealer": "econ", "service": true, "top_speed": 175, "accel": 12.0, "handling": 6, "fuel": 7.5, "tank": 55, "colors": ["ffbe28", "f2f2f2", "1d1f24", "2b7a6f"]},
}

## Недвижимость. prop: kind жилое (interior) или бизнес.
const PROPERTY: Dictionary = {
	"studio": {"name": "Студия на Площади", "desc": "Уютная студия рядом с фонтаном.", "price": 3500000, "icon": "home", "interior": "apt_studio"},
	"flat": {"name": "Квартира в высотке", "desc": "Двухкомнатная квартира с видом на город.", "price": 7000000, "icon": "home", "interior": "apt_flat"},
	"house": {"name": "Дом в жилом районе", "desc": "Собственный дом с гаражом.", "price": 15000000, "icon": "home", "interior": "apt_house"},
}

## Бизнесы: доход в ₽ за минуту, копится до cap_minutes часов игрового времени.
const BUSINESSES: Dictionary = {
	"coffee": {"name": "Кофейня «Корона-Кофе»", "desc": "Кофе на площади — золотая жила.", "price": 850000, "icon": "shop", "income": 210, "cap_min": 180, "tax": 0.06},
	"minimart": {"name": "Мини-маркет «У Фонтана»", "desc": "Торговая точка с высоким трафиком.", "price": 1600000, "icon": "shop", "income": 420, "cap_min": 180, "tax": 0.06},
	"carwash": {"name": "Автомойка «Блеск»", "desc": "Мойка у торгового квартала.", "price": 2900000, "icon": "car", "income": 760, "cap_min": 180, "tax": 0.06},
	"rentflat": {"name": "Сдача квартиры внаём", "desc": "Пассивный доход от аренды.", "price": 4600000, "icon": "home", "income": 1150, "cap_min": 240, "tax": 0.06},
}

## Лицензии мэрии.
const LICENSES: Dictionary = {
	"business": {"name": "Лицензия предпринимателя", "desc": "Право владеть бизнесами в Ванбурге.", "price": 50000, "icon": "crown"},
	"taxi": {"name": "Таксо-лицензия", "desc": "Право работать в такси (смена у диспетчера).", "price": 12000, "icon": "car"},
	"weapon": {"name": "Охотничий билет", "desc": "Разрешение на работу с инструментом повышенного риска.", "price": 8000, "icon": "shield"},
}

## Профессии. npc — точка мира, где стоит NPC приёма (заполняет город, см. job_points.gd).
## base_pay — выплата за полный цикл смены, per_task — бонус за каждое выполненное задание цикла.
## vehicle: "" | "any" | "truck" | "taxi" — требует автомобиль.
const JOBS: Dictionary = {
	"courier": {"name": "Курьер", "desc": "Разносите посылки по почтовым ящикам города.", "base_pay": 3200, "per_task": 450, "xp": 40, "min_level": 1, "icon": "jobs", "vehicle": "", "tasks": 3},
	"loader": {"name": "Грузчик", "desc": "Переносите коробки со склада в магазин. По одной — руки не казённые.", "base_pay": 1800, "per_task": 700, "xp": 55, "min_level": 1, "icon": "jobs", "vehicle": "", "tasks": 3},
	"taxi": {"name": "Таксист", "desc": "Развозите пассажиров по остановкам. Нужен автомобиль.", "base_pay": 4200, "per_task": 1300, "xp": 70, "min_level": 3, "icon": "car", "vehicle": "any", "tasks": 3, "license": "taxi"},
	"trucker": {"name": "Дальнобойщик", "desc": "Возите груз из порта по трём точкам города.", "base_pay": 6500, "per_task": 1600, "xp": 90, "min_level": 5, "icon": "car", "vehicle": "any", "tasks": 3},
	"builder": {"name": "Строитель", "desc": "Отделочные работы на стройке ЖК «Синий».", "base_pay": 5200, "per_task": 900, "xp": 80, "min_level": 4, "icon": "jobs", "vehicle": "", "tasks": 4},
	"miner": {"name": "Шахтёр", "desc": "Добывайте камень и руду в карьере на окраине.", "base_pay": 1500, "per_task": 380, "xp": 60, "min_level": 2, "icon": "shield", "vehicle": "", "tasks": 4},
	"lumberjack": {"name": "Лесоруб", "desc": "Рубите деревья в лесополосе за городом.", "base_pay": 1500, "per_task": 360, "xp": 60, "min_level": 2, "icon": "jobs", "vehicle": "", "tasks": 4},
	"fisher": {"name": "Рыбак", "desc": "Ловите рыбу на пруду. Нужен спиннинг (продаётся на рынке).", "base_pay": 800, "per_task": 300, "xp": 50, "min_level": 1, "icon": "star", "vehicle": "", "tasks": 3, "item": "rod"},
	"farmer": {"name": "Фермер", "desc": "Посадите урожай, вернитесь позже и соберите его.", "base_pay": 1200, "per_task": 420, "xp": 55, "min_level": 2, "icon": "health", "vehicle": "", "tasks": 4},
	"mechanic": {"name": "Механик", "desc": "Ремонтируйте автомобили клиентов в сервисе.", "base_pay": 2000, "per_task": 850, "xp": 75, "min_level": 4, "icon": "jobs", "vehicle": "", "tasks": 2, "item": "toolbox"},
	"police": {"name": "Полицейский", "desc": "Служба в полиции Ванбурга: патрули и задержания.", "base_pay": 4800, "per_task": 900, "xp": 85, "min_level": 6, "icon": "shield", "vehicle": "", "tasks": 4, "org": "police"},
	"army": {"name": "Служба в армии", "desc": "Караул на военной базе за городом.", "base_pay": 5600, "per_task": 1000, "xp": 95, "min_level": 8, "icon": "shield", "vehicle": "", "tasks": 4, "org": "army"},
}

## Уровни профессии: границы опыта навыка (индекс+1 = уровень).
const JOB_SKILL_STEPS: Array = [0, 120, 360, 840, 1800]
const JOB_LEVELS: Array = ["Новичок", "Стажёр", "Опытный", "Мастер", "Легенда"]

## Ранги организаций (полиция/армия).
const RANKS: Dictionary = {
	"police": ["Кадет", "Сержант", "Лейтенант", "Капитан", "Шеф полиции"],
	"army": ["Рядовой", "Ефрейтор", "Сержант", "Прапорщик", "Майор"],
}
## Множитель зарплаты от ранга организации (1..5).
const RANK_PAY: Array = [1.0, 1.18, 1.38, 1.6, 1.9]

## Розыск: сколько звёзд за каждое преступление, и цена ареста/тюрьмы.
const WANTED_DECAY_SEC := 240.0        # одна звезда спадает за 4 минуты без новых преступлений
const JAIL_SEC_PER_STAR := 50.0
const BAIL_PER_STAR := 4000

## Услуги города.
const SERVICES: Dictionary = {
	"hospital": {"name": "Больница Ванбурга", "heal_price": 1500, "partial_health": 40.0},
	"ambulance": {"name": "Вызов скорой", "price": 800, "delay": 15.0},
	"tow": {"name": "Эвакуатор со штрафстоянки", "price": 5000},
	"taxi_call": {"name": "Вызов такси", "price": 300},
	"impound_fee": {"name": "Штрафстоянка (штраф)", "price": 3500},
	"repair_per_percent": {"name": "Ремонт кузова за 1%", "price": 120},
	"fuel_per_liter": {"name": "Топливо за 1 литр", "price": 64},
	"race_entry_foot": {"name": "Взнос: забег вокруг парка", "price": 500},
	"race_entry_car": {"name": "Взнос: кольцевая гонка", "price": 1500},
}

## Тюнинг: id -> {название, цена, описание, бонус}.
const TUNING: Dictionary = {
	"spoiler": {"name": "Спойлер", "price": 45000, "desc": "+1 к управляемости", "handling": 1},
	"exhaust": {"name": "Спортивный выхлоп", "price": 65000, "desc": "+8% к разгону", "accel": 0.92},
	"tint": {"name": "Тонировка стёкол", "price": 15000, "desc": "Стильный тёмный салон", "visual": true},
	"neon": {"name": "Неоновая подсветка", "price": 28000, "desc": "Синее свечение под днищем", "visual": true},
	"rims": {"name": "Золотые диски", "price": 36000, "desc": "Хром меняется на золото", "visual": true},
}

## Территории банд.
const GANGS: Dictionary = {
	"port": {"name": "Портовые", "color": "c0392b", "tribute": 2600},
	"industrial": {"name": "Заводские", "color": "27ae60", "tribute": 2400},
	"north": {"name": "Северные", "color": "8e44ad", "tribute": 2200},
}
const GANG_TRIBUTE_PERIOD := 600.0   # 10 минут
const GANG_RETALIATION := 1800.0     # через 30 минут банда отбивает зону назад

## Гонки: чекпоинты задаёт мир. Призовые за финиш (чем быстрее — тем больше).
const RACES: Dictionary = {
	"foot": {"name": "Забег вокруг парка", "desc": "6 чекпоинтов пешком. Кроссовки быстрее!", "base_prize": 4200, "prize_per_sec": 22},
	"car": {"name": "Кольцевая гонка", "desc": "8 чекпоинтов на автомобиле по большому кругу.", "base_prize": 9000, "prize_per_sec": 16, "vehicle": true},
}


static func get_catalog(kind: String) -> Dictionary:
	match kind:
		"shop":
			var shop: Dictionary = {}
			for id in SHOP_ITEMS:
				shop[id] = ITEMS[id]
			return shop
		"cars":
			return CARS
		"property":
			return PROPERTY
		"jobs":
			return JOBS
		"business":
			return BUSINESSES
		"licenses":
			return LICENSES
		"tuning":
			return TUNING
		"pawnshop":
			var out: Dictionary = {}
			for id in SELLABLE:
				out[id] = ITEMS[id]
			return out
	return {}


static func item_name(item_id: String) -> String:
	if ITEMS.has(item_id):
		return String(ITEMS[item_id]["name"])
	return item_id


static func item_def(item_id: String) -> Dictionary:
	if ITEMS.has(item_id):
		return ITEMS[item_id]
	return {"name": item_id, "desc": "", "price": 0, "icon": "star", "kind": "misc", "weight": 0.1, "stack": 1}


static func dealer_catalog(dealer_id: String) -> Dictionary:
	var out: Dictionary = {}
	if not DEALERS.has(dealer_id):
		return out
	for cid in DEALERS[dealer_id]["cars"]:
		out[cid] = CARS[cid]
	return out


static func car_name(car_id: String) -> String:
	if CARS.has(car_id):
		return String(CARS[car_id]["name"])
	return car_id


static func property_name(prop_id: String) -> String:
	if PROPERTY.has(prop_id):
		return String(PROPERTY[prop_id]["name"])
	return prop_id


static func job_name(job_id: String) -> String:
	if JOBS.has(job_id):
		return String(JOBS[job_id]["name"])
	return job_id


## Уровень профессии по опыту.
static func job_skill_level(skill_xp: int) -> int:
	var lvl := 1
	for i in range(JOB_SKILL_STEPS.size()):
		if skill_xp >= int(JOB_SKILL_STEPS[i]):
			lvl = i + 1
	return lvl


## Сколько опыта навыка нужно до следующего уровня (0 — максимум).
static func job_skill_progress(skill_xp: int) -> Dictionary:
	var lvl := job_skill_level(skill_xp)
	if lvl >= JOB_SKILL_STEPS.size():
		return {"level": lvl, "xp": skill_xp, "need": 0}
	return {"level": lvl, "xp": skill_xp, "need": int(JOB_SKILL_STEPS[lvl])}


## Цена автомобиля с учётом износа (для продажи в салоне, 60% максимум).
static func car_sell_price(entry: Dictionary) -> int:
	var base := int(CARS[String(entry["id"])]["price"])
	var damage := float(entry.get("damage", 0.0))
	var wear := 1.0 - clampf(damage * 0.004, 0.0, 0.25)
	return int(float(base) * 0.6 * wear)
