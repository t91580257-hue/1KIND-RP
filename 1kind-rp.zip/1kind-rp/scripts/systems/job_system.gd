extends Node
## JobSystem (автозагрузка): движок профессий.
## Управляет сессией работы: цепочкой задач (дойти / удержание / ловля / ожидание),
## маркерами в мире, прогрессом и выплатой. Мир (vanburg.gd) подписывается на сигналы
## и рисует маркеры, а HUD показывает трекер заданий.
##
## Типы задач:
##   {"type":"goto",  "pos":Vector3, "r":радиус, "label":String, "hold":сек, "give":[id,count], "take":[id,count]}
##   {"type":"wait",  "seconds":N, "label":String}                      — таймер (ферма: урожай зреет)
##   {"type":"fish",  "pos":Vector3, "r":радиус, "label":String}         — мини-игра рыбалки
## Завершение задачи: done(), переход к следующей; финал — выплата.

signal session_started(job_id: String)
signal task_changed
signal session_progress(fraction: float)     # 0..1 прогресс удержания/ловли
signal session_finished(text: String)
signal session_cancelled(text: String)
signal fish_bite(active: bool)

const Points = preload("res://scripts/world/job_points.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

var active_job: String = ""
var tasks: Array = []
var task_index: int = 0
var session_token: int = 0
var started_at: float = 0.0
var tasks_done: int = 0

## Ссылка на игрока (устанавливает мир) — для проверки близости и удержания.
var player: Node3D = null

var _hold_progress: float = 0.0
var _fish_phase: String = ""      # "" | "cast" | "wait_bite" | "bite"
var _fish_timer: float = 0.0
var _fish_bite_window: float = 0.0


func is_active() -> bool:
		return active_job != ""


func current_task() -> Dictionary:
		if task_index >= 0 and task_index < tasks.size():
				return tasks[task_index]
		return {}


func current_marker_pos() -> Vector3:
		var t := current_task()
		if t.has("pos"):
				return t["pos"]
		return Vector3.ZERO


# ---------------------------------------------------------------- запуск/отмена

func can_start(job_id: String) -> Dictionary:
		if not Catalogs.JOBS.has(job_id):
				return {"ok": false, "text": "Работа не найдена."}
		if is_active():
				return {"ok": false, "text": "Сначала завершите текущую смену (%s)." % Catalogs.job_name(active_job)}
		var job: Dictionary = Catalogs.JOBS[job_id]
		if GameState.level < int(job["min_level"]):
				return {"ok": false, "text": "Нужен уровень %d." % int(job["min_level"])}
		if job.has("license") and not GameState.has_license(String(job["license"])):
				return {"ok": false, "text": "Нужна лицензия: %s (мэрия)." % String(Catalogs.LICENSES[String(job["license"])]["name"])}
		if job.has("item") and not GameState.has_item(String(job["item"])):
				return {"ok": false, "text": "Нужен предмет: %s." % Catalogs.item_name(String(job["item"]))}
		var left := GameState.cooldown_left("jobcd_" + job_id)
		if left > 0.0:
				return {"ok": false, "text": "Следующая смена через %d с." % int(ceil(left))}
		return {"ok": true, "text": ""}


func start_job(job_id: String) -> Dictionary:
		var check := can_start(job_id)
		if not bool(check["ok"]):
				return check
		var job: Dictionary = Catalogs.JOBS[job_id]
		# Такси и дальнобой требуют автомобиля под рукой.
		if String(job.get("vehicle", "")) == "any" and GameState.owned_cars.is_empty():
				return {"ok": false, "text": "Нужен автомобиль (купите в автосалоне или вызовите из гаража)."}
		tasks = _build_tasks(job_id)
		if tasks.is_empty():
				return {"ok": false, "text": "Маршрут смены недоступен."}
		active_job = job_id
		task_index = 0
		tasks_done = 0
		started_at = Time.get_unix_time_from_system()
		session_token = randi()
		_hold_progress = 0.0
		_fish_phase = ""
		GameState.start_cooldown("jobcd_" + job_id, 90.0)
		session_started.emit(job_id)
		task_changed.emit()
		return {"ok": true, "text": "Смена началась: %s" % String(job["name"])}


func cancel_session() -> void:
		if active_job == "":
				return
		var name := Catalogs.job_name(active_job)
		_cleanup()
		session_cancelled.emit("Смена «%s» прервана — без выплаты." % name)
		GameState.notify("Смена «%s» прервана — без выплаты." % name)


func _cleanup() -> void:
		active_job = ""
		tasks = []
		task_index = 0
		_hold_progress = 0.0
		_fish_phase = ""
		fish_bite.emit(false)


func abandon_allowed() -> bool:
		return is_active()


# ---------------------------------------------------------------- задачи

func _goto(pos: Vector3, label: String, hold: float = 0.0, r: float = 3.2, give: Array = [], take: Array = []) -> Dictionary:
		return {"type": "goto", "pos": pos, "label": label, "hold": hold, "r": r, "give": give, "take": take}


func _build_tasks(job_id: String) -> Array:
		var out: Array = []
		match job_id:
				"courier":
						out.append(_goto(Points.COURIER_GIVER, "Заберите посылки у диспетчера", 1.2, 3.0, ["package", 3]))
						var boxes: Array = Points.MAILBOXES.duplicate()
						boxes.shuffle()
						for i in range(3):
								out.append(_goto(boxes[i], "Доставьте посылку (%d/3)" % (i + 1), 1.0, 3.4, [], ["package", 1]))
				"loader":
						for i in range(3):
								var src: Vector3 = Points.LOADER_BOXES[i % Points.LOADER_BOXES.size()]
								out.append(_goto(src, "Возьмите коробку со склада (%d/3)" % (i + 1), 2.2))
								out.append(_goto(Points.LOADER_DROP, "Отнесите коробку в магазин", 2.2))
				"builder":
						for i in range(Points.BUILDER_STAGES.size()):
								out.append(_goto(Points.BUILDER_STAGES[i], "Этап отделки %d/%d" % [i + 1, Points.BUILDER_STAGES.size()], 4.0, 3.4))
				"miner":
						var rocks: Array = Points.QUARRY_ROCKS.duplicate()
						rocks.shuffle()
						for i in range(3):
								out.append(_goto(rocks[i % rocks.size()], "Добыча камня (%d/3)" % (i + 1), 3.0, 3.2, ["stone", 1]))
						if randf() < 0.35:
								out.append(_goto(rocks[3 % rocks.size()], "Редкая жила! Добыча руды", 4.0, 3.2, ["ore", 1]))
						out.append(_goto(Points.RAW_DEPOT, "Сдайте добычу на приёмку", 1.5, 3.4, [], ["stone", 3]))
				"lumberjack":
						var trees: Array = Points.FOREST_TREES.duplicate()
						trees.shuffle()
						for i in range(3):
								out.append(_goto(trees[i % trees.size()], "Валите дерево (%d/3)" % (i + 1), 3.4, 3.2, ["wood", 1]))
						out.append(_goto(trees[3 % trees.size()], "Последнее дерево", 3.4, 3.2, ["wood", 1]))
						out.append(_goto(Points.RAW_DEPOT, "Сдайте брёвна на приёмку", 1.5, 3.4, [], ["wood", 4]))
				"fisher":
						if not GameState.has_item("rod"):
								return []
						for i in range(3):
								out.append({"type": "fish", "pos": Points.FISH_SPOT, "r": 3.4, "label": "Забросьте спиннинг (%d/3)" % (i + 1), "give": [], "take": []})
						out.append(_goto(Points.MARKET_SELL, "Продайте улов на рынке", 1.0, 3.4))
				"farmer":
						for i in range(Points.FARM_PLOTS.size()):
								out.append(_goto(Points.FARM_PLOTS[i], "Посадите грядку (%d/4)" % (i + 1), 2.0, 3.0))
						out.append({"type": "wait", "seconds": 90.0, "label": "Урожай зреет — займитесь другими делами"})
						for i in range(Points.FARM_PLOTS.size()):
								out.append(_goto(Points.FARM_PLOTS[i], "Соберите урожай (%d/4)" % (i + 1), 2.0, 3.0, ["vegetables", 2]))
						out.append(_goto(Points.FARM_BARN, "Сдайте урожай на склад фермы", 1.5, 3.4, [], ["vegetables", 8]))
				"taxi":
						var stops: Array = Points.TAXI_STOPS.duplicate()
						stops.shuffle()
						for i in range(3):
								out.append(_goto(stops[i], "Подберите пассажира на остановке (%d/3)" % (i + 1), 1.0, 4.5))
								var dest: Vector3 = stops[(i + 1 + randi() % (stops.size() - 1)) % stops.size()]
								out.append(_goto(dest, "Доставьте пассажира до остановки", 0.0, 4.5))
				"trucker":
						out.append(_goto(Points.TRUCK_LOAD, "Загрузите контейнеры в порту", 3.0, 4.5))
						for i in range(Points.TRUCK_POINTS.size()):
								out.append(_goto(Points.TRUCK_POINTS[i], "Доставьте груз (точка %d/3)" % (i + 1), 1.2, 5.0))
						out.append(_goto(Points.TRUCK_RETURN, "Вернитесь в порт за расчётом", 1.5, 5.0))
				"mechanic":
						for i in range(Points.MECHANIC_CARS.size()):
								out.append(_goto(Points.MECHANIC_CARS[i], "Отремонтируйте автомобиль клиента (%d/2)" % (i + 1), 4.0, 3.4))
				"police":
						for i in range(Points.POLICE_CHECKPOINTS.size()):
								out.append(_goto(Points.POLICE_CHECKPOINTS[i], "Патруль: точка %d/4" % (i + 1), 1.0, 4.5))
						out.append(_goto(Points.POLICE_NPC, "Доложите о маршруте в участке", 1.0, 3.2))
				"army":
						for i in range(Points.ARMY_CHECKPOINTS.size()):
								out.append(_goto(Points.ARMY_CHECKPOINTS[i], "Караул: пост %d/4" % (i + 1), 1.5, 4.5))
						out.append(_goto(Points.ARMY_NPC, "Доложитесь командиру", 1.0, 3.2))
		return out


# ---------------------------------------------------------------- цикл обновления

func _process(delta: float) -> void:
		if not is_active() or player == null or not is_instance_valid(player):
				return
		var t := current_task()
		if t.is_empty():
				return
		match String(t.get("type", "goto")):
				"goto":
						_process_goto(t, delta)
				"wait":
						_process_wait(t, delta)
				"fish":
						_process_fish(t, delta)


func _task_distance(t: Dictionary) -> float:
		if player == null:
				return 1.0e9
		var p: Vector3 = t["pos"]
		var dx := player.global_position.x - p.x
		var dz := player.global_position.z - p.z
		return sqrt(dx * dx + dz * dz)


func _process_goto(t: Dictionary, delta: float) -> void:
		var d := _task_distance(t)
		var r := float(t.get("r", 3.2))
		if d > r:
				if _hold_progress > 0.0:
						_hold_progress = 0.0
						session_progress.emit(0.0)
				return
		var need := float(t.get("hold", 0.0))
		if need <= 0.0:
				_complete_task()
				return
		_hold_progress += delta
		session_progress.emit(clampf(_hold_progress / need, 0.0, 1.0))
		if _hold_progress >= need:
				_hold_progress = 0.0
				_complete_task()


func _process_wait(t: Dictionary, delta: float) -> void:
		t["seconds"] = float(t.get("seconds", 0.0)) - delta
		var total_left := maxf(0.0, float(t["seconds"]))
		session_progress.emit(1.0 - clampf(total_left / 90.0, 0.0, 1.0))
		if total_left <= 0.0:
				_complete_task()


func _process_fish(t: Dictionary, delta: float) -> void:
		var d := _task_distance(t)
		if d > float(t.get("r", 3.4)):
				if _fish_phase != "":
						_fish_phase = ""
						_fish_timer = 0.0
						fish_bite.emit(false)
				return
		match _fish_phase:
				"":
						# Фаза заброса: удержание в точке.
						_hold_progress += delta
						session_progress.emit(clampf(_hold_progress / 1.5, 0.0, 1.0))
						if _hold_progress >= 1.5:
								_hold_progress = 0.0
								_fish_phase = "wait_bite"
								_fish_timer = randf_range(2.5, 6.5)
								session_progress.emit(0.0)
				"wait_bite":
						_fish_timer -= delta
						if _fish_timer <= 0.0:
								_fish_phase = "bite"
								_fish_bite_window = 1.7
								fish_bite.emit(true)
				"bite":
						_fish_bite_window -= delta
						if _fish_bite_window <= 0.0:
								# Клюнула, но игрок не успел.
								_fish_phase = "wait_bite"
								_fish_timer = randf_range(3.0, 7.0)
								fish_bite.emit(false)
								GameState.notify("Рыба сорвалась! Ждите новую поклёвку.")


## Нажатие кнопки «Действие» во время поклёвки = подсечка.
func on_interact_pressed() -> void:
		if not is_active() or _fish_phase != "bite":
				return
		_fish_phase = ""
		fish_bite.emit(false)
		var t := current_task()
		var skill_bonus := clampf(0.12 * float(GameState.job_skill("fisher")["level"] - 1), 0.0, 0.5)
		if randf() < 0.72 + skill_bonus:
				var big := randf() < 0.12 + skill_bonus * 0.5
				var item := "fish_big" if big else "fish"
				var added := GameState.add_item(item, 1)
				if added > 0:
						if big:
								GameState.notify("Рекордный улов! %s — на рынке за него дадут дорого." % Catalogs.item_name(item))
						else:
								GameState.notify("Поймал: %s" % Catalogs.item_name(item))
						GameState.statistics["fish_caught"] = int(GameState.statistics.get("fish_caught", 0)) + 1
				else:
						GameState.notify("Улов выронил — инвентарь полон.")
				_complete_task()
		else:
				GameState.notify("Мимо! Рычащий поплавок ушёл под воду.")
				_fish_phase = "wait_bite"
				_fish_timer = randf_range(3.0, 7.0)


func _complete_task() -> void:
		var t := current_task()
		var give: Array = t.get("give", [])
		if give.size() == 2:
				var got := GameState.add_item(String(give[0]), int(give[1]))
				if got < int(give[1]):
						GameState.notify("Инвентарь полон! Освободите место и продолжите.")
						_hold_progress = 0.0
						return
		var take: Array = t.get("take", [])
		if take.size() == 2:
				GameState.remove_item(String(take[0]), int(take[1]))
		tasks_done += 1
		GameState.statistics["tasks_done"] = int(GameState.statistics.get("tasks_done", 0)) + 1
		task_index += 1
		if task_index >= tasks.size():
				_finish_session()
		else:
				AudioManager.play_sfx("click")
				task_changed.emit()


func _finish_session() -> void:
		var job_id := active_job
		var job: Dictionary = Catalogs.JOBS[job_id]
		# Онлайн: смену подтверждает сервер (считает выплату и навык сам).
		if GameState.online_mode:
				NetworkService.request("job_done", {"job": job_id, "token": session_token, "elapsed": Time.get_unix_time_from_system() - started_at})
				_cleanup()
				GameState.notify("Смена «%s» отправлена на проверку сервера…" % String(job["name"]))
				return
		var bonus := tasks_done * int(job.get("per_task", 0))
		var net := GameState.job_payout(job_id, bonus)
		GameState.add_xp(int(job["xp"]))
		GameState.add_job_skill_xp(job_id, int(job["xp"]))
		# Рост ранга организаций: каждая 4-я смена продвигает по службе.
		if job.has("org"):
				var org := String(job["org"])
				var rank := GameState.org_rank(org)
				var needed := 4 * rank
				if int(GameState.statistics.get("jobs_done", 0)) % maxi(2, needed) == 0 and rank < 5:
						GameState.org_ranks[org] = rank + 1
						GameState.notify("Повышение! Новый ранг: %s" % String(Catalogs.RANKS[org][rank]))
		GameState.statistics["jobs_done"] = int(GameState.statistics.get("jobs_done", 0)) + 1
		AudioManager.play_sfx("coin")
		_cleanup()
		session_finished.emit("Смена «%s» завершена: +%s на счёт (налог уплачен)" % [String(job["name"]), GameState.fmt_money(net)])
		GameState.save_profile()


# ---------------------------------------------------------------- HUD-хелперы

func task_text() -> String:
		if not is_active():
				return ""
		var t := current_task()
		var label := String(t.get("label", ""))
		if tasks.size() > 0:
				label += "  ·  этап %d/%d" % [task_index + 1, tasks.size()]
		return label


func marker_distance() -> float:
		var t := current_task()
		if t.is_empty() or t.get("pos") == null:
				return -1.0
		return _task_distance(t)


func hold_fraction() -> float:
		var t := current_task()
		if t.is_empty():
				return 0.0
		if String(t.get("type", "")) == "wait":
				return 1.0 - clampf(maxf(0.0, float(t.get("seconds", 0.0))) / 90.0, 0.0, 1.0)
		return clampf(_hold_progress, 0.0, 1.0)
