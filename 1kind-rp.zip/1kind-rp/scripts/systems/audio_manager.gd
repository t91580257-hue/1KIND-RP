extends Node
## Звук (автозагрузка AudioManager).
## Внешних аудиофайлов в первой версии нет: короткие звуки интерфейса и фоновая
## мелодия генерируются кодом (простые синусоиды). Шины "Music" и "SFX"
## создаёт GameSettings, их громкость задаётся в настройках.

const SFX_RATE := 22050
const MUSIC_RATE := 8000

var _music_player: AudioStreamPlayer
var _sfx_players: Array = []
var _sfx: Dictionary = {}
var _next_player: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_sfx["click"] = _make_tone([880.0], 0.06, 0.35, SFX_RATE)
	_sfx["coin"] = _make_sequence([988.0, 1319.0], 0.09, 0.35)
	_sfx["levelup"] = _make_sequence([523.0, 659.0, 784.0, 1047.0], 0.11, 0.35)
	_sfx["error"] = _make_tone([196.0], 0.18, 0.4, SFX_RATE)
	_sfx["open"] = _make_sequence([660.0, 880.0], 0.05, 0.3)
	for i in range(4):
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_players.append(p)
	_music_player = AudioStreamPlayer.new()
	_music_player.bus = "Music"
	_music_player.stream = _make_music()
	_music_player.volume_db = -6.0
	add_child(_music_player)
	_music_player.play()


func play_sfx(sfx_name: String) -> void:
	if not _sfx.has(sfx_name) or _sfx_players.is_empty():
		return
	var p: AudioStreamPlayer = _sfx_players[_next_player]
	_next_player = (_next_player + 1) % _sfx_players.size()
	p.stream = _sfx[sfx_name]
	p.play()


func _make_wav(samples: PackedFloat32Array, rate: int) -> AudioStreamWAV:
	var data := PackedByteArray()
	data.resize(samples.size() * 2)
	for i in range(samples.size()):
		data.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 32000.0))
	var wav := AudioStreamWAV.new()
	wav.format = AudioStreamWAV.FORMAT_16_BITS
	wav.mix_rate = rate
	wav.stereo = false
	wav.data = data
	return wav


func _tone_samples(freqs: Array, duration: float, volume: float, rate: int) -> PackedFloat32Array:
	var n := int(duration * rate)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in range(n):
		var t := float(i) / float(rate)
		var env := minf(1.0, float(n - i) / float(n) * 4.0) * minf(1.0, float(i) / 120.0)
		var s := 0.0
		for f in freqs:
			s += sin(TAU * float(f) * t)
		out[i] = s / float(freqs.size()) * volume * env
	return out


func _make_tone(freqs: Array, duration: float, volume: float, rate: int) -> AudioStreamWAV:
	return _make_wav(_tone_samples(freqs, duration, volume, rate), rate)


func _make_sequence(notes: Array, note_len: float, volume: float) -> AudioStreamWAV:
	var all := PackedFloat32Array()
	for f in notes:
		all.append_array(_tone_samples([float(f)], note_len, volume, SFX_RATE))
	return _make_wav(all, SFX_RATE)


## Спокойный зацикленный «пад» (аккорды Am – F – C – G), 16 секунд.
func _make_music() -> AudioStreamWAV:
	var chords: Array = [
		[110.0, 220.0, 261.63, 329.63],
		[87.31, 174.61, 220.0, 261.63],
		[130.81, 261.63, 329.63, 392.0],
		[98.0, 196.0, 246.94, 293.66],
	]
	var chord_len := 4.0
	var n_chord := int(chord_len * MUSIC_RATE)
	var samples := PackedFloat32Array()
	samples.resize(n_chord * chords.size())
	for c in range(chords.size()):
		var freqs: Array = chords[c]
		for i in range(n_chord):
			var t := float(i) / float(MUSIC_RATE)
			var env := sin(PI * float(i) / float(n_chord))
			env = 0.25 + 0.75 * env
			var s := 0.0
			for f in freqs:
				s += sin(TAU * float(f) * t)
			samples[c * n_chord + i] = s / float(freqs.size()) * 0.28 * env
	var wav := _make_wav(samples, MUSIC_RATE)
	wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
	wav.loop_begin = 0
	wav.loop_end = samples.size()
	return wav
