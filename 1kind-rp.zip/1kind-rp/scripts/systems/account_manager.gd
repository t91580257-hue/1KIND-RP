extends Node
## Локальная авторизация (автозагрузка AccountManager).
##
## ВАЖНО: это ЛОКАЛЬНАЯ авторизация на устройстве, а не онлайн-система.
## Аккаунты хранятся в user://accounts.json, пароли — только в виде
## PBKDF2-HMAC-SHA256 с уникальной случайной солью (в открытом виде не хранятся).
## Для перехода на серверную авторизацию (Nakama) см. network_service.gd и README.
##
## ПУЛЕНЕПРОБИВАЕМОСТЬ (v0.3.2, важно для Android):
##  • проверка пароля выполняется в ОТДЕЛЬНОМ ПОТОКЕ — интерфейс не блокируется;
##  • в цепочке авторизации НЕТ НИ ОДНОГО await: UI читает состояние проверки
##    простыми полями (check_running, check_elapsed_ms, check_progress()) в своём
##    _process и получает результат сигналом check_finished. Упавшая корутина
##    больше не может «заморозить» экран навсегда — так нечему падать;
##  • жёсткий тайм-аут MAX_HASH_SECONDS: и поток имеет внутренний предохранитель,
##    и автозагрузка следит за временем в _process — интерфейс гарантированно
##    разблокируется и показывает понятную ошибку;
##  • рабочий поток не трогает общие данные аккаунтов: получает копию задачи,
##    пишет результат в отдельное поле, читается оно только после завершения.
##
## СТАРЫЕ АККАУНТЫ (10 000 итераций) работают как раньше: параметр хранится
## в записи, после первого успешного входа аккаунт автоматически переводится
## на PBKDF2_ITERATIONS (медленный вход происходит только один раз).

signal check_finished(result: Dictionary)
## result: {"kind": "login"|"register", "ok": bool, "error": String, "nick": String}

const ACCOUNTS_PATH := "user://accounts.json"
const PBKDF2_ITERATIONS := 2000      # новые аккаунты: быстро даже на слабых Android
const LEGACY_ITERATIONS := 10000     # старые аккаунты (мигрируются при первом входе)
const SALT_BYTES := 16
const HASH_BYTES := 32
const MAX_HASH_SECONDS := 45.0       # жёсткий предел длительности проверки
const MIN_NICK := 3
const MAX_NICK := 16
const MIN_PASS := 6
const MAX_PASS := 64
const GENERIC_LOGIN_ERROR := "Неверный никнейм или пароль."

# Текущая проверка (UI читает напрямую, но не изменяет).
var check_running: bool = false       # идёт ли проверка
var check_kind: String = ""           # "login" | "register"
var check_elapsed_ms: int = 0         # сколько длится (обновляет _process)
var check_iter_done: int = 0          # счётчик итераций (обновляет поток)
var check_iter_total: int = 1         # всего итераций по задаче

var current_nick: String = ""
var logged_in: bool = false

var _accounts: Dictionary = {}
var _crypto := Crypto.new()
var _thread: Thread = null
var _task: Dictionary = {}            # данные задачи (готовятся в главном потоке)
var _out: Dictionary = {}             # результат потока (читается только после join)
var _started_ms: int = 0
var _discarded: bool = false          # результат отброшен (тайм-аут/отмена)


func _ready() -> void:
	# Проверка пароля и её тайм-аут следят через _process даже при паузе дерева.
	process_mode = Node.PROCESS_MODE_ALWAYS
	_load_accounts()


func _process(_delta: float) -> void:
	if _thread == null:
		return
	if _thread.is_alive():
		check_elapsed_ms = Time.get_ticks_msec() - _started_ms
		if check_elapsed_ms > int(MAX_HASH_SECONDS * 1000.0) and not _discarded:
			# Поток не убиваем: он завершится сам по внутреннему предохранителю
			# и будет присоединён в следующем кадре без обработки результата.
			_discard("Проверка заняла слишком много времени. Попробуйте ещё раз.")
		return
	# Поток завершён — забираем результат и применяем его в главном потоке.
	var out: Dictionary = _thread.wait_to_finish()
	_thread = null
	check_running = false
	if _discarded:
		return
	_apply_out(out)


## Прогресс проверки 0..1 (для статусных подписей UI).
func check_progress() -> float:
	if check_iter_total < 1:
		return 0.0
	return clampf(float(check_iter_done) / float(check_iter_total), 0.0, 1.0)


## Отменить ожидание текущей проверки (экран закрыли). Поток завершится сам.
func cancel_check() -> void:
	if _thread != null and not _discarded:
		_discard("Проверка отменена.")


# ------------------------------------------------ запуск проверки (мгновенно)

## Начать вход. Возвращает {"ok": bool, "error": String}; при ok=true результат
## придёт сигналом check_finished. Ничего не блокирует.
func start_login(nick: String, password: String) -> Dictionary:
	if _thread != null and _thread.is_alive():
		return {"ok": false, "error": "Предыдущая проверка ещё идёт, подождите."}
	nick = nick.strip_edges()
	if nick.is_empty() or password.is_empty():
		return {"ok": false, "error": "Введите никнейм и пароль."}
	var key := nick_key(nick)
	var known := _accounts.has(key)
	var salt: PackedByteArray
	var iterations := PBKDF2_ITERATIONS
	var expected_hex := ""
	var rehash := false
	var display_nick := nick
	var created: float = 0.0
	if known:
		var acc: Dictionary = _accounts[key]
		salt = String(acc.get("salt", "")).hex_decode()
		iterations = int(acc.get("iterations", PBKDF2_ITERATIONS))
		if iterations < 1:
			iterations = PBKDF2_ITERATIONS
		expected_hex = String(acc.get("hash", ""))
		display_nick = String(acc.get("nick", nick))
		created = float(acc.get("created", 0.0))
		rehash = iterations != PBKDF2_ITERATIONS
	else:
		# Фиктивное вычисление, чтобы время ответа не выдавало существование аккаунта.
		salt = _crypto.generate_random_bytes(SALT_BYTES)
	var total := iterations + (PBKDF2_ITERATIONS if rehash else 0)
	_begin_check("login", {
		"nick": nick,
		"nick_key": key,
		"known": known,
		"display_nick": display_nick,
		"created": created,
		"expected_hex": expected_hex,
		"password": password.to_utf8_buffer(),
		"salt": salt,
		"iterations": iterations,
		"dk_len": HASH_BYTES,
		"also_rehash": rehash,
	}, total)
	return {"ok": true, "error": ""}


## Начать регистрацию. Мгновенные проверки до хеширования — ошибки видны сразу.
func start_register(nick: String, password: String, password_repeat: String) -> Dictionary:
	if _thread != null and _thread.is_alive():
		return {"ok": false, "error": "Предыдущая проверка ещё идёт, подождите."}
	nick = nick.strip_edges()
	if nick.is_empty() or password.is_empty() or password_repeat.is_empty():
		return {"ok": false, "error": "Заполните все поля."}
	var nick_error := validate_nick(nick)
	if nick_error != "":
		return {"ok": false, "error": nick_error}
	var pass_error := validate_password(password)
	if pass_error != "":
		return {"ok": false, "error": pass_error}
	if password != password_repeat:
		return {"ok": false, "error": "Пароли не совпадают."}
	if account_exists(nick):
		return {"ok": false, "error": "Такой никнейм уже занят на этом устройстве."}
	var salt: PackedByteArray = _crypto.generate_random_bytes(SALT_BYTES)
	_begin_check("register", {
		"nick": nick,
		"nick_key": nick_key(nick),
		"password": password.to_utf8_buffer(),
		"salt": salt,
		"salt_hex": salt.hex_encode(),
		"iterations": PBKDF2_ITERATIONS,
		"dk_len": HASH_BYTES,
		"also_rehash": false,
	}, PBKDF2_ITERATIONS)
	return {"ok": true, "error": ""}


func _begin_check(kind: String, task: Dictionary, total_iterations: int) -> void:
	_task = task
	_out = {}
	_discarded = false
	check_running = true
	check_kind = kind
	check_elapsed_ms = 0
	check_iter_done = 0
	check_iter_total = maxi(total_iterations, 1)
	_started_ms = Time.get_ticks_msec()
	_thread = Thread.new()
	var err := _thread.start(_worker.bind(task))
	if err != OK:
		# Поток не стартовал — сразу сообщаем об ошибке, интерфейс не блокируется.
		_thread = null
		check_running = false
		_task = {}
		check_finished.emit({"kind": kind, "ok": false, "error": "Не удалось запустить проверку. Попробуйте ещё раз.", "nick": ""})


# ------------------------------------------------ рабочий поток (чистая математика)

func _worker(job: Dictionary) -> Dictionary:
	# job приходит через Callable.bind(): копия данных задачи без доступа
	# к общим полям autoload.
	var crypto := Crypto.new()
	var password: PackedByteArray = job["password"]
	var deadline := Time.get_ticks_msec() + int(MAX_HASH_SECONDS * 1000.0)
	var hash_b := _pbkdf2_worker(crypto, password, job["salt"], int(job["iterations"]), int(job["dk_len"]), deadline)
	if hash_b.is_empty():
		return {"timed_out": true}
	var out := {"timed_out": false, "hash": hash_b}
	if bool(job.get("also_rehash", false)):
		# Миграция старого аккаунта: новая соль + хеш на быстрых итерациях.
		var ns: PackedByteArray = crypto.generate_random_bytes(SALT_BYTES)
		var nh := _pbkdf2_worker(crypto, password, ns, PBKDF2_ITERATIONS, HASH_BYTES, deadline)
		if not nh.is_empty():
			out["rehash_salt"] = ns.hex_encode()
			out["rehash_hash"] = nh.hex_encode()
		# Если не успели — вход всё равно состоялся, миграция повторится при следующем входе.
	return out


## PBKDF2-HMAC-SHA256 (RFC 8018) внутри потока, с внутренним предохранителем по времени.
func _pbkdf2_worker(crypto: Crypto, password: PackedByteArray, salt: PackedByteArray, iterations: int, dk_len: int, deadline: int) -> PackedByteArray:
	var result := PackedByteArray()
	var block_index := 1
	while result.size() < dk_len:
		var salt_block := salt.duplicate()
		salt_block.append((block_index >> 24) & 0xFF)
		salt_block.append((block_index >> 16) & 0xFF)
		salt_block.append((block_index >> 8) & 0xFF)
		salt_block.append(block_index & 0xFF)
		var u: PackedByteArray = crypto.hmac_digest(HashingContext.HASH_SHA256, password, salt_block)
		var t: PackedByteArray = u.duplicate()
		var n := t.size()
		var i := 1
		while i < iterations:
			u = crypto.hmac_digest(HashingContext.HASH_SHA256, password, u)
			var j := 0
			while j < n:
				t[j] = t[j] ^ u[j]
				j += 1
			i += 1
			check_iter_done += 1
			if (i & 31) == 0 and Time.get_ticks_msec() > deadline:
				return PackedByteArray()
		result.append_array(t)
		block_index += 1
	return result.slice(0, dk_len)


# ------------------------------------------------ применение результата (главный поток)

func _apply_out(out: Dictionary) -> void:
	# Вид проверки хранится в check_kind (ключ kind в задачу не кладётся).
	if check_kind == "register":
		_apply_register(out)
		return
	_apply_login(out)


func _apply_register(out: Dictionary) -> void:
	var key := String(_task.get("nick_key", ""))
	var nick := String(_task.get("nick", ""))
	if bool(out.get("timed_out", false)):
		check_finished.emit({"kind": "register", "ok": false, "error": "Создание аккаунта заняло слишком много времени. Попробуйте ещё раз.", "nick": ""})
		return
	_accounts[key] = {
		"nick": nick,
		"salt": String(_task.get("salt_hex", "")),
		"hash": PackedByteArray(out["hash"]).hex_encode(),
		"iterations": int(_task.get("iterations", PBKDF2_ITERATIONS)),
		"algo": "PBKDF2-HMAC-SHA256",
		"created": Time.get_unix_time_from_system(),
	}
	if not _save_accounts():
		_accounts.erase(key)
		check_finished.emit({"kind": "register", "ok": false, "error": "Не удалось сохранить аккаунт на устройстве.", "nick": ""})
		return
	check_finished.emit({"kind": "register", "ok": true, "error": "", "nick": nick})


func _apply_login(out: Dictionary) -> void:
	var known := bool(_task.get("known", false))
	if bool(out.get("timed_out", false)):
		check_finished.emit({"kind": "login", "ok": false, "error": "Проверка заняла слишком много времени. Попробуйте ещё раз.", "nick": ""})
		return
	var expected := String(_task.get("expected_hex", "")).hex_decode()
	if not known or not _constant_time_equal(PackedByteArray(out["hash"]), expected):
		check_finished.emit({"kind": "login", "ok": false, "error": GENERIC_LOGIN_ERROR, "nick": ""})
		return
	var key := String(_task.get("nick_key", ""))
	current_nick = String(_task.get("display_nick", _task.get("nick", "")))
	logged_in = true
	if out.has("rehash_hash"):
		# Разовая миграция старого аккаунта на быстрый параметр итераций.
		_accounts[key] = {
			"nick": current_nick,
			"salt": String(out["rehash_salt"]),
			"hash": String(out["rehash_hash"]),
			"iterations": PBKDF2_ITERATIONS,
			"algo": "PBKDF2-HMAC-SHA256",
			"created": float(_task.get("created", 0.0)),
		}
		_save_accounts()
	check_finished.emit({"kind": "login", "ok": true, "error": "", "nick": current_nick})


func _discard(reason: String) -> void:
	_discarded = true
	check_running = false
	check_finished.emit({"kind": check_kind, "ok": false, "error": reason, "nick": ""})


# ------------------------------------------------ валидация и утилиты

func validate_nick(nick: String) -> String:
	if nick.length() < MIN_NICK or nick.length() > MAX_NICK:
		return "Никнейм должен содержать от %d до %d символов." % [MIN_NICK, MAX_NICK]
	var rx := RegEx.new()
	rx.compile("^[\\p{L}0-9_]+$")
	if rx.search(nick) == null:
		return "Никнейм может содержать только буквы, цифры и знак «_»."
	return ""


func validate_password(password: String) -> String:
	if password.length() < MIN_PASS:
		return "Пароль должен содержать минимум %d символов." % MIN_PASS
	if password.length() > MAX_PASS:
		return "Пароль слишком длинный (максимум %d символов)." % MAX_PASS
	return ""


func nick_key(nick: String) -> String:
	return nick.strip_edges().to_lower()


func account_exists(nick: String) -> bool:
	return _accounts.has(nick_key(nick))


func logout() -> void:
	current_nick = ""
	logged_in = false


func _constant_time_equal(a: PackedByteArray, b: PackedByteArray) -> bool:
	if a.size() != b.size():
		return false
	var diff := 0
	for i in range(a.size()):
		diff |= a[i] ^ b[i]
	return diff == 0


func _load_accounts() -> void:
	_accounts = {}
	if not FileAccess.file_exists(ACCOUNTS_PATH):
		return
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY and parsed.has("accounts") and typeof(parsed["accounts"]) == TYPE_DICTIONARY:
		_accounts = parsed["accounts"]


func _save_accounts() -> bool:
	var f := FileAccess.open(ACCOUNTS_PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Не удалось открыть %s для записи" % ACCOUNTS_PATH)
		return false
	f.store_string(JSON.stringify({"version": 1, "accounts": _accounts}))
	f.close()
	return true
