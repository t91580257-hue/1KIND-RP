extends Node
## Глобальные настройки игры (автозагрузка GameSettings).
## Хранятся в user://settings.cfg и сохраняются между запусками.

signal settings_changed

const SAVE_PATH := "user://settings.cfg"
const SECTION := "settings"
const QUALITY_NAMES: Array = ["Низкое", "Среднее", "Высокое"]

var camera_sensitivity: float = 1.0   # 0.3 .. 2.5
var music_volume: float = 0.5         # 0 .. 1
var sfx_volume: float = 0.8           # 0 .. 1
var graphics_quality: int = 1         # 0 низкое, 1 среднее, 2 высокое
var touch_scale: float = 1.0          # 0.7 .. 1.5 (размер элементов управления)
var touch_opacity: float = 0.85       # 0.3 .. 1.0
var invert_y: bool = false
var hold_to_run: bool = false         # false = кнопка бега работает как переключатель
var show_fps: bool = false


func _ready() -> void:
	load_settings()
	apply_audio()


func load_settings() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	camera_sensitivity = clampf(float(cfg.get_value(SECTION, "camera_sensitivity", camera_sensitivity)), 0.3, 2.5)
	music_volume = clampf(float(cfg.get_value(SECTION, "music_volume", music_volume)), 0.0, 1.0)
	sfx_volume = clampf(float(cfg.get_value(SECTION, "sfx_volume", sfx_volume)), 0.0, 1.0)
	graphics_quality = clampi(int(cfg.get_value(SECTION, "graphics_quality", graphics_quality)), 0, 2)
	touch_scale = clampf(float(cfg.get_value(SECTION, "touch_scale", touch_scale)), 0.7, 1.5)
	touch_opacity = clampf(float(cfg.get_value(SECTION, "touch_opacity", touch_opacity)), 0.3, 1.0)
	invert_y = bool(cfg.get_value(SECTION, "invert_y", invert_y))
	hold_to_run = bool(cfg.get_value(SECTION, "hold_to_run", hold_to_run))
	show_fps = bool(cfg.get_value(SECTION, "show_fps", show_fps))


func save_settings() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value(SECTION, "camera_sensitivity", camera_sensitivity)
	cfg.set_value(SECTION, "music_volume", music_volume)
	cfg.set_value(SECTION, "sfx_volume", sfx_volume)
	cfg.set_value(SECTION, "graphics_quality", graphics_quality)
	cfg.set_value(SECTION, "touch_scale", touch_scale)
	cfg.set_value(SECTION, "touch_opacity", touch_opacity)
	cfg.set_value(SECTION, "invert_y", invert_y)
	cfg.set_value(SECTION, "hold_to_run", hold_to_run)
	cfg.set_value(SECTION, "show_fps", show_fps)
	var err := cfg.save(SAVE_PATH)
	if err != OK:
		push_warning("Не удалось сохранить настройки, код ошибки: %d" % err)


func reset_to_defaults() -> void:
	camera_sensitivity = 1.0
	music_volume = 0.5
	sfx_volume = 0.8
	graphics_quality = 1
	touch_scale = 1.0
	touch_opacity = 0.85
	invert_y = false
	hold_to_run = false
	show_fps = false
	apply_all()


## Применить изменения и уведомить подписчиков (HUD, сенсорное управление, мир).
func apply_all() -> void:
	apply_audio()
	settings_changed.emit()


func apply_audio() -> void:
	_set_bus_volume("Music", music_volume)
	_set_bus_volume("SFX", sfx_volume)


func _set_bus_volume(bus_name: String, linear: float) -> void:
	var idx := _ensure_bus(bus_name)
	AudioServer.set_bus_mute(idx, linear <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.0001)))


func _ensure_bus(bus_name: String) -> int:
	var idx := AudioServer.get_bus_index(bus_name)
	if idx == -1:
		AudioServer.add_bus()
		idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(idx, bus_name)
		AudioServer.set_bus_send(idx, "Master")
	return idx


## Настройки Viewport: сглаживание.
func apply_viewport(vp: Viewport) -> void:
	if vp == null:
		return
	if graphics_quality >= 2:
		vp.msaa_3d = Viewport.MSAA_2X
	else:
		vp.msaa_3d = Viewport.MSAA_DISABLED


## Настройки солнца: тени и дальность теней.
func apply_light(light: DirectionalLight3D) -> void:
	if light == null:
		return
	match graphics_quality:
		0:
			light.shadow_enabled = false
		1:
			light.shadow_enabled = true
			light.directional_shadow_max_distance = 55.0
		_:
			light.shadow_enabled = true
			light.directional_shadow_max_distance = 110.0


## Дальность отрисовки камеры.
func camera_far() -> float:
	match graphics_quality:
		0:
			return 650.0
		1:
			return 1200.0
	return 2000.0


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_settings()
