extends Node
## Состояние игрока и профиль (автозагрузка GameState).
## Баланс виртуальной валюты, уровень, опыт, инвентарь, покупки.
## Профиль каждого аккаунта сохраняется в user://profiles/<sha256 никнейма>.json.
## Это локальное сохранение; для онлайна профиль будет храниться на сервере.

signal balance_changed(new_balance: int)
signal xp_changed(level: int, xp: int, xp_needed: int)
signal inventory_changed
signal notification(text: String)

const Catalogs = preload("res://scripts/systems/catalogs.gd")

const CURRENCY := "VB"
const START_BALANCE := 500
const PROFILE_DIR := "user://profiles"
const AUTOSAVE_INTERVAL := 30.0

var nickname: String = ""
var balance: int = 0
var level: int = 1
var xp: int = 0
var play_seconds: float = 0.0
var inventory: Dictionary = {}      # item_id -> количество
var owned_cars: Array = []          # id автомобилей
var owned_property: Array = []      # id недвижимости
var cooldowns: Dictionary = {}      # ключ -> unix-время готовности
var session_active: bool = false

var _autosave_timer: float = 0.0


func _process(delta: float) -> void:
	if not session_active:
		return
	play_seconds += delta
	_autosave_timer += delta
	if _autosave_timer >= AUTOSAVE_INTERVAL:
		_autosave_timer = 0.0
		save_profile()


func xp_needed(for_level: int) -> int:
	return 100 + (for_level - 1) * 50


func fmt_money(amount: int) -> String:
	var s := str(absi(amount))
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = " " + out
	if amount < 0:
		out = "-" + out
	return "%s %s" % [out, CURRENCY]


func fmt_time(seconds: float) -> String:
	var total := int(seconds)
	return "%d ч %02d мин" % [total / 3600, (total % 3600) / 60]


# ---------- Сессия ----------

func start_session(nick: String) -> void:
	nickname = nick
	_reset_profile()
	load_profile()
	session_active = true
	_autosave_timer = 0.0
	balance_changed.emit(balance)
	xp_changed.emit(level, xp, xp_needed(level))
	inventory_changed.emit()


func end_session() -> void:
	if session_active:
		save_profile()
	session_active = false
	nickname = ""
	_reset_profile()
	AccountManager.logout()


func _reset_profile() -> void:
	balance = START_BALANCE
	level = 1
	xp = 0
	play_seconds = 0.0
	inventory = {}
	owned_cars = []
	owned_property = []
	cooldowns = {}


func _profile_path() -> String:
	return "%s/%s.json" % [PROFILE_DIR, nickname.strip_edges().to_lower().sha256_text()]


func save_profile() -> void:
	if nickname == "":
		return
	DirAccess.make_dir_recursive_absolute(PROFILE_DIR)
	var data := {
		"version": 1,
		"nickname": nickname,
		"balance": balance,
		"level": level,
		"xp": xp,
		"play_seconds": play_seconds,
		"inventory": inventory,
		"owned_cars": owned_cars,
		"owned_property": owned_property,
		"cooldowns": cooldowns,
	}
	var f := FileAccess.open(_profile_path(), FileAccess.WRITE)
	if f == null:
		push_warning("Не удалось сохранить профиль игрока.")
		return
	f.store_string(JSON.stringify(data))
	f.close()


func load_profile() -> void:
	var path := _profile_path()
	if not FileAccess.file_exists(path):
		return
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	balance = int(parsed.get("balance", START_BALANCE))
	level = maxi(1, int(parsed.get("level", 1)))
	xp = maxi(0, int(parsed.get("xp", 0)))
	play_seconds = float(parsed.get("play_seconds", 0.0))
	var inv: Variant = parsed.get("inventory", {})
	inventory = {}
	if typeof(inv) == TYPE_DICTIONARY:
		for k in inv.keys():
			inventory[String(k)] = int(inv[k])
	owned_cars = _to_string_array(parsed.get("owned_cars", []))
	owned_property = _to_string_array(parsed.get("owned_property", []))
	var cds: Variant = parsed.get("cooldowns", {})
	cooldowns = {}
	if typeof(cds) == TYPE_DICTIONARY:
		for k in cds.keys():
			cooldowns[String(k)] = float(cds[k])


func _to_string_array(src: Variant) -> Array:
	var out: Array = []
	if typeof(src) == TYPE_ARRAY:
		for v in src:
			out.append(String(v))
	return out


# ---------- Экономика ----------

func add_money(amount: int) -> void:
	balance += amount
	balance_changed.emit(balance)


func try_spend(amount: int) -> bool:
	if amount < 0 or balance < amount:
		return false
	balance -= amount
	balance_changed.emit(balance)
	return true


func add_xp(amount: int) -> void:
	xp += amount
	while xp >= xp_needed(level):
		xp -= xp_needed(level)
		level += 1
		notification.emit("Новый уровень: %d!" % level)
		AudioManager.play_sfx("levelup")
	xp_changed.emit(level, xp, xp_needed(level))


func notify(text: String) -> void:
	notification.emit(text)


# ---------- Инвентарь ----------

func add_item(item_id: String, count: int = 1) -> void:
	inventory[item_id] = int(inventory.get(item_id, 0)) + count
	inventory_changed.emit()


func remove_item(item_id: String, count: int = 1) -> bool:
	var have := int(inventory.get(item_id, 0))
	if have < count:
		return false
	if have == count:
		inventory.erase(item_id)
	else:
		inventory[item_id] = have - count
	inventory_changed.emit()
	return true


# ---------- Покупки ----------

## kind: "shop" | "cars" | "property". Возвращает {"ok": bool, "text": String}.
func buy(kind: String, item_id: String) -> Dictionary:
	var catalog := Catalogs.get_catalog(kind)
	if not catalog.has(item_id):
		return {"ok": false, "text": "Товар не найден."}
	var entry: Dictionary = catalog[item_id]
	var price := int(entry["price"])
	if kind == "cars" and owned_cars.has(item_id):
		return {"ok": false, "text": "Этот автомобиль уже у вас."}
	if kind == "property" and owned_property.has(item_id):
		return {"ok": false, "text": "Эта недвижимость уже принадлежит вам."}
	if not try_spend(price):
		return {"ok": false, "text": "Недостаточно средств."}
	match kind:
		"shop":
			add_item(item_id, 1)
		"cars":
			owned_cars.append(item_id)
			inventory_changed.emit()
		"property":
			owned_property.append(item_id)
			inventory_changed.emit()
	add_xp(10)
	AudioManager.play_sfx("coin")
	save_profile()
	return {"ok": true, "text": "Покупка: %s" % String(entry["name"])}


# ---------- Работа ----------

func work(job_id: String) -> Dictionary:
	if not Catalogs.JOBS.has(job_id):
		return {"ok": false, "text": "Работа не найдена."}
	var job: Dictionary = Catalogs.JOBS[job_id]
	if level < int(job["min_level"]):
		return {"ok": false, "text": "Нужен уровень %d." % int(job["min_level"])}
	var left := cooldown_left("job_" + job_id)
	if left > 0.0:
		return {"ok": false, "text": "Отдохните ещё %d с." % int(ceil(left))}
	start_cooldown("job_" + job_id, float(job["cooldown"]))
	add_money(int(job["pay"]))
	add_xp(int(job["xp"]))
	AudioManager.play_sfx("coin")
	save_profile()
	return {"ok": true, "text": "Смена завершена: +%s" % fmt_money(int(job["pay"]))}


# ---------- Перезарядки ----------

func cooldown_left(key: String) -> float:
	var ready_at := float(cooldowns.get(key, 0.0))
	return maxf(0.0, ready_at - Time.get_unix_time_from_system())


func start_cooldown(key: String, seconds: float) -> void:
	cooldowns[key] = Time.get_unix_time_from_system() + seconds


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if session_active:
			save_profile()
