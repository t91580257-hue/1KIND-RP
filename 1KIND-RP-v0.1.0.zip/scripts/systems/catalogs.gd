extends RefCounted
## Каталоги игровых данных: товары, автомобили, недвижимость, работы.
## Все данные описаны в одном месте, чтобы позже их можно было заменить
## данными с сервера (Nakama storage) без переписывания интерфейса.

const ITEMS: Dictionary = {
	"water": {"name": "Бутылка воды", "desc": "Освежает в жаркий день.", "price": 25, "icon": "health"},
	"sandwich": {"name": "Сэндвич", "desc": "Сытный перекус из кафе.", "price": 60, "icon": "shop"},
	"phone_case": {"name": "Чехол для телефона", "desc": "Сине-золотой, с короной.", "price": 150, "icon": "phone"},
	"map_vanburg": {"name": "Карта Ванбурга", "desc": "Бумажная карта города.", "price": 90, "icon": "map"},
	"gold_badge": {"name": "Золотой значок", "desc": "Знак отличия жителя Ванбурга.", "price": 400, "icon": "star"},
}

const CARS: Dictionary = {
	"hatch": {"name": "Городской хэтчбек «Ванби»", "desc": "Экономичный городской автомобиль.", "price": 8500, "icon": "car"},
	"sedan": {"name": "Седан «Корона S»", "desc": "Комфортный седан бизнес-класса.", "price": 21000, "icon": "car"},
	"coupe": {"name": "Купе «Золотая стрела»", "desc": "Быстрое спортивное купе.", "price": 48000, "icon": "car"},
}

const PROPERTY: Dictionary = {
	"studio": {"name": "Студия на Площади", "desc": "Уютная студия рядом с фонтаном.", "price": 12000, "icon": "home"},
	"flat": {"name": "Квартира в высотке", "desc": "Двухкомнатная квартира с видом на город.", "price": 30000, "icon": "home"},
	"house": {"name": "Дом в жилом районе", "desc": "Собственный дом с гаражом.", "price": 65000, "icon": "home"},
}

const JOBS: Dictionary = {
	"courier": {"name": "Курьер", "desc": "Развезти посылки по району.", "pay": 120, "xp": 30, "cooldown": 25.0, "min_level": 1, "icon": "jobs"},
	"loader": {"name": "Грузчик", "desc": "Разгрузить машину у магазина.", "pay": 220, "xp": 45, "cooldown": 35.0, "min_level": 2, "icon": "jobs"},
	"guard": {"name": "Охранник", "desc": "Дежурство на объекте.", "pay": 380, "xp": 70, "cooldown": 50.0, "min_level": 4, "icon": "shield"},
}


static func get_catalog(kind: String) -> Dictionary:
	match kind:
		"shop":
			return ITEMS
		"cars":
			return CARS
		"property":
			return PROPERTY
		"jobs":
			return JOBS
	return {}


static func item_name(item_id: String) -> String:
	if ITEMS.has(item_id):
		return String(ITEMS[item_id]["name"])
	return item_id


static func car_name(car_id: String) -> String:
	if CARS.has(car_id):
		return String(CARS[car_id]["name"])
	return car_id


static func property_name(prop_id: String) -> String:
	if PROPERTY.has(prop_id):
		return String(PROPERTY[prop_id]["name"])
	return prop_id
