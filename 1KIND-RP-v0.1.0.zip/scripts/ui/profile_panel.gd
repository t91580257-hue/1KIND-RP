extends Control
## Профиль игрока: ник, уровень, баланс, время в игре, инвентарь, автомобили и недвижимость.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(760, 560)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)
	root.add_child(UiKit.make_title("Профиль", 40))

	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 18)
	root.add_child(head)
	head.add_child(UiKit.make_icon("user", 86))
	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(info)
	info.add_child(UiKit.make_label(GameState.nickname, 34, UiKit.COLOR_GOLD))
	info.add_child(UiKit.make_label("Уровень %d  ·  опыт %d / %d" % [GameState.level, GameState.xp, GameState.xp_needed(GameState.level)], 22))
	info.add_child(UiKit.make_label("Баланс: %s" % GameState.fmt_money(GameState.balance), 24, UiKit.COLOR_TEXT))
	info.add_child(UiKit.make_label("Время в игре: %s" % GameState.fmt_time(GameState.play_seconds), 20, UiKit.COLOR_MUTED))
	info.add_child(UiKit.make_label("Режим: %s" % NetworkService.mode_title(), 20, UiKit.COLOR_MUTED))

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 250)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var lists := VBoxContainer.new()
	lists.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lists.add_theme_constant_override("separation", 6)
	scroll.add_child(lists)

	_section(lists, "Инвентарь", _inventory_lines())
	_section(lists, "Автомобили", _car_lines())
	_section(lists, "Недвижимость", _property_lines())

	var close := UiKit.make_button("Закрыть", "gold", Vector2(300, 64))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)


func _section(parent: Control, title: String, lines: Array) -> void:
	parent.add_child(UiKit.make_label(title, 26, UiKit.COLOR_GOLD))
	if lines.is_empty():
		parent.add_child(UiKit.make_label("Пока пусто", 20, UiKit.COLOR_MUTED))
		return
	for line in lines:
		parent.add_child(UiKit.make_label("•  %s" % String(line), 22))


func _inventory_lines() -> Array:
	var out: Array = []
	for id in GameState.inventory.keys():
		out.append("%s × %d" % [Catalogs.item_name(String(id)), int(GameState.inventory[id])])
	return out


func _car_lines() -> Array:
	var out: Array = []
	for id in GameState.owned_cars:
		out.append(Catalogs.car_name(String(id)))
	return out


func _property_lines() -> Array:
	var out: Array = []
	for id in GameState.owned_property:
		out.append(Catalogs.property_name(String(id)))
	return out
