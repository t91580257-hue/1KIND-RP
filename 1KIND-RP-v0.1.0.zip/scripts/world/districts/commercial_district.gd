extends "res://scripts/world/districts/district.gd"
## Торговый квартал (северо-восток): магазин, автосалон, агентство
## недвижимости и большая парковка с разметкой.

const Kit = preload("res://scripts/world/world_kit.gd")

const ORIGIN := Vector3(35.0, 0.0, -35.0)


func build() -> void:
	name = "Commercial"
	_build_shops()
	_build_parking_lot()


func _build_shops() -> void:
	var shops: Array = [
		{"x": -8.5, "tex": "brick_red", "sign": "МАГАЗИН 24/7", "action": "shop", "title": "Магазин 24/7", "prompt": "Зайти в магазин"},
		{"x": 5.5, "tex": "concrete", "sign": "АВТОСАЛОН", "action": "cars", "title": "Автосалон «Корона-Мотор»", "prompt": "Выбрать автомобиль"},
		{"x": 19.5, "tex": "stone", "sign": "НЕДВИЖИМОСТЬ", "action": "property", "title": "Агентство «Золотой ключ»", "prompt": "Посмотреть объекты"},
	]
	for s in shops:
		var lx: float = s["x"]
		var wall_tex: String = s["tex"]
		var sign_text: String = s["sign"]
		var action: String = s["action"]
		var title: String = s["title"]
		var prompt: String = s["prompt"]
		Kit.add_shop(self, ORIGIN + Vector3(lx, 0, 21), Vector3(13, 7, 10), wall_tex, sign_text, 0.0)
		Kit.add_interactable(self, ORIGIN + Vector3(lx, 0, 27.5), action, title, prompt, 2.8)
	# Деревья между магазинами и парковкой.
	for i in range(6):
		Kit.add_tree(self, ORIGIN + Vector3(-12.0 + 7.0 * float(i), 0, 9.0), 0.9, i)


func _build_parking_lot() -> void:
	var asphalt := Kit.tri_mat("asphalt", 6.0, Color(0.9, 0.9, 0.95))
	var white := Kit.color_mat(Color(0.95, 0.95, 0.95), 0.9)
	var center := ORIGIN + Vector3(4, 0, -10)
	Kit.add_flat(self, center.x, center.z, 36.0, 24.0, 0.05, asphalt)
	var rng := RandomNumberGenerator.new()
	rng.seed = 424242
	var colors: Array = [
		Color(0.8, 0.1, 0.1), Color(0.1, 0.35, 0.8), Color(0.95, 0.75, 0.15),
		Color(0.85, 0.85, 0.88), Color(0.1, 0.1, 0.12), Color(0.1, 0.5, 0.3), Color(0.5, 0.2, 0.6),
	]
	for row_z in [-17.0, -3.0]:
		var rz: float = row_z
		for k in range(13):
			var x := -14.0 + 3.0 * float(k)
			Kit.add_box(self, ORIGIN + Vector3(x, 0.058, rz), Vector3(0.12, 0.012, 5.5), white, false)
		for k in range(12):
			if rng.randf() < 0.55:
				var cx := -12.5 + 3.0 * float(k)
				var col: Color = colors[rng.randi() % colors.size()]
				var rot := 90.0 if rz > -10.0 else -90.0
				Kit.add_car(self, ORIGIN + Vector3(cx, 0, rz), rot, col)
	Kit.add_sign(self, ORIGIN + Vector3(-15.5, 0, -10), "parking", 90.0)
	Kit.add_sign(self, ORIGIN + Vector3(22.5, 0, -10), "parking", -90.0)
	for i in range(5):
		Kit.add_tree(self, ORIGIN + Vector3(-12.0 + 8.0 * float(i), 0, -24.0), 1.0, i + 1)
	for i in range(4):
		Kit.add_lamp(self, ORIGIN + Vector3(-12.0 + 12.0 * float(i), 0, -10.0), 0.0)
