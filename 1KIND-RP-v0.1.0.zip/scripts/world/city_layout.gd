extends RefCounted
## Общая сетка Ванбурга. Все размеры в метрах.
## Улицы идут вдоль осей X и Z по линиям LINES. Кварталы лежат между улицами,
## центры кварталов — (±35, ±35). В центре (0, 0) — Центральная площадь.

const ROAD_W := 12.0            # ширина проезжей части
const HALF_ROAD := 6.0
const SIDEWALK_W := 3.0
const LINES: Array = [-70.0, 0.0, 70.0]
const EXTENT := 110.0           # улицы тянутся до ±EXTENT
const PLAZA_HALF := 20.0        # половина стороны площади
const BOUNDARY := 114.0         # граница игровой зоны (живая изгородь)
const SPAWN := Vector3(0.0, 1.0, 13.0)


## Название района по позиции (для HUD).
static func zone_name(p: Vector3) -> String:
	if absf(p.x) < PLAZA_HALF and absf(p.z) < PLAZA_HALF:
		return "Центральная площадь"
	if absf(p.x) > 76.0 or absf(p.z) > 76.0:
		return "Окраина Ванбурга"
	if p.x < -6.0 and p.z < -6.0:
		return "Гражданский квартал"
	if p.x > 6.0 and p.z < -6.0:
		return "Торговый квартал"
	if p.x < -6.0 and p.z > 6.0:
		return "Жилой район: высотки"
	if p.x > 6.0 and p.z > 6.0:
		return "Жилой район: дома"
	return "Улицы Ванбурга"
