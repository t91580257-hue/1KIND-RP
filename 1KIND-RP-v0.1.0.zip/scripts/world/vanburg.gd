extends Node3D
## Игровой мир Ванбург: собирает город, игрока, HUD, сенсорное управление и меню.
## Обрабатывает взаимодействия с объектами города и пауза/оверлеи.

const CityBuilder = preload("res://scripts/world/city_builder.gd")
const Layout = preload("res://scripts/world/city_layout.gd")
const UiKit = preload("res://scripts/ui/ui_kit.gd")
const PlayerScene = preload("res://scenes/player/player.tscn")
const HudScene = preload("res://scenes/ui/hud.tscn")
const TouchScene = preload("res://scenes/ui/touch_controls.tscn")
const PauseScene = preload("res://scenes/ui/pause_menu.tscn")
const ProfileScene = preload("res://scenes/ui/profile_panel.tscn")
const CatalogScene = preload("res://scenes/ui/catalog_panel.tscn")
const SettingsScene = preload("res://scenes/ui/settings_screen.tscn")
const MENU_SCENE := "res://scenes/main_menu.tscn"

const ATM_COOLDOWN := 90.0
const ATM_PAYOUT := 250

var _player = null
var _hud = null
var _touch = null
var _ui: CanvasLayer
var _sun: DirectionalLight3D
var _overlay: Control = null
var _overlay_from_pause: bool = false
var _zone_timer: float = 0.0


func _ready() -> void:
	get_tree().set_quit_on_go_back(false)
	# Запуск сцены напрямую из редактора (без входа): временная тестовая сессия.
	if not GameState.session_active:
		GameState.start_session("Тестер")

	_ui = CanvasLayer.new()
	_ui.layer = 10
	add_child(_ui)
	var loading := _make_loading()
	_ui.add_child(loading)
	# Два кадра, чтобы экран загрузки успел отрисоваться до построения города.
	await get_tree().process_frame
	await get_tree().process_frame

	_sun = CityBuilder.add_atmosphere(self)
	GameSettings.apply_light(_sun)
	GameSettings.apply_viewport(get_viewport())
	GameSettings.settings_changed.connect(_on_settings_changed)
	var info := CityBuilder.build(self)

	_player = PlayerScene.instantiate()
	add_child(_player)
	_player.global_position = info["spawn"]
	_player.focus_changed.connect(_on_focus_changed)

	_hud = HudScene.instantiate()
	_ui.add_child(_hud)
	_touch = TouchScene.instantiate()
	_ui.add_child(_touch)
	_player.controls = _touch
	_touch.jump_pressed.connect(_player.request_jump)
	_touch.interact_pressed.connect(_interact)
	_touch.menu_pressed.connect(_open_pause)

	loading.queue_free()
	GameState.notify("Добро пожаловать в Ванбург, %s!" % GameState.nickname)


func _exit_tree() -> void:
	if GameSettings.settings_changed.is_connected(_on_settings_changed):
		GameSettings.settings_changed.disconnect(_on_settings_changed)


func _make_loading() -> Control:
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = UiKit.COLOR_NAVY
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)
	var vb := VBoxContainer.new()
	center.add_child(vb)
	var icon := UiKit.make_icon("crown", 120)
	icon.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	vb.add_child(icon)
	vb.add_child(UiKit.make_title("Загрузка Ванбурга…", 40))
	return root


func _on_settings_changed() -> void:
	GameSettings.apply_light(_sun)
	GameSettings.apply_viewport(get_viewport())


func _process(delta: float) -> void:
	if _player == null or _hud == null:
		return
	_zone_timer -= delta
	if _zone_timer <= 0.0:
		_zone_timer = 0.4
		_hud.set_zone(Layout.zone_name(_player.global_position))


# ---------- Ввод ----------

func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	if key.physical_keycode == KEY_E and _overlay == null:
		_interact()
	elif key.physical_keycode == KEY_ESCAPE:
		_toggle_pause()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_toggle_pause()


func _toggle_pause() -> void:
	if _player == null:
		return
	if _overlay == null:
		_open_pause()
	else:
		_close_overlay()


# ---------- Взаимодействия ----------

func _on_focus_changed(target) -> void:
	if target == null:
		_hud.set_prompt("", "")
		return
	_hud.set_prompt(String(target.get("title")), "%s — кнопка «ДЕЙСТВИЕ» (E)" % String(target.get("prompt")))


func _interact() -> void:
	if _overlay != null or _player == null:
		return
	var target = _player.focus_target
	if target == null or not is_instance_valid(target):
		GameState.notify("Рядом нет объектов для взаимодействия.")
		return
	AudioManager.play_sfx("click")
	perform_interaction(String(target.get("action_id")), String(target.get("title")))


func perform_interaction(action_id: String, title: String) -> void:
	match action_id:
		"atm":
			var left := GameState.cooldown_left("atm")
			if left > 0.0:
				GameState.notify("Банкомат: пособие будет доступно через %d с." % int(ceil(left)))
				AudioManager.play_sfx("error")
			else:
				GameState.start_cooldown("atm", ATM_COOLDOWN)
				GameState.add_money(ATM_PAYOUT)
				GameState.notify("Банкомат: пособие +%s" % GameState.fmt_money(ATM_PAYOUT))
				AudioManager.play_sfx("coin")
		"fountain":
			if GameState.try_spend(1):
				GameState.add_xp(5)
				GameState.notify("Монета брошена в фонтан. Загадайте желание! (+5 опыта)")
				AudioManager.play_sfx("coin")
			else:
				GameState.notify("Нет монетки: баланс пуст.")
				AudioManager.play_sfx("error")
		"info_board":
			GameState.notify("Ванбург: площадь, торговый и гражданский кварталы, высотки и жилые дома. Онлайн появится позже.")
		"bus_stop":
			GameState.notify("%s: общественный транспорт появится в будущих версиях." % title)
		"shop", "cars", "property", "jobs":
			_open_catalog(action_id)
		_:
			GameState.notify(title)


# ---------- Оверлеи ----------

func _set_overlay(node: Control, from_pause: bool) -> void:
	if _overlay != null:
		_overlay.queue_free()
	_overlay = node
	_overlay_from_pause = from_pause
	_ui.add_child(node)
	get_tree().paused = true
	_touch.enabled = false
	_player.input_enabled = false
	_hud.set_prompt("", "")
	AudioManager.play_sfx("open")


func _close_overlay() -> void:
	if _overlay != null:
		_overlay.queue_free()
		_overlay = null
	get_tree().paused = false
	_touch.enabled = true
	_player.input_enabled = true
	_player.focus_changed.emit(_player.focus_target)
	GameState.save_profile()


func _open_pause() -> void:
	if _overlay != null:
		return
	var menu = PauseScene.instantiate()
	menu.resume_requested.connect(_close_overlay)
	menu.profile_requested.connect(_open_profile)
	menu.settings_requested.connect(_open_settings)
	menu.exit_requested.connect(_exit_to_menu)
	_set_overlay(menu, true)


func _back_to_pause() -> void:
	var menu = PauseScene.instantiate()
	menu.resume_requested.connect(_close_overlay)
	menu.profile_requested.connect(_open_profile)
	menu.settings_requested.connect(_open_settings)
	menu.exit_requested.connect(_exit_to_menu)
	_set_overlay(menu, true)


func _open_profile() -> void:
	var panel = ProfileScene.instantiate()
	panel.closed.connect(_back_to_pause)
	_set_overlay(panel, true)


func _open_settings() -> void:
	var screen = SettingsScene.instantiate()
	screen.closed.connect(_back_to_pause)
	_set_overlay(screen, true)


func _open_catalog(kind: String) -> void:
	var panel = CatalogScene.instantiate()
	panel.kind = kind
	panel.closed.connect(_close_overlay)
	_set_overlay(panel, false)


func _exit_to_menu() -> void:
	GameState.end_session()
	get_tree().paused = false
	get_tree().change_scene_to_file(MENU_SCENE)
