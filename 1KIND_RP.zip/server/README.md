# Серверная часть 1KIND RP (заготовка)

**Статус: онлайн НЕ реализован.** Клиент игры (версия 0.1.0) работает полностью офлайн
и к этому серверу не подключается. Папка `server/` — отправная точка для будущего онлайна.

## Что здесь
- `docker-compose.yml` — Nakama + PostgreSQL для разработки.
- `modules/vanburg_match.lua` — каркас авторитетного матча на 50 игроков (не подключён, содержит TODO).

## План перехода на онлайн
1. Поднять сервер: `docker compose up -d` (нужен компьютер или VPS с Docker).
2. Добавить в проект клиент Nakama для Godot 4 (https://github.com/heroiclabs/nakama-godot)
   в папку `addons/` и подключить его **только** в `scripts/systems/network_service.gd`.
3. Серверная авторизация: заменить локальные вызовы `AccountManager.login/register`
   вызовами `NetworkService.authenticate(...)` (email/пароль или device id через Nakama).
4. Профиль: перенести `GameState.save_profile/load_profile` в Nakama Storage (данные в PostgreSQL).
5. Синхронизация игроков: `NetworkService.join_world()` + отправка позиции (`send_player_state`),
   создание «призраков» других игроков в мире Ванбург.
6. Чат: канал Nakama + панель чата в HUD.
7. Перед публикацией: HTTPS/WSS, свои пароли и ключи (в `docker-compose.yml` пароли только для разработки),
   разрешение `INTERNET` в Android export preset (сейчас выключено).
