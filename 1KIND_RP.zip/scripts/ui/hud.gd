extends Control
## Игровой HUD: профиль и опыт (слева сверху), баланс (справа сверху),
## местоположение, подсказка взаимодействия (снизу) и всплывающие уведомления.

signal inventory_pressed

const UiKit = preload("res://scripts/ui/ui_kit.gd")

var _name_label: Label
var _level_label: Label
var _xp_bar: ProgressBar
var _balance_label: Label
var _bank_label: Label
var _health_bar: ProgressBar
var _hunger_bar: ProgressBar
var _thirst_bar: ProgressBar
var _zone_label: Label
var _prompt_panel: PanelContainer
var _prompt_title: Label
var _prompt_hint: Label
var _toast_panel: PanelContainer
var _toast_label: Label
var _fps_label: Label
var _toast_tween: Tween


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_build_profile_box()
	_build_balance_box()
	_build_stats_box()
	_build_buttons()
	_build_prompt()
	_build_toast()
	_fps_label = UiKit.make_label("", 18, UiKit.COLOR_MUTED)
	_place(_fps_label, 0.5, 0.0, 0.0, 6.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	add_child(_fps_label)

	GameState.balance_changed.connect(_on_balance_changed)
	GameState.xp_changed.connect(_on_xp_changed)
	GameState.notification.connect(show_toast)
	GameState.stats_changed.connect(_on_stats_changed)
	_on_stats_changed()
	_name_label.text = GameState.nickname
	_on_balance_changed(GameState.balance)
	_on_xp_changed(GameState.level, GameState.xp, GameState.xp_needed(GameState.level))


func _place(c: Control, ax: float, ay: float, ox: float, oy: float, gh: int, gv: int) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_right = ox
	c.offset_top = oy
	c.offset_bottom = oy
	c.grow_horizontal = gh
	c.grow_vertical = gv


func _build_profile_box() -> void:
	var panel := UiKit.make_panel()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 0.0, 0.0, 16.0, 14.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(panel)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	panel.add_child(hb)
	hb.add_child(UiKit.make_icon("user", 60))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 2)
	hb.add_child(vb)
	_name_label = UiKit.make_label("", 26, UiKit.COLOR_GOLD)
	vb.add_child(_name_label)
	_level_label = UiKit.make_label("Уровень 1", 19, UiKit.COLOR_TEXT)
	vb.add_child(_level_label)
	_xp_bar = ProgressBar.new()
	_xp_bar.custom_minimum_size = Vector2(210, 14)
	_xp_bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = UiKit.COLOR_NAVY
	bg.set_corner_radius_all(7)
	var fg := StyleBoxFlat.new()
	fg.bg_color = UiKit.COLOR_GOLD
	fg.set_corner_radius_all(7)
	_xp_bar.add_theme_stylebox_override("background", bg)
	_xp_bar.add_theme_stylebox_override("fill", fg)
	vb.add_child(_xp_bar)
	_zone_label = UiKit.make_label("", 20, UiKit.COLOR_TEXT)
	_zone_label.add_theme_color_override("font_outline_color", UiKit.COLOR_NAVY)
	_zone_label.add_theme_constant_override("outline_size", 6)
	_place(_zone_label, 0.0, 0.0, 22.0, 112.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(_zone_label)


func _build_balance_box() -> void:
	var panel := UiKit.make_panel()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 1.0, 0.0, -16.0, 14.0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
	add_child(panel)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 10)
	panel.add_child(hb)
	hb.add_child(UiKit.make_icon("money", 44))
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 0)
	hb.add_child(vb)
	_balance_label = UiKit.make_label("0", 28, UiKit.COLOR_GOLD)
	vb.add_child(_balance_label)
	_bank_label = UiKit.make_label("", 18, UiKit.COLOR_MUTED)
	vb.add_child(_bank_label)


func _make_stat_bar(color: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(150, 12)
	bar.max_value = 100.0
	bar.show_percentage = false
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.04, 0.08, 0.18, 0.7)
	bg.set_corner_radius_all(6)
	var fg := StyleBoxFlat.new()
	fg.bg_color = color
	fg.set_corner_radius_all(6)
	bar.add_theme_stylebox_override("background", bg)
	bar.add_theme_stylebox_override("fill", fg)
	return bar


func _build_stats_box() -> void:
	var panel := UiKit.make_panel()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(panel, 0.0, 0.0, 16.0, 150.0, Control.GROW_DIRECTION_END, Control.GROW_DIRECTION_END)
	add_child(panel)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 10)
	grid.add_theme_constant_override("v_separation", 4)
	panel.add_child(grid)
	_health_bar = _make_stat_bar(Color("ff5a5f"))
	_hunger_bar = _make_stat_bar(Color("ffbe28"))
	_thirst_bar = _make_stat_bar(Color("1e90ff"))
	for row in [["Здоровье", _health_bar], ["Голод", _hunger_bar], ["Жажда", _thirst_bar]]:
		var lab := UiKit.make_label(String(row[0]), 16, UiKit.COLOR_MUTED)
		grid.add_child(lab)
		var bar: ProgressBar = row[1]
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		grid.add_child(bar)


func _build_buttons() -> void:
	var inv := UiKit.make_button("Инвентарь", "blue", Vector2(200, 56), 22)
	_place(inv, 1.0, 0.0, -16.0, 112.0, Control.GROW_DIRECTION_BEGIN, Control.GROW_DIRECTION_END)
	inv.pressed.connect(func() -> void: inventory_pressed.emit())
	add_child(inv)


func _on_stats_changed() -> void:
	_health_bar.value = GameState.health
	_hunger_bar.value = GameState.hunger
	_thirst_bar.value = GameState.thirst


func _build_prompt() -> void:
	_prompt_panel = UiKit.make_panel()
	_prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_prompt_panel, 0.5, 1.0, 0.0, -34.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_BEGIN)
	_prompt_panel.visible = false
	add_child(_prompt_panel)
	var vb := VBoxContainer.new()
	_prompt_panel.add_child(vb)
	_prompt_title = UiKit.make_label("", 26, UiKit.COLOR_GOLD)
	_prompt_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_prompt_title)
	_prompt_hint = UiKit.make_label("", 20, UiKit.COLOR_TEXT)
	_prompt_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(_prompt_hint)


func _build_toast() -> void:
	_toast_panel = UiKit.make_panel()
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_place(_toast_panel, 0.5, 0.0, 0.0, 84.0, Control.GROW_DIRECTION_BOTH, Control.GROW_DIRECTION_END)
	_toast_panel.modulate.a = 0.0
	add_child(_toast_panel)
	_toast_label = UiKit.make_label("", 24, UiKit.COLOR_TEXT)
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_panel.add_child(_toast_label)


func set_zone(text: String) -> void:
	_zone_label.text = text


func set_prompt(title: String, hint: String) -> void:
	if title == "":
		_prompt_panel.visible = false
		return
	_prompt_title.text = title
	_prompt_hint.text = hint
	_prompt_panel.visible = true


func show_toast(text: String) -> void:
	_toast_label.text = text
	if _toast_tween != null:
		_toast_tween.kill()
	_toast_panel.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(2.4)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.6)


func _on_balance_changed(value: int) -> void:
	_balance_label.text = GameState.fmt_money(value)
	_bank_label.text = "Счёт: %s" % GameState.fmt_money(GameState.bank)


func _on_xp_changed(level: int, xp: int, needed: int) -> void:
	_level_label.text = "Уровень %d" % level
	_xp_bar.max_value = float(needed)
	_xp_bar.value = float(xp)


func _process(_delta: float) -> void:
	_fps_label.visible = GameSettings.show_fps
	if GameSettings.show_fps:
		_fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
