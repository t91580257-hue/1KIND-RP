extends Control
## Сенсорное управление: виртуальный джойстик (слева), свайп камеры (справа),
## кнопки прыжка, бега, действия и меню. Обработка мультитача выполняется вручную
## по индексу касания, поэтому можно одновременно держать джойстик и жать кнопки.
## На ПК (без сенсорного экрана) мышь работает как одно касание — для проверки.

signal jump_pressed
signal interact_pressed
signal menu_pressed

const MOUSE_INDEX := 9999

var move_vector: Vector2 = Vector2.ZERO
var run_active: bool = false
var enabled: bool = true : set = set_enabled

var _roles: Dictionary = {}          # индекс касания -> "joy" | "cam" | "btn:<имя>"
var _joy_index: int = -1
var _joy_center: Vector2 = Vector2.ZERO
var _joy_pos: Vector2 = Vector2.ZERO
var _cam_accum: Vector2 = Vector2.ZERO
var _pressed: Dictionary = {}        # имя кнопки -> true, пока нажата
var _buttons: Dictionary = {}        # имя -> {"c": Vector2, "r": float}
var _joy_idle: Vector2 = Vector2.ZERO
var _joy_radius: float = 90.0
var _unit: float = 1.0
var _use_mouse: bool = false
var _icon_interact: Texture2D
var _icon_menu: Texture2D


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_use_mouse = not DisplayServer.is_touchscreen_available()
	_icon_interact = load("res://assets/ui/icons/location.png") as Texture2D
	_icon_menu = load("res://assets/ui/icons/settings.png") as Texture2D
	resized.connect(_update_layout)
	GameSettings.settings_changed.connect(_update_layout)
	_update_layout()


func set_enabled(value: bool) -> void:
	enabled = value
	if not enabled:
		_release_all()
	visible = enabled


func consume_camera_delta() -> Vector2:
	var d := _cam_accum
	_cam_accum = Vector2.ZERO
	return d


func _release_all() -> void:
	_roles.clear()
	_pressed.clear()
	_joy_index = -1
	move_vector = Vector2.ZERO
	_joy_pos = _joy_center
	if GameSettings.hold_to_run:
		run_active = false
	queue_redraw()


func _update_layout() -> void:
	var sz := size
	if sz.x < 10.0 or sz.y < 10.0:
		sz = get_viewport_rect().size
	_unit = clampf(minf(sz.x, sz.y) / 720.0, 0.6, 1.6) * GameSettings.touch_scale
	var u := _unit
	var margin := 36.0 * u
	_joy_radius = 92.0 * u
	_joy_idle = Vector2(margin + _joy_radius + 20.0 * u, sz.y - margin - _joy_radius)
	if _joy_index == -1:
		_joy_center = _joy_idle
		_joy_pos = _joy_idle
	var right := sz.x - margin
	var bottom := sz.y - margin
	_buttons = {
		"jump": {"c": Vector2(right - 62.0 * u, bottom - 70.0 * u), "r": 58.0 * u},
		"interact": {"c": Vector2(right - 190.0 * u, bottom - 56.0 * u), "r": 50.0 * u},
		"run": {"c": Vector2(right - 92.0 * u, bottom - 200.0 * u), "r": 44.0 * u},
		"menu": {"c": Vector2(right - 38.0 * u, margin + 30.0 * u), "r": 34.0 * u},
	}
	modulate = Color(1, 1, 1, GameSettings.touch_opacity)
	queue_redraw()


func _input(event: InputEvent) -> void:
	if not enabled or not is_visible_in_tree():
		return
	var st := event as InputEventScreenTouch
	if st != null:
		_on_touch(st.index, st.position, st.pressed)
		return
	var sd := event as InputEventScreenDrag
	if sd != null:
		_on_drag(sd.index, sd.position, sd.relative)
		return
	if not _use_mouse:
		return
	var mb := event as InputEventMouseButton
	if mb != null and mb.button_index == MOUSE_BUTTON_LEFT:
		_on_touch(MOUSE_INDEX, mb.position, mb.pressed)
		return
	var mm := event as InputEventMouseMotion
	if mm != null and _roles.has(MOUSE_INDEX):
		_on_drag(MOUSE_INDEX, mm.position, mm.relative)


func _button_at(p: Vector2) -> String:
	for key in _buttons.keys():
		var b: Dictionary = _buttons[key]
		var c: Vector2 = b["c"]
		var r: float = b["r"]
		if p.distance_to(c) <= r * 1.25:
			return String(key)
	return ""


func _on_touch(index: int, pos: Vector2, pressed: bool) -> void:
	if pressed:
		if _roles.has(index):
			return
		var btn := _button_at(pos)
		if btn != "":
			_roles[index] = "btn:" + btn
			_press_button(btn)
		elif pos.x < size.x * 0.45 and pos.y > size.y * 0.2 and _joy_index == -1:
			_roles[index] = "joy"
			_joy_index = index
			_joy_center = pos
			_joy_pos = pos
			move_vector = Vector2.ZERO
		else:
			_roles[index] = "cam"
		queue_redraw()
	else:
		if not _roles.has(index):
			return
		var role: String = _roles[index]
		_roles.erase(index)
		if role == "joy":
			_joy_index = -1
			move_vector = Vector2.ZERO
			_joy_center = _joy_idle
			_joy_pos = _joy_idle
		elif role.begins_with("btn:"):
			_release_button(role.substr(4))
		queue_redraw()


func _on_drag(index: int, pos: Vector2, relative: Vector2) -> void:
	if not _roles.has(index):
		return
	var role: String = _roles[index]
	if role == "joy":
		var offset := pos - _joy_center
		if offset.length() > _joy_radius:
			offset = offset.normalized() * _joy_radius
		_joy_pos = _joy_center + offset
		var v := offset / _joy_radius
		if v.length() < 0.12:
			v = Vector2.ZERO
		move_vector = v
		queue_redraw()
	elif role == "cam":
		_cam_accum += relative


func _press_button(btn: String) -> void:
	_pressed[btn] = true
	match btn:
		"jump":
			jump_pressed.emit()
		"interact":
			interact_pressed.emit()
		"menu":
			menu_pressed.emit()
		"run":
			if GameSettings.hold_to_run:
				run_active = true
			else:
				run_active = not run_active


func _release_button(btn: String) -> void:
	_pressed.erase(btn)
	if btn == "run" and GameSettings.hold_to_run:
		run_active = false


func _draw() -> void:
	var u := _unit
	var font := ThemeDB.fallback_font
	# Джойстик.
	draw_circle(_joy_center, _joy_radius, Color(0.04, 0.1, 0.25, 0.45))
	draw_arc(_joy_center, _joy_radius, 0.0, TAU, 48, Color(1.0, 0.75, 0.16, 0.9), 3.0 * u)
	var knob_r := 42.0 * u
	draw_circle(_joy_pos, knob_r, Color(0.12, 0.5, 1.0, 0.85))
	draw_arc(_joy_pos, knob_r, 0.0, TAU, 32, Color(1.0, 0.75, 0.16, 1.0), 3.0 * u)
	# Кнопки.
	for key in _buttons.keys():
		var name_btn := String(key)
		var b: Dictionary = _buttons[key]
		var c: Vector2 = b["c"]
		var r: float = b["r"]
		var down := _pressed.has(name_btn)
		var active := name_btn == "run" and run_active
		var fill := Color(0.04, 0.1, 0.25, 0.65)
		if name_btn == "jump":
			fill = Color(0.1, 0.45, 0.95, 0.9)
		elif active:
			fill = Color(1.0, 0.75, 0.16, 0.95)
		if down:
			fill = fill.lightened(0.25)
		draw_circle(c, r, fill)
		draw_arc(c, r, 0.0, TAU, 40, Color(1.0, 0.75, 0.16, 1.0), 3.0 * u)
		match name_btn:
			"jump":
				_draw_chevrons(c, r, 1, Color.WHITE, u)
			"run":
				var col := Color(0.04, 0.1, 0.25) if active else Color.WHITE
				_draw_chevrons(c, r * 0.9, 2, col, u)
			"interact":
				if _icon_interact != null:
					draw_texture_rect(_icon_interact, Rect2(c - Vector2(r, r) * 0.95, Vector2(r, r) * 1.9), false)
			"menu":
				if _icon_menu != null:
					draw_texture_rect(_icon_menu, Rect2(c - Vector2(r, r) * 1.05, Vector2(r, r) * 2.1), false)
		var caption := ""
		match name_btn:
			"jump":
				caption = "ПРЫЖОК"
			"run":
				caption = "БЕГ"
			"interact":
				caption = "ДЕЙСТВИЕ"
		if caption != "" and font != null:
			var fs := int(16.0 * u)
			draw_string(font, c + Vector2(-r, r + 18.0 * u), caption, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, fs, Color(1, 1, 1, 0.95))


## Рисует шевроны «вверх» (для прыжка — один, для бега — два).
func _draw_chevrons(c: Vector2, r: float, count: int, col: Color, u: float) -> void:
	var w := r * 0.42
	var h := r * 0.28
	var gap := r * 0.3
	var total := gap * float(count - 1)
	for i in range(count):
		var y := c.y + total * 0.5 - gap * float(i) + h * 0.3
		var pts := PackedVector2Array([Vector2(c.x - w, y), Vector2(c.x, y - h), Vector2(c.x + w, y)])
		draw_polyline(pts, col, 5.0 * u, true)
