extends Control
## Меню паузы в игре: продолжить, профиль, настройки, выход в главное меню.

signal resume_requested
signal profile_requested
signal settings_requested
signal exit_requested

const UiKit = preload("res://scripts/ui/ui_kit.gd")


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	vb.add_child(UiKit.make_title("Пауза", 42))

	var resume := UiKit.make_button("Продолжить", "gold", Vector2(380, 68))
	resume.pressed.connect(func() -> void: resume_requested.emit())
	vb.add_child(resume)
	var profile := UiKit.make_button("Профиль", "blue", Vector2(380, 68))
	profile.pressed.connect(func() -> void: profile_requested.emit())
	vb.add_child(profile)
	var settings := UiKit.make_button("Настройки", "blue", Vector2(380, 68))
	settings.pressed.connect(func() -> void: settings_requested.emit())
	vb.add_child(settings)
	var exit_btn := UiKit.make_button("В главное меню", "dark", Vector2(380, 68))
	exit_btn.pressed.connect(func() -> void: exit_requested.emit())
	vb.add_child(exit_btn)
	var note := UiKit.make_label("Прогресс сохраняется автоматически", 18, UiKit.COLOR_MUTED)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(note)
