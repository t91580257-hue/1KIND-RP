extends Control
## Универсальная панель каталога: магазин, автосалон, агентство недвижимости, центр занятости.
## Использует Catalogs и методы GameState (buy / work). Задать kind до добавления в дерево.

signal closed

const UiKit = preload("res://scripts/ui/ui_kit.gd")
const Catalogs = preload("res://scripts/systems/catalogs.gd")

const TITLES: Dictionary = {
	"shop": "Магазин 24/7",
	"property": "Агентство «Золотой ключ»",
	"jobs": "Центр занятости",
}
const NOTES: Dictionary = {
	"shop": "Оплата: наличные, затем банковская карта. Товары попадают в инвентарь.",
	"property": "Покупка записывается в профиль. Заселение появится в будущих версиях.",
	"jobs": "Зарплата поступает на банковский счёт за вычетом налога 13%. Высокие уровни открывают лучшие смены.",
}

var kind: String = "shop"

var _rows: Dictionary = {}          # id -> {"button": Button, "desc": Label, "base_desc": String}
var _balance_label: Label
var _timer: float = 0.0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(UiKit.make_dim())
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var panel := UiKit.make_panel()
	panel.custom_minimum_size = Vector2(840, 560)
	center.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 10)
	panel.add_child(root)

	root.add_child(UiKit.make_title(String(TITLES.get(kind, "Каталог")), 36))
	_balance_label = UiKit.make_label("", 26, UiKit.COLOR_GOLD)
	_balance_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(_balance_label)
	var note := UiKit.make_label(String(NOTES.get(kind, "")), 18, UiKit.COLOR_MUTED)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note.custom_minimum_size = Vector2(700, 0)
	root.add_child(note)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.custom_minimum_size = Vector2(0, 300)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	scroll.add_child(list)

	var catalog := Catalogs.get_catalog(kind)
	for id in catalog.keys():
		_add_row(list, String(id), catalog[id])

	var close := UiKit.make_button("Закрыть", "dark", Vector2(300, 62))
	close.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	close.pressed.connect(func() -> void: closed.emit())
	root.add_child(close)

	GameState.balance_changed.connect(_on_balance_changed)
	GameState.inventory_changed.connect(_update_states)
	_update_states()


func _on_balance_changed(_value: int) -> void:
	_update_states()


func _add_row(parent: Control, id: String, entry: Dictionary) -> void:
	var row_panel := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.14, 0.3, 0.8)
	sb.border_color = UiKit.COLOR_BLUE
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 8
	sb.content_margin_bottom = 8
	row_panel.add_theme_stylebox_override("panel", sb)
	parent.add_child(row_panel)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	row_panel.add_child(row)
	row.add_child(UiKit.make_icon(String(entry.get("icon", "star")), 56))

	var info := VBoxContainer.new()
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(info)
	info.add_child(UiKit.make_label(String(entry["name"]), 24, UiKit.COLOR_TEXT))
	var base_desc := String(entry.get("desc", ""))
	var desc := UiKit.make_label(base_desc, 18, UiKit.COLOR_MUTED)
	info.add_child(desc)

	var value_text := ""
	if kind == "jobs":
		value_text = "%s\n+%d опыта" % [GameState.fmt_money(int(entry["pay"])), int(entry["xp"])]
	else:
		value_text = GameState.fmt_money(int(entry["price"]))
	var value := UiKit.make_label(value_text, 22, UiKit.COLOR_GOLD)
	value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	row.add_child(value)

	var btn := UiKit.make_button("Купить", "gold", Vector2(170, 56), 24)
	btn.pressed.connect(_on_action.bind(id))
	row.add_child(btn)
	_rows[id] = {"button": btn, "desc": desc, "base_desc": base_desc}


func _on_action(id: String) -> void:
	var result: Dictionary
	if kind == "jobs":
		result = GameState.work(id)
	else:
		result = GameState.buy(kind, id)
	GameState.notify(String(result["text"]))
	if not bool(result["ok"]):
		AudioManager.play_sfx("error")
	_update_states()


func _update_states() -> void:
	_balance_label.text = "Наличные: %s   ·   Счёт: %s" % [GameState.fmt_money(GameState.cash), GameState.fmt_money(GameState.bank)]
	var catalog := Catalogs.get_catalog(kind)
	for id in _rows.keys():
		var entry: Dictionary = catalog[id]
		var row: Dictionary = _rows[id]
		var btn: Button = row["button"]
		var desc: Label = row["desc"]
		var base_desc: String = row["base_desc"]
		match kind:
			"shop":
				var have := GameState.item_total(String(id))
				desc.text = base_desc if have == 0 else "%s  (у вас: %d)" % [base_desc, have]
				btn.text = "Купить"
				btn.disabled = GameState.total_money() < int(entry["price"])
			"property":
				var owned_p := GameState.owned_property.has(id)
				btn.text = "Куплено" if owned_p else "Купить"
				btn.disabled = owned_p or GameState.total_money() < int(entry["price"])
			"jobs":
				var need := int(entry["min_level"])
				var left := GameState.cooldown_left("job_" + String(id))
				if GameState.level < need:
					btn.text = "Ур. %d" % need
					btn.disabled = true
				elif left > 0.0:
					btn.text = "%d с" % int(ceil(left))
					btn.disabled = true
				else:
					btn.text = "Работать"
					btn.disabled = false


func _process(delta: float) -> void:
	if kind != "jobs":
		return
	_timer += delta
	if _timer >= 0.5:
		_timer = 0.0
		_update_states()
