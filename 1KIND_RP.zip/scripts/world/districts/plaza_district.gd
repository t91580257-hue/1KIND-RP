extends "res://scripts/world/districts/district.gd"
## Центральная площадь Ванбурга: фонтан с короной, лавочки, деревья,
## банкомат, информационный стенд, пешеходные переходы.

const Kit = preload("res://scripts/world/world_kit.gd")
const Layout = preload("res://scripts/world/city_layout.gd")


func build() -> void:
	name = "Plaza"
	_build_floor()
	_build_fountain()
	_build_crosswalks()
	_build_furniture()
	_build_atm(Vector3(12.0, 0, 12.0))
	_build_info_board(Vector3(-12.0, 0, -12.0))


func _yaw_toward(origin: Vector3, target: Vector3) -> float:
	var d := target - origin
	return rad_to_deg(atan2(d.x, d.z))


func _build_floor() -> void:
	var stone := Kit.tri_mat("stone", 4.0, Color(0.95, 0.92, 0.86))
	Kit.add_flat(self, 0.0, 0.0, Layout.PLAZA_HALF * 2.0, Layout.PLAZA_HALF * 2.0, 0.1, stone)
	Kit.add_cylinder(self, Vector3(0, 0.058, 0), 13.4, 0.116, Kit.color_mat(Color("ffbe28"), 0.4, 0.5), false, 48)
	Kit.add_cylinder(self, Vector3(0, 0.06, 0), 13.0, 0.12, Kit.tri_mat("sand", 3.0, Color(1.0, 0.95, 0.8)), false, 48)


func _build_fountain() -> void:
	var stone := Kit.tri_mat("stone", 2.0, Color(0.8, 0.82, 0.9))
	Kit.add_cylinder(self, Vector3(0, 0.35, 0), 5.5, 0.7, stone, true, 32)
	Kit.add_cylinder(self, Vector3(0, 0.36, 0), 5.0, 0.72, Kit.water_mat(), false, 32)
	Kit.add_cylinder(self, Vector3(0, 1.5, 0), 1.0, 3.0, stone, true, 16)
	Kit.add_cylinder(self, Vector3(0, 3.1, 0), 2.2, 0.4, stone, false, 24)
	Kit.add_cylinder(self, Vector3(0, 3.32, 0), 1.9, 0.1, Kit.water_mat(), false, 24)
	Kit.add_crown(self, Vector3(0, 3.4, 0), 1.7)
	Kit.add_interactable(self, Vector3(0, 0, 7.6), "fountain", "Фонтан Короны", "Бросить монету (1 VB)", 2.8)


func _build_crosswalks() -> void:
	var white := Kit.color_mat(Color(0.95, 0.95, 0.95), 0.9)
	for i in range(8):
		var o := -4.9 + 1.4 * float(i)
		Kit.add_box(self, Vector3(23.0, 0.056, o), Vector3(3.0, 0.012, 0.6), white, false)
		Kit.add_box(self, Vector3(-23.0, 0.056, o), Vector3(3.0, 0.012, 0.6), white, false)
		Kit.add_box(self, Vector3(o, 0.056, 23.0), Vector3(0.6, 0.012, 3.0), white, false)
		Kit.add_box(self, Vector3(o, 0.056, -23.0), Vector3(0.6, 0.012, 3.0), white, false)


func _build_furniture() -> void:
	# Лавочки по кругу лицом к фонтану.
	for k in range(8):
		var a := deg_to_rad(22.5 + 45.0 * float(k))
		var p := Vector3(cos(a) * 14.5, 0.1, sin(a) * 14.5)
		Kit.add_bench(self, p, _yaw_toward(p, Vector3.ZERO))
	# Деревья в кадках по углам.
	var planter := Kit.tri_mat("stone", 2.0, Color(0.85, 0.85, 0.9))
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var fx: float = sx
			var fz: float = sz
			var p := Vector3(fx * 16.5, 0, fz * 16.5)
			Kit.add_box(self, p + Vector3(0, 0.35, 0), Vector3(3.4, 0.7, 3.4), planter, true)
			Kit.add_tree(self, p + Vector3(0, 0.7, 0), 0.9, 0 if fx * fz > 0.0 else 2)
	# Фонари по краю площади.
	var lamp_spots: Array = [
		Vector3(18.5, 0, 10.0), Vector3(18.5, 0, -10.0), Vector3(-18.5, 0, 10.0), Vector3(-18.5, 0, -10.0),
		Vector3(10.0, 0, 18.5), Vector3(-10.0, 0, 18.5), Vector3(10.0, 0, -18.5), Vector3(-10.0, 0, -18.5),
	]
	for sp in lamp_spots:
		var pos: Vector3 = sp
		var d := Vector3.ZERO - pos
		Kit.add_lamp(self, pos + Vector3(0, 0.1, 0), rad_to_deg(atan2(-d.z, d.x)))
	# Кусты у фонтана.
	for k in range(6):
		var a2 := deg_to_rad(60.0 * float(k) + 10.0)
		Kit.add_bush(self, Vector3(cos(a2) * 9.5, 0.1, sin(a2) * 9.5), 1.1)


func _build_atm(p: Vector3) -> void:
	var root := Node3D.new()
	root.position = p
	root.rotation_degrees.y = _yaw_toward(p, Vector3.ZERO)
	add_child(root)
	var metal := Kit.color_mat(Color(0.08, 0.2, 0.45), 0.4, 0.6)
	Kit.add_box(root, Vector3(0, 1.15, 0), Vector3(1.4, 2.3, 1.0), metal, true)
	Kit.add_box(root, Vector3(0, 1.5, 0.52), Vector3(1.0, 0.7, 0.05), Kit.emissive_mat(Color(0.2, 0.6, 1.0), 1.0), false)
	Kit.add_box(root, Vector3(0, 0.95, 0.52), Vector3(0.7, 0.18, 0.05), Kit.color_mat(Color("ffbe28"), 0.4, 0.5), false)
	Kit.add_label(root, "БАНКОМАТ", Vector3(0, 2.6, 0.1), 0.006, Color("ffbe28"))
	var d := (Vector3.ZERO - p).normalized()
	Kit.add_interactable(self, p + d * 1.9, "atm", "Банкомат 1KIND", "Открыть банкомат", 2.4)


func _build_info_board(p: Vector3) -> void:
	var root := Node3D.new()
	root.position = p
	root.rotation_degrees.y = _yaw_toward(p, Vector3.ZERO)
	add_child(root)
	var metal := Kit.color_mat(Color(0.12, 0.2, 0.4), 0.5, 0.5)
	Kit.add_cylinder(root, Vector3(-1.6, 1.3, 0), 0.07, 2.6, metal, true, 8)
	Kit.add_cylinder(root, Vector3(1.6, 1.3, 0), 0.07, 2.6, metal, true, 8)
	Kit.add_box(root, Vector3(0, 2.0, 0), Vector3(4.0, 2.0, 0.15), Kit.color_mat(Color(0.05, 0.12, 0.3), 0.5), true)
	Kit.add_box(root, Vector3(0, 2.0, 0.08), Vector3(3.8, 1.8, 0.02), Kit.emissive_mat(Color(0.1, 0.25, 0.55), 0.5), false)
	Kit.add_label(root, "ДОБРО ПОЖАЛОВАТЬ\nВ ВАНБУРГ", Vector3(0, 2.0, 0.12), 0.007, Color("ffbe28"))
	var d := (Vector3.ZERO - p).normalized()
	Kit.add_interactable(self, p + d * 2.0, "info_board", "Информационный стенд", "Прочитать", 2.4)
