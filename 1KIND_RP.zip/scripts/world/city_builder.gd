extends RefCounted
## Собирает город Ванбург из модульных районов. Чтобы добавить новый район,
## создайте скрипт на основе districts/district.gd и добавьте его в DISTRICTS.

const Kit = preload("res://scripts/world/world_kit.gd")
const Layout = preload("res://scripts/world/city_layout.gd")

const DISTRICTS: Array = [
	preload("res://scripts/world/districts/streets_district.gd"),
	preload("res://scripts/world/districts/plaza_district.gd"),
	preload("res://scripts/world/districts/civic_district.gd"),
	preload("res://scripts/world/districts/commercial_district.gd"),
	preload("res://scripts/world/districts/highrise_district.gd"),
	preload("res://scripts/world/districts/residential_district.gd"),
	preload("res://scripts/world/districts/expansion_district.gd"),
	preload("res://scripts/world/districts/outskirts_district.gd"),
]


## Строит землю и все районы внутри root. Возвращает {"spawn": Vector3}.
static func build(root: Node3D) -> Dictionary:
	Kit.add_ground(root)
	for district_script in DISTRICTS:
		var d: Node3D = district_script.new()
		root.add_child(d)
		d.call("build")
	return {"spawn": Layout.SPAWN}


## Небо, свет и туман в тёплых «закатных» тонах. Возвращает солнце.
static func add_atmosphere(root: Node3D) -> DirectionalLight3D:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.10, 0.24, 0.52)
	sky_mat.sky_horizon_color = Color(0.96, 0.66, 0.42)
	sky_mat.ground_horizon_color = Color(0.96, 0.66, 0.42)
	sky_mat.ground_bottom_color = Color(0.08, 0.12, 0.22)
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 1.0
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.86, 0.68, 0.55)
	env.fog_density = 0.00055
	var we := WorldEnvironment.new()
	we.environment = env
	root.add_child(we)

	var sun := DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.86, 0.66)
	sun.light_energy = 1.25
	sun.rotation_degrees = Vector3(-38.0, -55.0, 0.0)
	root.add_child(sun)
	return sun
