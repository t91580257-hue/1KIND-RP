extends Node3D
## Стилизованная модель персонажа из отдельных частей тела (без внешних моделей)
## и процедурная анимация ходьбы/бега/прыжка. Лицом модель смотрит в -Z.

const Kit = preload("res://scripts/world/world_kit.gd")

var _left_arm: Node3D
var _right_arm: Node3D
var _left_leg: Node3D
var _right_leg: Node3D
var _body: Node3D
var _phase: float = 0.0


func _ready() -> void:
	var skin := Kit.color_mat(Color(0.96, 0.78, 0.62), 0.8)
	var shirt := Kit.color_mat(Color(0.12, 0.45, 0.95), 0.7)
	var pants := Kit.color_mat(Color(0.08, 0.14, 0.3), 0.8)
	var shoes := Kit.color_mat(Color("ffbe28"), 0.5, 0.2)
	var hair := Kit.color_mat(Color(0.2, 0.12, 0.08), 0.9)
	var dark := Kit.color_mat(Color(0.05, 0.05, 0.08), 0.5)
	var gold := Kit.color_mat(Color("ffbe28"), 0.4, 0.6)

	_body = Node3D.new()
	_body.name = "Body"
	add_child(_body)

	# Торс и эмблема-корона на груди.
	Kit.add_box(_body, Vector3(0, 1.15, 0), Vector3(0.52, 0.64, 0.28), shirt, false)
	Kit.add_box(_body, Vector3(0, 1.2, -0.145), Vector3(0.16, 0.1, 0.02), gold, false)
	Kit.add_box(_body, Vector3(0, 0.84, 0), Vector3(0.54, 0.1, 0.3), gold, false)
	# Голова, волосы, глаза.
	Kit.add_sphere(_body, Vector3(0, 1.66, 0), 0.19, skin)
	Kit.add_box(_body, Vector3(0, 1.82, 0.02), Vector3(0.38, 0.14, 0.38), hair, false)
	Kit.add_box(_body, Vector3(-0.07, 1.68, -0.17), Vector3(0.05, 0.06, 0.02), dark, false)
	Kit.add_box(_body, Vector3(0.07, 1.68, -0.17), Vector3(0.05, 0.06, 0.02), dark, false)
	# Руки и ноги — на шарнирах (pivot) в плечах и бёдрах.
	_left_arm = _make_limb(Vector3(-0.35, 1.4, 0), Vector3(0.14, 0.58, 0.14), shirt, skin, 0.46)
	_right_arm = _make_limb(Vector3(0.35, 1.4, 0), Vector3(0.14, 0.58, 0.14), shirt, skin, 0.46)
	_left_leg = _make_limb(Vector3(-0.14, 0.82, 0), Vector3(0.18, 0.82, 0.2), pants, shoes, 0.12)
	_right_leg = _make_limb(Vector3(0.14, 0.82, 0), Vector3(0.18, 0.82, 0.2), pants, shoes, 0.12)


## Создаёт конечность: шарнир в точке pivot_pos, основная часть вниз и «кисть/ботинок» внизу.
func _make_limb(pivot_pos: Vector3, size: Vector3, main_mat: Material, end_mat: Material, end_h: float) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = pivot_pos
	_body.add_child(pivot)
	Kit.add_box(pivot, Vector3(0, -(size.y - end_h) * 0.5, 0), Vector3(size.x, size.y - end_h, size.z), main_mat, false)
	Kit.add_box(pivot, Vector3(0, -size.y + end_h * 0.5, 0), Vector3(size.x * 1.05, end_h, size.z * 1.15), end_mat, false)
	return pivot


## Вызывается каждый физический кадр из Player.
func animate(horizontal_speed: float, running: bool, on_floor: bool, delta: float) -> void:
	if not on_floor:
		_left_arm.rotation.x = lerpf(_left_arm.rotation.x, -2.4, 10.0 * delta)
		_right_arm.rotation.x = lerpf(_right_arm.rotation.x, -2.4, 10.0 * delta)
		_left_leg.rotation.x = lerpf(_left_leg.rotation.x, 0.5, 10.0 * delta)
		_right_leg.rotation.x = lerpf(_right_leg.rotation.x, -0.4, 10.0 * delta)
		return
	if horizontal_speed > 0.3:
		var freq := 11.0 if running else 7.5
		var amp := 0.95 if running else 0.6
		_phase += delta * freq * clampf(horizontal_speed / 4.0, 0.6, 1.6)
		var s := sin(_phase) * amp
		_left_leg.rotation.x = s
		_right_leg.rotation.x = -s
		_left_arm.rotation.x = -s * 0.9
		_right_arm.rotation.x = s * 0.9
		_body.position.y = absf(sin(_phase)) * (0.06 if running else 0.03)
		_body.rotation.x = -0.12 if running else 0.0
	else:
		_phase += delta * 2.0
		for limb in [_left_leg, _right_leg, _left_arm, _right_arm]:
			var node: Node3D = limb
			node.rotation.x = lerpf(node.rotation.x, 0.0, 10.0 * delta)
		_body.position.y = sin(_phase) * 0.008
		_body.rotation.x = lerpf(_body.rotation.x, 0.0, 8.0 * delta)
