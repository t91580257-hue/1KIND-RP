extends Node
## Точка входа для БУДУЩЕГО онлайн-режима (автозагрузка NetworkService).
##
## СТАТУС: онлайн НЕ реализован. Первая версия работает полностью офлайн,
## мультиплеер, серверная авторизация и сетевой чат пока отсутствуют.
##
## Этот скрипт задаёт единый интерфейс, через который игра будет общаться с сервером.
## Когда появится клиент Nakama (https://heroiclabs.com/docs/nakama/client-libraries/),
## его нужно подключить ТОЛЬКО здесь, не меняя меню, HUD и игровой мир:
##   - authenticate()        -> authenticate_email_async / authenticate_device_async
##   - join_world()          -> создание/вход в общий матч (до 50 игроков)
##   - send_player_state()   -> отправка позиции/анимации (match data)
##   - send_chat_message()   -> канал чата
##   - load_profile()/save_profile() -> Nakama Storage (PostgreSQL)
## Серверная часть (docker-compose Nakama + PostgreSQL) описана в папке server/.

signal connection_state_changed(online: bool)

const MAX_PLAYERS := 50
const ONLINE_IMPLEMENTED := false

var online: bool = false


func is_online() -> bool:
	return online


func mode_title() -> String:
	if ONLINE_IMPLEMENTED and online:
		return "Онлайн"
	return "Офлайн (локальная игра)"


## Серверная авторизация. Пока недоступна — возвращает честную ошибку.
func authenticate(_nick: String, _password: String) -> Dictionary:
	return {"ok": false, "error": "Онлайн-режим ещё не реализован: сервер Nakama не подключён."}


func join_world() -> Dictionary:
	return {"ok": false, "error": "Мультиплеер ещё не реализован."}


func send_chat_message(_text: String) -> bool:
	return false


func send_player_state(_position: Vector3, _yaw: float, _anim_state: int) -> void:
	# Ничего не отправляем: сервера нет. Хук оставлен для будущей синхронизации.
	return
