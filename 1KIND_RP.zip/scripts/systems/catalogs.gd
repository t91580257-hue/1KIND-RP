extends RefCounted
## Каталоги игровых данных: товары, автомобили, недвижимость, работы.
## Все данные описаны в одном месте, чтобы позже их можно было заменить
## данными с сервера (Nakama storage) без переписывания интерфейса.

## kind: food | drink | misc | key | quest | case
const ITEMS: Dictionary = {
	"water": {"name": "Бутылка воды", "desc": "Утоляет жажду.", "price": 60, "icon": "health", "kind": "drink", "weight": 0.5, "stack": 10, "thirst": 35.0},
	"cola": {"name": "Лимонад", "desc": "Холодный газированный напиток.", "price": 90, "icon": "shop", "kind": "drink", "weight": 0.5, "stack": 10, "thirst": 25.0, "hunger": 3.0},
	"sandwich": {"name": "Сэндвич", "desc": "Сытный перекус.", "price": 150, "icon": "shop", "kind": "food", "weight": 0.3, "stack": 10, "hunger": 30.0},
	"burger": {"name": "Бургер", "desc": "Горячий бургер из кафе.", "price": 290, "icon": "shop", "kind": "food", "weight": 0.4, "stack": 10, "hunger": 45.0, "thirst": -5.0},
	"medkit": {"name": "Аптечка", "desc": "Восстанавливает 40 здоровья.", "price": 900, "icon": "health", "kind": "misc", "weight": 0.8, "stack": 5, "heal": 40.0},
	"phone_case": {"name": "Чехол для телефона", "desc": "Сине-золотой, с короной.", "price": 450, "icon": "phone", "kind": "misc", "weight": 0.1, "stack": 5},
	"map_vanburg": {"name": "Карта Ванбурга", "desc": "Бумажная карта города.", "price": 250, "icon": "map", "kind": "misc", "weight": 0.1, "stack": 1},
	"gold_badge": {"name": "Золотой значок", "desc": "Знак отличия жителя Ванбурга.", "price": 3000, "icon": "star", "kind": "misc", "weight": 0.1, "stack": 1},
	"case_basic": {"name": "Обычный кейс", "desc": "Откройте: случайная награда в ₽ или предметы.", "price": 1500, "icon": "premium", "kind": "case", "weight": 1.0, "stack": 20},
}

## Предметы, которые нельзя купить в магазине 24/7 (кейсы выдаются заданиями, ключи — покупкой).
const SHOP_ITEMS: Array = ["water", "cola", "sandwich", "burger", "medkit", "phone_case", "map_vanburg", "gold_badge", "case_basic"]

## Автосалоны: id -> название и список автомобилей (по 5 в каждом).
const DEALERS: Dictionary = {
	"econ": {"name": "Автосалон «Ванби-Авто» (эконом)", "cars": ["vanbi", "step", "kombi", "tropa", "master"]},
	"mid": {"name": "Автосалон «Корона-Мотор» (средний класс)", "cars": ["korona_s", "putnik", "gorets", "strela", "briz"]},
	"premium": {"name": "Автосалон «Золотой Руль» (премиум)", "cars": ["regent", "titan", "strela_gt", "faeton", "molniya"]},
}

## shape — тип процедурной 3D-модели (см. car_factory.gd). Скорость в км/ч, разгон 0-100 в секундах,
## handling 1..10, fuel — л/100 км, tank — объём бака в литрах.
const CARS: Dictionary = {
	"vanbi": {"name": "«Ванби» городской хэтчбек", "desc": "Компактный и экономичный.", "price": 450000, "icon": "car", "shape": "hatch", "dealer": "econ", "top_speed": 150, "accel": 14.5, "handling": 6, "fuel": 5.8, "tank": 40, "colors": ["d94b3f", "f2f2f2", "2f6fd6", "f0b429"]},
	"step": {"name": "«Степь» седан", "desc": "Простой надёжный седан.", "price": 620000, "icon": "car", "shape": "sedan", "dealer": "econ", "top_speed": 170, "accel": 12.8, "handling": 5, "fuel": 7.2, "tank": 50, "colors": ["8a8f98", "1d1f24", "f2f2f2", "5a7d3c"]},
	"kombi": {"name": "«Комби» компактвэн", "desc": "Просторный семейный фургон.", "price": 780000, "icon": "car", "shape": "van", "dealer": "econ", "top_speed": 160, "accel": 14.0, "handling": 4, "fuel": 8.4, "tank": 55, "colors": ["f2f2f2", "3a6ea5", "c9a227", "7b4a9e"]},
	"tropa": {"name": "«Тропа» кроссовер", "desc": "Городской кроссовер.", "price": 890000, "icon": "car", "shape": "crossover", "dealer": "econ", "top_speed": 175, "accel": 11.8, "handling": 5, "fuel": 8.1, "tank": 55, "colors": ["b5651d", "1d1f24", "e8e8e8", "2b7a6f"]},
	"master": {"name": "«Мастер» пикап", "desc": "Рабочая лошадка с кузовом.", "price": 950000, "icon": "car", "shape": "pickup", "dealer": "econ", "top_speed": 165, "accel": 12.5, "handling": 4, "fuel": 10.2, "tank": 70, "colors": ["c0392b", "34495e", "f2f2f2", "27ae60"]},

	"korona_s": {"name": "«Корона S» седан", "desc": "Комфортный седан бизнес-класса.", "price": 2100000, "icon": "car", "shape": "sedan", "dealer": "mid", "top_speed": 210, "accel": 8.4, "handling": 7, "fuel": 8.0, "tank": 62, "colors": ["0a1630", "c0c4cc", "ffbe28", "7a1f2b"]},
	"putnik": {"name": "«Путник» универсал", "desc": "Вместительный универсал.", "price": 2400000, "icon": "car", "shape": "wagon", "dealer": "mid", "top_speed": 205, "accel": 8.9, "handling": 7, "fuel": 8.6, "tank": 65, "colors": ["2e4a62", "d8d8d8", "3d3d3d", "6b8e23"]},
	"gorets": {"name": "«Горец» внедорожник", "desc": "Полноприводный внедорожник.", "price": 3100000, "icon": "car", "shape": "suv", "dealer": "mid", "top_speed": 195, "accel": 9.2, "handling": 6, "fuel": 11.5, "tank": 80, "colors": ["2f3b2a", "1d1f24", "e0e0e0", "8b5a2b"]},
	"strela": {"name": "«Стрела» купе", "desc": "Динамичное спортивное купе.", "price": 3600000, "icon": "car", "shape": "coupe", "dealer": "mid", "top_speed": 240, "accel": 6.4, "handling": 8, "fuel": 10.4, "tank": 58, "colors": ["d62828", "1e90ff", "111111", "f77f00"]},
	"briz": {"name": "«Бриз» кабриолет", "desc": "Открытый кабриолет для прогулок.", "price": 4200000, "icon": "car", "shape": "cabrio", "dealer": "mid", "top_speed": 225, "accel": 7.2, "handling": 8, "fuel": 9.6, "tank": 56, "colors": ["f2d0a4", "00a6a6", "e63946", "f1faee"]},

	"regent": {"name": "«Регент» представительский седан", "desc": "Флагманский седан с салоном люкс.", "price": 9000000, "icon": "car", "shape": "limo", "dealer": "premium", "top_speed": 250, "accel": 5.6, "handling": 8, "fuel": 11.8, "tank": 78, "colors": ["0b0b0f", "f4f4f4", "1c2541", "4a4e57"]},
	"titan": {"name": "«Титан» премиум-внедорожник", "desc": "Мощный и роскошный.", "price": 12000000, "icon": "car", "shape": "bigsuv", "dealer": "premium", "top_speed": 245, "accel": 5.4, "handling": 7, "fuel": 14.5, "tank": 95, "colors": ["111111", "ececec", "3b3f46", "5c1a1b"]},
	"strela_gt": {"name": "«Золотая стрела GT» гран-туризмо", "desc": "Гранд-турер с V8.", "price": 15000000, "icon": "car", "shape": "gt", "dealer": "premium", "top_speed": 295, "accel": 4.1, "handling": 9, "fuel": 13.2, "tank": 70, "colors": ["ffbe28", "0a1630", "d9d9d9", "8d0801"]},
	"faeton": {"name": "«Фаэтон» родстер", "desc": "Лёгкий двухместный родстер.", "price": 19000000, "icon": "car", "shape": "roadster", "dealer": "premium", "top_speed": 305, "accel": 3.8, "handling": 10, "fuel": 12.6, "tank": 60, "colors": ["1e90ff", "f2f2f2", "e63946", "2a9d8f"]},
	"molniya": {"name": "«Молния» суперкар", "desc": "Топовый суперкар с низким силуэтом.", "price": 35000000, "icon": "car", "shape": "super", "dealer": "premium", "top_speed": 350, "accel": 2.7, "handling": 10, "fuel": 16.0, "tank": 75, "colors": ["f4d03f", "e74c3c", "111111", "7d3cff"]},
}

const PROPERTY: Dictionary = {
	"studio": {"name": "Студия на Площади", "desc": "Уютная студия рядом с фонтаном.", "price": 3500000, "icon": "home"},
	"flat": {"name": "Квартира в высотке", "desc": "Двухкомнатная квартира с видом на город.", "price": 7000000, "icon": "home"},
	"house": {"name": "Дом в жилом районе", "desc": "Собственный дом с гаражом.", "price": 15000000, "icon": "home"},
}

const JOBS: Dictionary = {
	"courier": {"name": "Курьер", "desc": "Развезти посылки по району.", "pay": 1200, "xp": 30, "cooldown": 25.0, "min_level": 1, "icon": "jobs"},
	"loader": {"name": "Грузчик", "desc": "Разгрузить машину у магазина.", "pay": 2200, "xp": 45, "cooldown": 35.0, "min_level": 2, "icon": "jobs"},
	"guard": {"name": "Охранник", "desc": "Дежурство на объекте.", "pay": 3800, "xp": 70, "cooldown": 50.0, "min_level": 4, "icon": "shield"},
}


static func get_catalog(kind: String) -> Dictionary:
	match kind:
		"shop":
			var shop: Dictionary = {}
			for id in SHOP_ITEMS:
				shop[id] = ITEMS[id]
			return shop
		"cars":
			return CARS
		"property":
			return PROPERTY
		"jobs":
			return JOBS
	return {}


static func item_name(item_id: String) -> String:
	if ITEMS.has(item_id):
		return String(ITEMS[item_id]["name"])
	return item_id


static func item_def(item_id: String) -> Dictionary:
	if ITEMS.has(item_id):
		return ITEMS[item_id]
	return {"name": item_id, "desc": "", "price": 0, "icon": "star", "kind": "misc", "weight": 0.1, "stack": 1}


static func dealer_catalog(dealer_id: String) -> Dictionary:
	var out: Dictionary = {}
	if not DEALERS.has(dealer_id):
		return out
	for cid in DEALERS[dealer_id]["cars"]:
		out[cid] = CARS[cid]
	return out


static func car_name(car_id: String) -> String:
	if CARS.has(car_id):
		return String(CARS[car_id]["name"])
	return car_id


static func property_name(prop_id: String) -> String:
	if PROPERTY.has(prop_id):
		return String(PROPERTY[prop_id]["name"])
	return prop_id
