extends Node
## Состояние игрока и профиль (автозагрузка GameState).
## Единая экономика в рублях (₽): наличные, банковский счёт, журнал операций, налоги, штрафы.
## Показатели выживания (здоровье, голод, жажда), инвентарь со слотами и весом, автомобили в гараже.
## Профиль каждого аккаунта сохраняется в user://profiles/<sha256 никнейма>.json.
## ВАЖНО: это ЛОКАЛЬНОЕ сохранение. В онлайне все эти операции должны выполняться на сервере (см. server/).

signal balance_changed(new_balance: int)
signal xp_changed(level: int, xp: int, xp_needed: int)
signal inventory_changed
signal stats_changed
signal notification(text: String)

const Catalogs = preload("res://scripts/systems/catalogs.gd")

const CURRENCY := "₽"
const START_CASH := 15000
const START_BANK := 50000
const TAX_RATE := 0.13            # налог на зарплату (НДФЛ)
const LEDGER_MAX := 100
const PROFILE_DIR := "user://profiles"
const PROFILE_VERSION := 2
const AUTOSAVE_INTERVAL := 30.0

const SLOT_COUNT := 30
const MAX_WEIGHT := 40.0
const GARAGE_MAX := 12

const HUNGER_DECAY := 0.035       # в секунду (≈ 48 мин до нуля)
const THIRST_DECAY := 0.055       # в секунду (≈ 30 мин до нуля)
const STARVE_DAMAGE := 0.6        # здоровья в секунду при нулевом голоде/жажде
const REGEN_RATE := 0.15          # здоровья в секунду при сытости

var nickname: String = ""
var cash: int = 0
var bank: int = 0
var level: int = 1
var xp: int = 0
var play_seconds: float = 0.0
var health: float = 100.0
var hunger: float = 100.0
var thirst: float = 100.0
var slots: Array = []               # SLOT_COUNT элементов: {} (пусто) или {"id": String, "count": int}
var equipped: Dictionary = {}       # слот экипировки -> id предмета (заполняется магазинами одежды)
var owned_cars: Array = []          # [{"id","color","fuel"}]
var owned_property: Array = []      # id недвижимости
var ledger: Array = []              # [{"t": unix, "kind", "amount", "text"}]
var cooldowns: Dictionary = {}      # ключ -> unix-время готовности
var last_world_pos: Array = []      # [x, y, z] последняя позиция в городе
var session_active: bool = false

var _autosave_timer: float = 0.0
var _stats_emit_timer: float = 0.0


## Для совместимости: «баланс» в интерфейсе — наличные.
var balance: int:
	get:
		return cash


func _process(delta: float) -> void:
	if not session_active:
		return
	play_seconds += delta
	_autosave_timer += delta
	if _autosave_timer >= AUTOSAVE_INTERVAL:
		_autosave_timer = 0.0
		save_profile()
	_tick_survival(delta)


func _tick_survival(delta: float) -> void:
	hunger = maxf(0.0, hunger - HUNGER_DECAY * delta)
	thirst = maxf(0.0, thirst - THIRST_DECAY * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health = maxf(1.0, health - STARVE_DAMAGE * delta)
	elif hunger > 30.0 and thirst > 30.0:
		health = minf(100.0, health + REGEN_RATE * delta)
	_stats_emit_timer += delta
	if _stats_emit_timer >= 0.5:
		_stats_emit_timer = 0.0
		stats_changed.emit()


func xp_needed(for_level: int) -> int:
	return 100 + (for_level - 1) * 50


func fmt_money(amount: int) -> String:
	var s := str(absi(amount))
	var out := ""
	var count := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = " " + out
	if amount < 0:
		out = "-" + out
	return "%s %s" % [out, CURRENCY]


func fmt_time(seconds: float) -> String:
	var total := int(seconds)
	return "%d ч %02d мин" % [total / 3600, (total % 3600) / 60]


# ---------- Сессия ----------

func start_session(nick: String) -> void:
	nickname = nick
	_reset_profile()
	load_profile()
	session_active = true
	_autosave_timer = 0.0
	balance_changed.emit(cash)
	xp_changed.emit(level, xp, xp_needed(level))
	inventory_changed.emit()
	stats_changed.emit()


func end_session() -> void:
	if session_active:
		save_profile()
	session_active = false
	nickname = ""
	_reset_profile()
	AccountManager.logout()


func _reset_profile() -> void:
	cash = START_CASH
	bank = START_BANK
	level = 1
	xp = 0
	play_seconds = 0.0
	health = 100.0
	hunger = 100.0
	thirst = 100.0
	slots = []
	for i in range(SLOT_COUNT):
		slots.append({})
	equipped = {}
	owned_cars = []
	owned_property = []
	ledger = []
	cooldowns = {}
	last_world_pos = []


func _profile_path_for(nick: String) -> String:
	return "%s/%s.json" % [PROFILE_DIR, nick.strip_edges().to_lower().sha256_text()]


func _profile_path() -> String:
	return _profile_path_for(nickname)


func save_profile() -> void:
	if nickname == "":
		return
	DirAccess.make_dir_recursive_absolute(PROFILE_DIR)
	var data := {
		"version": PROFILE_VERSION,
		"nickname": nickname,
		"cash": cash,
		"bank": bank,
		"level": level,
		"xp": xp,
		"play_seconds": play_seconds,
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"slots": slots,
		"equipped": equipped,
		"owned_cars": owned_cars,
		"owned_property": owned_property,
		"ledger": ledger,
		"cooldowns": cooldowns,
		"last_world_pos": last_world_pos,
	}
	var f := FileAccess.open(_profile_path(), FileAccess.WRITE)
	if f == null:
		push_warning("Не удалось сохранить профиль игрока.")
		return
	f.store_string(JSON.stringify(data))
	f.close()


func load_profile() -> void:
	var data := _read_profile_file(_profile_path())
	if data.is_empty():
		return
	var ver := int(data.get("version", 1))
	level = maxi(1, int(data.get("level", 1)))
	xp = maxi(0, int(data.get("xp", 0)))
	play_seconds = float(data.get("play_seconds", 0.0))
	if ver < 2:
		_migrate_v1(data)
	else:
		cash = maxi(0, int(data.get("cash", START_CASH)))
		bank = maxi(0, int(data.get("bank", START_BANK)))
		health = clampf(float(data.get("health", 100.0)), 1.0, 100.0)
		hunger = clampf(float(data.get("hunger", 100.0)), 0.0, 100.0)
		thirst = clampf(float(data.get("thirst", 100.0)), 0.0, 100.0)
		_load_slots(data.get("slots", []))
		var eq: Variant = data.get("equipped", {})
		equipped = {}
		if typeof(eq) == TYPE_DICTIONARY:
			for k in eq.keys():
				equipped[String(k)] = String(eq[k])
		owned_cars = _load_cars(data.get("owned_cars", []))
		owned_property = _to_string_array(data.get("owned_property", []))
		var led: Variant = data.get("ledger", [])
		ledger = led if typeof(led) == TYPE_ARRAY else []
		var wp: Variant = data.get("last_world_pos", [])
		last_world_pos = wp if typeof(wp) == TYPE_ARRAY and wp.size() == 3 else []
	var cds: Variant = data.get("cooldowns", {})
	cooldowns = {}
	if typeof(cds) == TYPE_DICTIONARY:
		for k in cds.keys():
			cooldowns[String(k)] = float(cds[k])


## Старый профиль (v0.1, валюта VB): 1 VB = 10 ₽, всё идёт на банковский счёт.
func _migrate_v1(data: Dictionary) -> void:
	cash = START_CASH
	bank = START_BANK + int(data.get("balance", 0)) * 10
	var inv: Variant = data.get("inventory", {})
	if typeof(inv) == TYPE_DICTIONARY:
		for k in inv.keys():
			add_item(String(k), int(inv[k]))
	owned_cars = []
	var old_cars := _to_string_array(data.get("owned_cars", []))
	var map := {"hatch": "vanbi", "sedan": "korona_s", "coupe": "strela"}
	for cid in old_cars:
		var new_id: String = map.get(cid, "")
		if new_id != "" and Catalogs.CARS.has(new_id):
			owned_cars.append({"id": new_id, "color": String(Catalogs.CARS[new_id]["colors"][0]), "fuel": float(Catalogs.CARS[new_id]["tank"])})
	owned_property = _to_string_array(data.get("owned_property", []))


func _read_profile_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return {}
	return parsed


func _load_slots(src: Variant) -> void:
	slots = []
	for i in range(SLOT_COUNT):
		slots.append({})
	if typeof(src) != TYPE_ARRAY:
		return
	for i in range(mini(src.size(), SLOT_COUNT)):
		var e: Variant = src[i]
		if typeof(e) == TYPE_DICTIONARY and e.has("id") and Catalogs.ITEMS.has(String(e["id"])):
			slots[i] = {"id": String(e["id"]), "count": maxi(1, int(e.get("count", 1)))}


func _load_cars(src: Variant) -> Array:
	var out: Array = []
	if typeof(src) != TYPE_ARRAY:
		return out
	for v in src:
		if typeof(v) == TYPE_DICTIONARY and Catalogs.CARS.has(String(v.get("id", ""))):
			var cid := String(v["id"])
			out.append({"id": cid, "color": String(v.get("color", Catalogs.CARS[cid]["colors"][0])), "fuel": float(v.get("fuel", Catalogs.CARS[cid]["tank"]))})
	return out


func _to_string_array(src: Variant) -> Array:
	var out: Array = []
	if typeof(src) == TYPE_ARRAY:
		for v in src:
			out.append(String(v))
	return out


# ---------- Деньги: наличные и банк ----------

func _log(kind: String, amount: int, text: String) -> void:
	ledger.push_front({"t": Time.get_unix_time_from_system(), "kind": kind, "amount": amount, "text": text})
	while ledger.size() > LEDGER_MAX:
		ledger.pop_back()


func _money_changed() -> void:
	balance_changed.emit(cash)


func add_money(amount: int, reason: String = "Поступление") -> void:
	cash += amount
	_log("cash", amount, reason)
	_money_changed()


## Списать наличные. Для обратной совместимости.
func try_spend(amount: int, reason: String = "Покупка") -> bool:
	if amount < 0 or cash < amount:
		return false
	cash -= amount
	_log("cash", -amount, reason)
	_money_changed()
	return true


func total_money() -> int:
	return cash + bank


## Оплата услуги/товара: сначала наличные, остаток — с банковской карты.
func charge(amount: int, reason: String) -> bool:
	if amount < 0 or total_money() < amount:
		return false
	var from_cash := mini(cash, amount)
	var from_bank := amount - from_cash
	cash -= from_cash
	bank -= from_bank
	if from_cash > 0:
		_log("cash", -from_cash, reason)
	if from_bank > 0:
		_log("bank", -from_bank, reason + " (карта)")
	_money_changed()
	return true


## Зачисление на банковский счёт (пособия, переводы, премии).
func credit_bank(amount: int, reason: String) -> void:
	bank += amount
	_log("bank", amount, reason)
	_money_changed()


func atm_deposit(amount: int) -> Dictionary:
	if amount <= 0 or cash < amount:
		return {"ok": false, "text": "Недостаточно наличных."}
	cash -= amount
	bank += amount
	_log("bank", amount, "Пополнение счёта через банкомат")
	_money_changed()
	return {"ok": true, "text": "Внесено на счёт: %s" % fmt_money(amount)}


func atm_withdraw(amount: int) -> Dictionary:
	if amount <= 0 or bank < amount:
		return {"ok": false, "text": "Недостаточно средств на счёте."}
	bank -= amount
	cash += amount
	_log("bank", -amount, "Снятие наличных в банкомате")
	_money_changed()
	return {"ok": true, "text": "Снято со счёта: %s" % fmt_money(amount)}


## Перевод другому ЛОКАЛЬНОМУ аккаунту этого устройства. Это не онлайн-перевод:
## для настоящих игроков перевод обязан выполнять сервер.
func transfer_local(target_nick: String, amount: int) -> Dictionary:
	var target := target_nick.strip_edges()
	if target == "" or target.to_lower() == nickname.to_lower():
		return {"ok": false, "text": "Укажите ник другого игрока."}
	if amount <= 0 or bank < amount:
		return {"ok": false, "text": "Недостаточно средств на счёте."}
	var path := _profile_path_for(target)
	var data := _read_profile_file(path)
	if data.is_empty() or int(data.get("version", 1)) < 2:
		return {"ok": false, "text": "Игрок «%s» не найден на этом устройстве." % target}
	data["bank"] = int(data.get("bank", 0)) + amount
	var led: Array = data.get("ledger", []) if typeof(data.get("ledger", [])) == TYPE_ARRAY else []
	led.push_front({"t": Time.get_unix_time_from_system(), "kind": "bank", "amount": amount, "text": "Перевод от %s" % nickname})
	data["ledger"] = led
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return {"ok": false, "text": "Не удалось выполнить перевод."}
	f.store_string(JSON.stringify(data))
	f.close()
	bank -= amount
	_log("bank", -amount, "Перевод игроку %s" % target)
	_money_changed()
	save_profile()
	return {"ok": true, "text": "Переведено %s игроку %s" % [fmt_money(amount), target]}


## Штраф списывается со счёта, затем с наличных. Может увести баланс в минус только на счёте.
func fine(amount: int, reason: String) -> void:
	var from_bank := mini(bank, amount)
	bank -= from_bank
	var rest := amount - from_bank
	var from_cash := mini(cash, rest)
	cash -= from_cash
	var debt := rest - from_cash
	if debt > 0:
		bank -= debt
	_log("bank", -amount, "Штраф: %s" % reason)
	_money_changed()
	notification.emit("Штраф %s: %s" % [fmt_money(amount), reason])


func pay_salary(gross: int, reason: String) -> int:
	var tax := int(round(float(gross) * TAX_RATE))
	var net := gross - tax
	bank += net
	_log("bank", net, "Зарплата: %s (налог %s)" % [reason, fmt_money(tax)])
	_money_changed()
	return net


func add_xp(amount: int) -> void:
	xp += amount
	while xp >= xp_needed(level):
		xp -= xp_needed(level)
		level += 1
		notification.emit("Новый уровень: %d!" % level)
		AudioManager.play_sfx("levelup")
	xp_changed.emit(level, xp, xp_needed(level))


func notify(text: String) -> void:
	notification.emit(text)


# ---------- Инвентарь ----------

func item_weight(item_id: String) -> float:
	return float(Catalogs.item_def(item_id).get("weight", 0.1))


func total_weight() -> float:
	var w := 0.0
	for s in slots:
		if not s.is_empty():
			w += item_weight(String(s["id"])) * float(int(s["count"]))
	return w


func item_total(item_id: String) -> int:
	var n := 0
	for s in slots:
		if not s.is_empty() and String(s["id"]) == item_id:
			n += int(s["count"])
	return n


func has_item(item_id: String, count: int = 1) -> bool:
	return item_total(item_id) >= count


## Добавляет предметы с учётом лимита веса, размера стека и свободных слотов.
## Возвращает, сколько штук реально добавлено.
func add_item(item_id: String, count: int = 1) -> int:
	if count <= 0 or not Catalogs.ITEMS.has(item_id):
		return 0
	var def := Catalogs.item_def(item_id)
	var stack := int(def.get("stack", 1))
	var unit_w := item_weight(item_id)
	var left := count
	var room_by_weight := count
	if unit_w > 0.0:
		room_by_weight = int(floor((MAX_WEIGHT - total_weight()) / unit_w + 0.0001))
	left = mini(left, maxi(0, room_by_weight))
	var added := 0
	for i in range(SLOT_COUNT):
		if left <= 0:
			break
		var s: Dictionary = slots[i]
		if not s.is_empty() and String(s["id"]) == item_id and int(s["count"]) < stack:
			var put := mini(left, stack - int(s["count"]))
			s["count"] = int(s["count"]) + put
			left -= put
			added += put
	for i in range(SLOT_COUNT):
		if left <= 0:
			break
		if slots[i].is_empty():
			var put2 := mini(left, stack)
			slots[i] = {"id": item_id, "count": put2}
			left -= put2
			added += put2
	if added > 0:
		inventory_changed.emit()
	return added


func can_add_item(item_id: String, count: int = 1) -> bool:
	# Пробное добавление без изменений состояния.
	var backup := slots.duplicate(true)
	var got := add_item(item_id, count)
	slots = backup
	inventory_changed.emit()
	return got >= count


func remove_item(item_id: String, count: int = 1) -> bool:
	if item_total(item_id) < count:
		return false
	var left := count
	for i in range(SLOT_COUNT - 1, -1, -1):
		if left <= 0:
			break
		var s: Dictionary = slots[i]
		if not s.is_empty() and String(s["id"]) == item_id:
			var take := mini(left, int(s["count"]))
			s["count"] = int(s["count"]) - take
			left -= take
			if int(s["count"]) <= 0:
				slots[i] = {}
	inventory_changed.emit()
	return true


func move_slot(from_i: int, to_i: int) -> void:
	if from_i == to_i or from_i < 0 or to_i < 0 or from_i >= SLOT_COUNT or to_i >= SLOT_COUNT:
		return
	var a: Dictionary = slots[from_i]
	var b: Dictionary = slots[to_i]
	if a.is_empty():
		return
	if not b.is_empty() and String(a["id"]) == String(b["id"]):
		var stack := int(Catalogs.item_def(String(a["id"])).get("stack", 1))
		var put := mini(int(a["count"]), stack - int(b["count"]))
		if put > 0:
			b["count"] = int(b["count"]) + put
			a["count"] = int(a["count"]) - put
			if int(a["count"]) <= 0:
				slots[from_i] = {}
	else:
		slots[from_i] = b
		slots[to_i] = a
	inventory_changed.emit()


## Разделить стек: отделяет amount штук в первый свободный слот.
func split_slot(i: int, amount: int) -> Dictionary:
	if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
		return {"ok": false, "text": "Слот пуст."}
	var s: Dictionary = slots[i]
	if amount <= 0 or amount >= int(s["count"]):
		return {"ok": false, "text": "Нельзя разделить такое количество."}
	for j in range(SLOT_COUNT):
		if slots[j].is_empty():
			s["count"] = int(s["count"]) - amount
			slots[j] = {"id": String(s["id"]), "count": amount}
			inventory_changed.emit()
			return {"ok": true, "text": "Стек разделён."}
	return {"ok": false, "text": "Нет свободных слотов."}


## Выбросить предметы из слота (предмет исчезает из инвентаря).
func drop_slot(i: int, amount: int) -> Dictionary:
	if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
		return {"ok": false, "text": "Слот пуст."}
	var s: Dictionary = slots[i]
	var id := String(s["id"])
	var n := clampi(amount, 1, int(s["count"]))
	s["count"] = int(s["count"]) - n
	if int(s["count"]) <= 0:
		slots[i] = {}
	inventory_changed.emit()
	return {"ok": true, "text": "Выброшено: %s × %d" % [Catalogs.item_name(id), n]}


## Использовать предмет из слота: еда/вода меняют голод и жажду, аптечка лечит, кейс открывается.
func use_slot(i: int) -> Dictionary:
	if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
		return {"ok": false, "text": "Слот пуст."}
	var id := String(slots[i]["id"])
	var def := Catalogs.item_def(id)
	var kind := String(def.get("kind", "misc"))
	var text := ""
	match kind:
		"food", "drink":
			if hunger >= 100.0 and float(def.get("hunger", 0.0)) > 0.0 and float(def.get("thirst", 0.0)) <= 0.0:
				return {"ok": false, "text": "Вы не голодны."}
			if thirst >= 100.0 and float(def.get("thirst", 0.0)) > 0.0 and float(def.get("hunger", 0.0)) <= 0.0:
				return {"ok": false, "text": "Вы не хотите пить."}
			hunger = clampf(hunger + float(def.get("hunger", 0.0)), 0.0, 100.0)
			thirst = clampf(thirst + float(def.get("thirst", 0.0)), 0.0, 100.0)
			text = "Использовано: %s" % String(def["name"])
		"misc":
			if def.has("heal"):
				if health >= 100.0:
					return {"ok": false, "text": "Здоровье полное."}
				health = clampf(health + float(def["heal"]), 1.0, 100.0)
				text = "Использовано: %s" % String(def["name"])
			else:
				return {"ok": false, "text": "Этот предмет нельзя использовать."}
		"case":
			text = _open_case(id)
		_:
			return {"ok": false, "text": "Этот предмет нельзя использовать."}
	remove_item_at(i, 1)
	stats_changed.emit()
	return {"ok": true, "text": text}


func remove_item_at(i: int, count: int) -> void:
	if i < 0 or i >= SLOT_COUNT or slots[i].is_empty():
		return
	var s: Dictionary = slots[i]
	s["count"] = int(s["count"]) - count
	if int(s["count"]) <= 0:
		slots[i] = {}
	inventory_changed.emit()


func _open_case(case_id: String) -> String:
	var roll := randf()
	if roll < 0.55:
		var sums: Array = [500, 1000, 1500, 2500]
		var sum: int = sums[randi() % sums.size()]
		add_money(sum, "Награда из кейса")
		return "Кейс: +%s" % fmt_money(sum)
	if roll < 0.9:
		var pool: Array = ["sandwich", "burger", "water", "cola", "medkit"]
		var pick: String = pool[randi() % pool.size()]
		if add_item(pick, 2) > 0:
			return "Кейс: %s × 2" % Catalogs.item_name(pick)
		add_money(1000, "Награда из кейса")
		return "Инвентарь полон, кейс заменён на %s" % fmt_money(1000)
	add_xp(150)
	return "Кейс: +150 опыта"


# ---------- Покупки ----------

## kind: "shop" | "property". Автомобили покупаются через buy_car(). Возвращает {"ok": bool, "text": String}.
func buy(kind: String, item_id: String) -> Dictionary:
	var catalog := Catalogs.get_catalog(kind)
	if not catalog.has(item_id):
		return {"ok": false, "text": "Товар не найден."}
	var entry: Dictionary = catalog[item_id]
	var price := int(entry["price"])
	if kind == "property" and owned_property.has(item_id):
		return {"ok": false, "text": "Эта недвижимость уже принадлежит вам."}
	if total_money() < price:
		return {"ok": false, "text": "Недостаточно средств."}
	match kind:
		"shop":
			if not can_add_item(item_id, 1):
				return {"ok": false, "text": "Нет места или превышен лимит веса."}
			charge(price, "Покупка: %s" % String(entry["name"]))
			add_item(item_id, 1)
		"property":
			charge(price, "Покупка: %s" % String(entry["name"]))
			owned_property.append(item_id)
			inventory_changed.emit()
		_:
			return {"ok": false, "text": "Неизвестная категория."}
	add_xp(10)
	AudioManager.play_sfx("coin")
	save_profile()
	return {"ok": true, "text": "Покупка: %s" % String(entry["name"])}


func buy_car(car_id: String, color_hex: String) -> Dictionary:
	if not Catalogs.CARS.has(car_id):
		return {"ok": false, "text": "Автомобиль не найден."}
	var entry: Dictionary = Catalogs.CARS[car_id]
	for c in owned_cars:
		if String(c["id"]) == car_id:
			return {"ok": false, "text": "Этот автомобиль уже в вашем гараже."}
	if owned_cars.size() >= GARAGE_MAX:
		return {"ok": false, "text": "Гараж заполнен."}
	var price := int(entry["price"])
	if total_money() < price:
		return {"ok": false, "text": "Недостаточно средств."}
	var col := color_hex if entry["colors"].has(color_hex) else String(entry["colors"][0])
	charge(price, "Покупка авто: %s" % String(entry["name"]))
	owned_cars.append({"id": car_id, "color": col, "fuel": float(entry["tank"])})
	inventory_changed.emit()
	add_xp(50)
	AudioManager.play_sfx("coin")
	save_profile()
	return {"ok": true, "text": "Автомобиль куплен и отправлен в гараж: %s" % String(entry["name"])}


func owns_car(car_id: String) -> bool:
	for c in owned_cars:
		if String(c["id"]) == car_id:
			return true
	return false


# ---------- Работа ----------

func work(job_id: String) -> Dictionary:
	if not Catalogs.JOBS.has(job_id):
		return {"ok": false, "text": "Работа не найдена."}
	var job: Dictionary = Catalogs.JOBS[job_id]
	if level < int(job["min_level"]):
		return {"ok": false, "text": "Нужен уровень %d." % int(job["min_level"])}
	var left := cooldown_left("job_" + job_id)
	if left > 0.0:
		return {"ok": false, "text": "Отдохните ещё %d с." % int(ceil(left))}
	start_cooldown("job_" + job_id, float(job["cooldown"]))
	var net := pay_salary(int(job["pay"]), String(job["name"]))
	add_xp(int(job["xp"]))
	AudioManager.play_sfx("coin")
	save_profile()
	return {"ok": true, "text": "Смена завершена: +%s на счёт (после налога)" % fmt_money(net)}


# ---------- Перезарядки ----------

func cooldown_left(key: String) -> float:
	var ready_at := float(cooldowns.get(key, 0.0))
	return maxf(0.0, ready_at - Time.get_unix_time_from_system())


func start_cooldown(key: String, seconds: float) -> void:
	cooldowns[key] = Time.get_unix_time_from_system() + seconds


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if session_active:
			save_profile()
